import {Component, OnDestroy, OnInit, ViewChild} from "@angular/core";
import {BaseService} from "../../shared/services/base.service";
import {Observable} from "rxjs/Observable";
import {Store} from "@ngrx/store";
import {LanguageState} from "../../shared/reducers/language.reducer";
import {ProductState} from "../../shared/reducers/product.reducer";
import {ToastService} from "../../shared/services/toast.service";
import {ModalDirective} from "ngx-bootstrap";
import {isEmpty} from "ramda";
import {CustomQueryGroupState, Habit} from "../../shared/reducers/custom-query.reducer";
import {CustomQueryParam, OurpalmSearchService} from "../ourpalm-searchbtn/ourpalm-search.service";
import {Subscription} from "rxjs/Subscription";
import {RecentProduct, RecentProductState} from "../../shared/reducers/recent-product.reducer";
import {CLEAR_PRODUCT_LANGUAGE_LIST} from "../../shared/reducers/product-language.reducer";
import {Router, UrlParser} from "../../router";
import {UserService} from "../user-box/user.service";

/**
 * 打开新的浏览器tab页，传递自定义查询
 */
export const NEW_TAB_CUSTOM_PARAM = 'NEW_TAB_CUSTOM_PARAM';

@Component({
    selector: 'app-aside',
    styleUrls: ['./control-sidebar.component.css'],
    templateUrl: './control-sidebar.component.html'
})
export class ControlSidebarComponent implements OnInit, OnDestroy {

    languageSubscription: Subscription;
    language$: Observable<LanguageState>;
    productsSubscription: Subscription;
    customQuery$: Observable<CustomQueryGroupState>;
    recentProducts$: Observable<RecentProductState>;

    /** 自定义查询分组名称 */
    groupName: string;
    @ViewChild('addModal') addModal: ModalDirective;

    language: string = '';
    product: string = '';
    products: any[] = [];

    constructor(private baseService: BaseService,
                private toastService: ToastService,
                private service: OurpalmSearchService,
                private userService: UserService,
                private router: Router,
                private urlParser: UrlParser,
                private store$: Store<any>) {
        this.language$ = this.store$.select('productLanguages');
        this.customQuery$ = this.store$.select('customQuerys');
        this.recentProducts$ = this.store$.select('recentProducts');
        this.languageSubscription = this.language$.subscribe((state: LanguageState) => {
            this.language = '';
            if (state.languages.length == 1) {
                setTimeout(() => {
                    this.language = state.languages[0].lgId;
                }, 5);
            }
        });
        this.productsSubscription = this.store$.select('products').subscribe((state: ProductState) => {
            this.products = state.products.map((product) => {
                return {
                    id: product.productId,
                    text: product.name
                }
            })
        });
    }

    ngOnInit() {
        this.baseService.loadAllCustomQuery();
    }

    ngOnDestroy(): void {
        this.languageSubscription.unsubscribe();
        this.productsSubscription.unsubscribe();
    }

    /**
     * 添加自定义查询分组
     */
    addCustomQueryGroup() {
        if (isEmpty(this.groupName)) {
            return this.toastService.translate('error', '分组名称不能为空');
        }

        this.baseService.addCustomQueryGroup(this.groupName).subscribe((result: any) => {
            if (result.status == '0') {
                this.addModal.hide();
                this.toastService.translate('success', '添加成功');
                this.baseService.loadAllCustomQuery();
            } else {
                this.toastService.pop('error', result.desc);
            }
        });
    }

    /**
     * 根据产品级联加载语言
     */
    onProductSelectEvent() {
        if (this.product) {
            this.baseService.loadProductLanguageList(this.product);
        } else {
            this.store$.dispatch({
                type: CLEAR_PRODUCT_LANGUAGE_LIST
            })
        }
    }

    /**
     * 删除最近使用的某个产品
     */
    deleteRecentProduct(productId: string) {
        this.baseService.deleteRecentProduct(productId).subscribe((result) => {
            if (result.status == '0') {
                this.baseService.getRecentProductList();
                this.toastService.translate('success', '删除成功');
            } else {
                this.toastService.pop('error', result.desc);
            }
        });
    }

    /**
     * 选择切换产品
     */
    switchProduct() {
        if (this.language && this.product) {
            this.router.navigateByUrl([this.userService.getDefaultRouterPath()], {
                queryParams: {
                    product: this.product,
                    language: this.language
                },
                queryParamsHandling: 'merge'
            });
            this.baseService.getProductInfo(this.product);
            //先保存当前产品
            this.baseService.saveRecentProduct(this.language, this.product).subscribe(() => {
                //再获取最近的产品列表
                this.baseService.getRecentProductList();
            });
        } else {
            this.toastService.translate('error', '请选择产品和语言');
        }
    }

    /**
     * 快速切换产品
     */
    fastSwitchProduct(product: RecentProduct) {
        this.router.navigateByUrl([this.userService.getDefaultRouterPath()], {
            queryParams: {
                product: product.productId,
                language: product.localeId
            },
            queryParamsHandling: 'merge'
        });
        this.baseService.getProductInfo(product.productId);
        //先保存当前产品
        this.baseService.saveRecentProduct(product.localeId, product.productId).subscribe(() => {
            //再获取最近的产品列表
            this.baseService.getRecentProductList();
        });
    }

    /**
     * 删除分组
     */
    deleteGroup(groupId: string) {
        this.baseService.deleteCustomQueryGroup(groupId).subscribe((result) => {
            if (result.status == '0') {
                this.toastService.translate('success', '删除成功');
                this.baseService.loadAllCustomQuery();
            } else {
                this.toastService.pop('error', result.desc);
            }
        });
    }

    /**
     * 一键清空
     */
    deleteAllCustomQuery() {
        this.baseService.deleteAllCustomQuery().subscribe((result) => {
            if (result.status == '0') {
                this.toastService.translate('success', '删除成功');
                this.baseService.loadAllCustomQuery();
            } else {
                this.toastService.pop('error', result.desc);
            }
        });
    }

    /**
     * 打开tab页，跳转到自定义查询页面
     */
    switch2CustomeQuery(habit: Habit | any) {
        let content: any = JSON.parse(decodeURIComponent(habit.content));
        let param: CustomQueryParam = {
            moduleKey: habit.moduleKey,
            operateKey: habit.functionKey,
            name: habit.name,
            showType: habit.showType,
            systemType: habit.systemType,
            groupId: habit.groupId,
            hash: content.hash,
            query: content.query,
            url: content.url
        };
        window.localStorage.setItem(NEW_TAB_CUSTOM_PARAM, JSON.stringify(param));

        let urlState1 = this.urlParser.parseUrlState(param.url);
        let urlState2 = this.urlParser.parseUrlState(window.location.href);
        let routePath1 = urlState1.segments.join('/');
        let query1 = urlState1.queryParams;
        let routePath2 = urlState2.segments.join('/');
        let query2 = urlState2.queryParams;
        let {product: product1, language: language1, i18n: i18n1} = query1;
        let {product: product2, language: language2, i18n: i18n2} = query2;
        if (routePath1 == routePath2 && product1 == product2 && language1 == language2 && i18n1 == i18n2) {
            //如果要跳转的页面就是当前页面
            this.service.research();
        } else {
            //如果要跳转的页面不是当前页面
            this.router.navigateByUrl(routePath1, {
                queryParams: query1,
                queryParamsHandling: 'merge'
            });
        }
    }

    /**
     * 删除单条自定义查询
     */
    deleteCustomeQuery(habit: Habit) {
        this.service.deleteSearchCondition(habit.habitId).subscribe((result) => {
            if (result.status == '0') {
                this.toastService.translate('success', '删除成功');
                this.baseService.loadAllCustomQuery();
            } else {
                this.toastService.pop('error', result.desc);
            }
        });
    }
}
