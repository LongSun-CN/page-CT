import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit} from "@angular/core";
import {Router} from "../../router/router";
import {RouterTab} from "../../router";
import {Subscription} from "rxjs/Subscription";

@Component({
    selector: '[router-tabs-manager]',
    changeDetection: ChangeDetectionStrategy.Default,
    template: `
        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
            <i class="fa fa-clone"></i>
            <span class="label label-success" *ngIf="tabs.length > 1">{{ tabs.length }}</span>
        </a>
        <ul class="dropdown-menu">
            <li>
                <ul class="menu">
                    <li *ngFor="let tab of tabs" [class.selected]="tab.selected">
                        <a>
                            <div class="pull-left">
                                <span style="display:inline-block;width:230px;text-overflow:ellipsis;overflow:hidden;"
                                      (click)="selectTab(tab.tabId)">
                                    {{ tab?.current?.route?.title || 'New Tab' }}
                                    ( 
                                        {{ (getLanguage(tab?.current?.href) | language | async)}}/
                                        {{ (getProduct(tab?.current?.href) | product | async)}}
                                    )
                                </span>
                            </div>
                            <div class="pull-right" *ngIf="tabs.length > 1">
                                <i class="fa fa-remove" (click)="removeTab(tab.tabId)"></i>
                            </div>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="footer"><a href="javascript:void(0);" (click)="newTab()">New Tab</a></li>
        </ul>
    `,
    styleUrls: ['router-tabs.component.css']
})
export class RouterTabsManagerComponent implements OnInit, OnDestroy {

    tabs: RouterTab[];

    tabsSubscribe: Subscription;

    constructor(private router: Router,
                private changeDetectorRef: ChangeDetectorRef) {
    }

    ngOnInit() {
        this.tabsSubscribe = this.router.tabs.subscribe((tabs: RouterTab[]) => {
            this.tabs = tabs;
        });
    }

    ngOnDestroy() {
        this.tabsSubscribe && this.tabsSubscribe.unsubscribe();
    }

    newTab() {
        this.router.addTab();
    }

    selectTab(tabId: number) {
        this.router.selectTab(tabId);
    }

    removeTab(tabId: number) {
        this.router.removeTab(tabId);
    }

    getProduct(fullPath: string): string {
        // return fullPath ? parseAbsoluteURL(fullPath).query.product : '';
        return null; //TODO
    }

    getLanguage(fullPath: string): string {
        // return fullPath ? parseAbsoluteURL(fullPath).query.language : '';
        return null; //TODO
    }
}