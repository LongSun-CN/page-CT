import {Component, Input, NgZone, OnDestroy, OnInit, ViewChild} from "@angular/core";
import {isEmpty} from "ramda";
import {ToastService} from "../../shared/services/toast.service";
import {CustomQueryParam, OurpalmSearchService} from "./ourpalm-search.service";
import {ModalDirective} from "ngx-bootstrap";
import {Observable} from "rxjs/Observable";
import {Store} from "@ngrx/store";
import {SearchBtnItemState} from "./ourpalm-search-btn.reducer";
import {Subscription} from "rxjs/Subscription";
import {CustomQueryGroupState} from "../../shared/reducers/custom-query.reducer";
import {BaseService} from "../../shared/services/base.service";
import {NEW_TAB_CUSTOM_PARAM} from "../control-sidebar/control-sidebar.component";
import {OnSearchBtnWorking, OnSearchButtonWorking, StringOrResolver} from "./search-btn.interface";

@Component({
    selector: 'ourpalm-search-btn',
    styleUrls: ['./ourpalm-search-btn.component.css'],
    templateUrl: './ourpalm-search-btn.component.html'
})
export class OurpalmSearchBtnComponent implements OnInit, OnDestroy {
    @ViewChild('modal') modal: ModalDirective;

    searches$: Observable<any>;
    _subscribe: Subscription;
    _researchSubscribe: Subscription;

    customQuery$: Observable<CustomQueryGroupState>;

    //Inputs
    @Input()
    component: OnSearchBtnWorking | OnSearchButtonWorking;
    module: string;
    operate: string;

    //add query
    name: string = '';
    group: string = '';

    constructor(private toastService: ToastService,
                private baseService: BaseService,
                private store$: Store<any>,
                private ngZone: NgZone,
                private service: OurpalmSearchService) {
        this.customQuery$ = this.store$.select('customQuerys');
    }

    ngOnInit(): void {
        this._researchSubscribe = this.service.research$.subscribe(() => {
            this.checkCrossPageQuery();
        });
    }

    ngOnDestroy(): void {
        this._subscribe && this._subscribe.unsubscribe();
        this._researchSubscribe && this._researchSubscribe.unsubscribe();
    }

    /**
     * 检查是否有跨页面查询
     */
    checkCrossPageQuery() {
        this.checkNewTabCustomQuery().then((param: any) => {
            this.ngZone.runOutsideAngular(() => {
                this.component.onResumeSearchItem(param as CustomQueryParam);
                window.localStorage.removeItem(NEW_TAB_CUSTOM_PARAM);
                console.log(`【${this.module + '/' + this.operate}】 --> 跨tab恢复查询条件`);
            });
        }, () => {
            this.ngZone.runOutsideAngular(() => {
                this.component.onResumeSearchNothing();
                console.log(`【${this.module + '/' + this.operate}】 --> 没有要恢复的查询条件`);
            });
        });
    }

    checkNewTabCustomQuery(): Promise<void> {
        return new Promise<any>((resolve, reject) => {
            let json = window.localStorage.getItem(NEW_TAB_CUSTOM_PARAM);
            if (json) {
                let param: CustomQueryParam = JSON.parse(json);
                resolve(param);
            } else {
                reject();
            }
        });

    }

    @Input('module') set _module(module: string) {
        this.module = module;
        this.initCustomQueryList();
    }

    @Input('operate') set _operate(operate: string) {
        this.operate = operate;
        this.initCustomQueryList();
    }

    /**
     * 加载改模块下的自定义查询
     */
    initCustomQueryList(): void {
        if (!this.module || !this.operate) return;

        this.searches$ = this.store$.select('searchbtn').pluck(`${this.module}-${this.operate}`, 'data');
        this._subscribe = this.store$.select('searchbtn').pluck(`${this.module}-${this.operate}`)
            .subscribe((item: SearchBtnItemState) => {
                if (!item) {
                    //如果没有缓冲的自定义查询就调用接口查询
                    this.loadCustomQueryList();
                }
            });
        this.checkCrossPageQuery();
    }

    loadCustomQueryList() {
        if (!this.module || !this.operate) return;
        this.service.loadSearchCondition(this.module, this.operate);
    }

    search() {
        this.component.onSearch();
    }

    save() {
        this.name = '';
        this.modal.show();
    }

    /**
     * 选中自定义查询，查询回显
     */
    select(item: any) {
        let content: any = JSON.parse(decodeURIComponent(item.content));
        let param: CustomQueryParam = {
            moduleKey: item.moduleKey,
            operateKey: item.functionKey,
            name: item.name,
            showType: item.showType,
            systemType: item.systemType,
            groupId: item.groupId,
            hash: content.hash,
            query: content.query,
            url: content.url
        };
        this.component.onSelectSearchItem(param);
    }

    /**
     * 删除自定义查询
     */
    remove(habitId: string) {
        this.service.deleteSearchCondition(habitId).subscribe((result: any) => {
            if (result.status == '0') {
                this.toastService.translate('success', '删除成功');
                this.baseService.loadAllCustomQuery();
                this.loadCustomQueryList();
            } else {
                this.toastService.pop('error', result.desc);
            }
        });
    }

    /**
     * 添加自定义查询
     */
    add() {
        if (isEmpty(this.group)) {
            return this.toastService.translate('error', '请选择所属分组');
        }
        if (isEmpty(this.name)) {
            return this.toastService.translate('error', '请输入自定义查询名称');
        }

        let content: string = '';
        let onAdding: StringOrResolver = this.component.onSearchAdding();
        if (typeof onAdding === 'string') {
            content = onAdding;
        } else if (typeof onAdding === 'function') {
            content = onAdding();
        }

        this.service.addSearchCondition({
            moduleKey: this.module,
            operateKey: this.operate,
            name: this.name,
            showType: '1',
            systemType: '0',
            groupId: this.group,
            hash: window.location.hash,
            query: content,
            url: window.location.href
        }).subscribe((result: any) => {
            if (result.status == '0') {
                this.modal.hide();
                this.toastService.translate('success', '添加成功');
                this.baseService.loadAllCustomQuery();
                this.loadCustomQueryList();
            } else {
                this.toastService.pop('error', result.desc);
            }
        });
    }
}
