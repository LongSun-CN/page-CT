import {Injectable} from "@angular/core";
import {HttpService} from "../../shared/services/httpx.service";
import {environment} from "../../../environments/environment";
import {mask} from "../../shared/services/httpx.interceptor";
import {Store} from "@ngrx/store";
import {LOAD_SEARCH_BTN, SearchBtnItemState} from "./ourpalm-search-btn.reducer";
import {Subject} from "rxjs/Subject";
import {Observable} from "rxjs/Observable";

/**
 * 模块KEY    moduleKey    String    不可为空    HTTP
 * 功能KEY    functionKey    String    不可为空    HTTP
 * 内容    content    String    不可为空    HTTP
 * 名称    name    String    不可为空    HTTP
 * 是否在控制台展示    showType    String    不可为空    HTTP    0不展示1展示
 * 是否为系统级别的检索条件    systemType    String    不可为空    HTTP    0不是1是
 * 分组ID    groupId    String    不可为空    HTTP
 */
export interface CustomQueryParam {
    /**模块KEY*/
    moduleKey: string;
    /**功能KEY*/
    operateKey: string;
    /**自定义查询名称*/
    name: string;
    /**是否在控制台展示*/
    showType: string;
    /**是否为系统级别的检索条件*/
    systemType: string;
    /**分组ID*/
    groupId: string;
    /**hash路由*/
    hash: string;
    /**查询条件*/
    query: string;
    /**页面整个url*/
    url?: string;
}

@Injectable()
export class OurpalmSearchService {

    private _research: Subject<void>;

    constructor(private http: HttpService,
                private store$: Store<any>) {
        this._research = new Subject<void>();
    }

    get research$(): Observable<void> {
        return this._research.asObservable();
    }

    /**
     * 添加用户自定义查询条件
     * @param moduleKey 模块
     * @param operateKey 功能
     * @param name 名字
     */
    addSearchCondition(param: CustomQueryParam) {
        return this.http
            .post(environment.getUrl('account/accountManage/saveAccountHabit.htm'), {
                moduleKey: param.moduleKey,
                functionKey: param.operateKey,
                showType: param.showType,
                systemType: param.systemType,
                name: param.name,
                content: encodeURIComponent(JSON.stringify({
                    hash: param.hash,
                    query: param.query,
                    url: param.url
                })),
                groupId: param.groupId,
                ...mask
            })
            .map((response) => response.json())
    }

    /**
     * 加载用户自定义查询条件
     * @param moduleKey 模块
     * @param operateKey 功能
     * @returns {Observable<R>}
     */
    loadSearchCondition(moduleKey: string, operateKey: string) {
        return this.http
            .post(environment.getUrl('account/accountManage/getAccountHabitByKey.htm'), {
                moduleKey,
                functionKey: operateKey,
                showType: '',
                name: '',
                isHaveSystem: ''
            })
            .map((response) => response.json())
            .subscribe((result: any) => {
                let data = result.data;
                let item: SearchBtnItemState = {
                    key: `${moduleKey}-${operateKey}`,
                    data
                };
                this.store$.dispatch({
                    type: LOAD_SEARCH_BTN,
                    payload: item
                });
            });
    }

    /**
     * 删除用户自定义条件
     * @param habitIds
     * @returns {Observable<R>}
     */
    deleteSearchCondition(habitIds: string) {
        return this.http
            .post(environment.getUrl('account/accountManage/deleteAccountHabit.htm'), {
                habitIds: habitIds,
                ...mask
            })
            .map((response) => response.json())
    }

    research() {
        this._research.next();
    }
}