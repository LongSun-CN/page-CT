import {Action} from "@ngrx/store";

export const LOAD_SEARCH_BTN = '[Ourpalm Search Btn] Search Notice';

export interface SearchBtnItemState {
    key: string;
    data: any[];
}

export type SearchBtnState = { [key: string]: SearchBtnItemState };

const initialState: SearchBtnState = {};

/**
 * 分页查询 reducer
 */
export function searchbtnReducer(state: SearchBtnState = initialState, action: Action) {
    switch (action.type) {
        case LOAD_SEARCH_BTN:
            let item: SearchBtnItemState = action.payload;
            return {...state, ...{[item.key]: item}};
        default:
            return state;
    }
}
