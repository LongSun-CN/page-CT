import {CustomQueryParam} from "./ourpalm-search.service";
import {NEW_TAB_CUSTOM_PARAM} from "../control-sidebar/control-sidebar.component";

export type StringResolver = () => string;
export type StringOrResolver = string | StringResolver;
export type SearchState = 'None' | 'LocalStorage';

/**
 * 配合search btn使用，即search btn的钩子函数
 */
export interface OnSearchBtnWorking {

    /**
     * 当点击下拉恢复查询时触发
     */
    onSelectSearchItem(param: CustomQueryParam);

    /**
     * 当点击查询按钮时触发
     */
    onSearch();

    /**
     * 当保存查询条件时触发，返回要保存的数据
     */
    onSearchAdding(): StringOrResolver;

    /**
     * 当从localStorage中恢复时触发 --> 控制台点击自定义查询时，需要跳转刷新页面，查询条件保存到localStorage中
     */
    onResumeSearchItem(param: CustomQueryParam);

    /**
     * 当检测到localStorage中没有要恢复的查询时触发
     */
    onResumeSearchNothing();
}

/**
 * 配合search btn使用，即search btn的钩子函数
 */
export abstract class OnSearchButtonWorking {
    /**
     * 当点击下拉恢复查询时触发
     */
    abstract onSelectSearchItem(param: CustomQueryParam);

    /**
     * 当点击查询按钮时触发
     */
    abstract onSearch();

    /**
     * 当保存查询条件时触发，返回要保存的数据
     */
    abstract onSearchAdding(): StringOrResolver;

    /**
     * 当从localStorage中恢复时触发 --> 控制台点击自定义查询时，需要跳转刷新页面，查询条件保存到localStorage中
     */
    abstract onResumeSearchItem(param: CustomQueryParam);

    /**
     * 当检测到localStorage中没有要恢复的查询时触发
     */
    abstract onResumeSearchNothing();

    private _state: SearchState;

    get searchState() {
        if (window.localStorage.getItem(NEW_TAB_CUSTOM_PARAM))
            return 'LocalStorage';
        return 'None';
    }
}