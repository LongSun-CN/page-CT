## ourpalm-search-btn

### 功能

* 保存自定义查询条件
* 删除自定义查询条件
* 系统自定义查询条件
* 选择自定义查询条件


### 示例

```xml
<ourpalm-search-btn module="logcenter"
                    [operate]="operateName"
                    [onAdding]="onAddingSearchCondition"
                    (onSelect)="onSearchConditionSelect($event);"
                    (onSearch)="search();">
</ourpalm-search-btn>
```

```xml
<ourpalm-search-btn [module]="'logcenter'"
                    [operate]="'operateName'"
                    [component]="this">
</ourpalm-search-btn>
```

```javascript
@Component()
export class DemoComponent implements OnSearchBtnWorking {

    onSelectSearchItem(param: CustomQueryParam) {

    }

    onSearch() {

    }

    onSearchAdding(): StringOrResolver {
        return JSON.stringify(this.criteria);
    }

    onResumeSearchItem(param: CustomQueryParam) {
        this.onSelectSearchItem(param);
    }

    onResumeSearchNothing() {
        // init
    }
}
```

### 属性

`@Input module` 组件需要一个输入标示模块名称 如：bbs、logcenter

`@Input operate` 组件需要一个功能输入标示 如：topic(帖子管理) section(版块管理)

`@Input component` 实现OnSearchBtnWorking接口的组件
