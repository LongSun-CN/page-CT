export {
    Files,
    FileItem,
    OurpalmInputImgReader,
    CUSTOM_INPUTIMG_CONTROL_VALUE_ACCESSOR
} from './ourpalm-inputimgreader.directive';