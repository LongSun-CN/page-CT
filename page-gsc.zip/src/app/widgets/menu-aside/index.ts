export {MenuAsideComponent} from './menu-aside.component';
