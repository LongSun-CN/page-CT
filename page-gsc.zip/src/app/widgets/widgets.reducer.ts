import {searchbtnReducer} from "./ourpalm-searchbtn/ourpalm-search-btn.reducer";

export const widgetReducers = {
    searchbtn: searchbtnReducer
};