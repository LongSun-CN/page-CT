import {ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit, ViewEncapsulation} from "@angular/core";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs/Observable";
import {ProductDetailState} from "../../shared/reducers/product-detail.reducer";
import {Params, Router, UrlParser} from "../../router";
import {ProductLanguageState} from "../../shared/reducers/product-language.reducer";
import {BaseService} from "../../shared/services/base.service";
import {UserService} from "../user-box/user.service";

@Component({
    selector: 'app-header',
    styleUrls: ['./app-header.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    encapsulation: ViewEncapsulation.None,
    templateUrl: './app-header.component.html'
})
export class AppHeaderComponent implements OnInit {

    productDetail$: Observable<ProductDetailState>;

    language$: Observable<ProductLanguageState>;

    constructor(private store$: Store<any>,
                private baseService: BaseService,
                private userService: UserService,
                private urlParser: UrlParser,
                private changeDetectorRef: ChangeDetectorRef,
                private router: Router) {
        this.productDetail$ = this.store$.select('productDetail');
        this.language$ = this.store$.select('headerProductLanguages');
    }

    language: any;
    languages: any[] = [];

    private _productId: string;
    private _modules: Array<any>;

    logcenter: any;
    isMis: boolean;

    @Input() set modules(modules: Array<any>) {
        this._modules = modules;
        let arr = modules.filter(module => module.code == 'logcenter');
        if (arr.length == 1) {
            this.logcenter = arr[0];
        }
    }

    get modules() {
        return this._modules;
    }

    ngOnInit() {
        let urlState = this.urlParser.parseUrlState(window.location.href);
        this.isMis = urlState && urlState.segments && urlState.segments.includes('mis');

        this.router.params.subscribe((params: Params) => {
            let {product, language} = params;
            this.language = language;
            if (product != this._productId) {
                this._productId = product;
                this.baseService.getProductInfo(product);
                this.baseService.loadHeaderProductLanguageList(product);
                this.changeDetectorRef.markForCheck();
            }
        });

        this.language$.subscribe((state: ProductLanguageState) => {
            this.languages = state.languages.map((item) => {
                return {
                    id: item.lgId,
                    text: item.name
                }
            });
            this.changeDetectorRef.markForCheck();
        });
    }

    changeLanguage() {
        this.router.navigateByUrl([this.userService.getDefaultRouterPath()], {
            queryParams: {
                product: this._productId,
                language: this.language
            },
            queryParamsHandling: 'merge'
        });
        //先保存当前产品
        this.baseService.saveRecentProduct(this.language, this._productId).subscribe(() => {
            //再获取最近的产品列表
            this.baseService.getRecentProductList();
        });
    }
}
