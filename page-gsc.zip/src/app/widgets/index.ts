export {WidgetModule} from './widget.module';
