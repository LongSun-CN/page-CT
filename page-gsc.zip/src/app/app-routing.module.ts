import {NgModule} from "@angular/core";
import {RouterModule} from "./router/router.module";
import {Routes} from "./router";
import {bbs_routing} from "./bbs/bbs-routing.module";
import {logcenter_routing} from "./logcenter/logcenter-router.module";
import {kfqaRouting} from "./kfqa/kfqa-routing.mudule";
import {packageRoutingModule} from "./package/package-routing.mudule";
import {mis_routing} from "./mis/mis-routing.module";
import {DashboardComponent} from "./bbs/pages/dashboard/dashboard.component";

const routes: Routes = [
    ...bbs_routing,
    ...logcenter_routing,
    ...kfqaRouting,
    ...packageRoutingModule,
    ...mis_routing,
    {
        title: 'otherwise',
        path: '(.*)',
        component: DashboardComponent
    }
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ]
})
export class AppRoutingModule {
}
