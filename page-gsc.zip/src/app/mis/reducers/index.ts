import {misAddedOperationsReducer} from "./joinsdk.reducer";

export const misReducers = {
    misAddedOperations: misAddedOperationsReducer
};