import {Page} from "ngx-ourpalm-table";
import {Action} from "@ngrx/store";

/**
 * 已添加的联运列表
 */
export const MIS_ADDED_OPERATIONS = '[Mis Join Sdk] added operation list';


export interface AddedOperations {
    initState?: boolean;
    criteria: any;
    page: Page;
}

export type AddedOperationsState = {
    [tabId_deviceGroupId: string]: AddedOperations
}

const initAddedOperationsState: AddedOperationsState = {};

export function misAddedOperationsReducer(state: AddedOperationsState = initAddedOperationsState, action: Action) {
    switch (action.type) {
        case MIS_ADDED_OPERATIONS:
            let new_state: AddedOperationsState = action.payload;
            return {...state, ...new_state};
        default:
            return state;
    }
}