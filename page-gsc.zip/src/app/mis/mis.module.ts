import {NgModule} from "@angular/core";
import {BasicComponent} from "./pages/basic/basic.component";
import {SharedModule} from "../shared/shared.module";
import {WidgetModule} from "../widgets/widget.module";
import {ComponentsArr} from "./pages/index";
import {BaseConfigComponent} from "./pages/sdkdetail/subPages/base-config/base-config.component";
import {ReferralLinkComponent} from "./pages/sdkdetail/subPages/referral-link/referral-link.component";
import {SdkDetailService} from "./pages/sdkdetail/sdk-detail.service";
import {DistributionChannelsComponent} from "./pages/sdkdetail/subPages/distribution-channels/distribution-channels.component";
import {FileUploadModule} from "ng2-file-upload";
import {MisBasicService} from "./pages/basic/mis-basic.service";
import {mis_services} from "./services/index";

@NgModule({
    imports: [
        WidgetModule,
        SharedModule,
        FileUploadModule
    ],
    declarations: [
        BasicComponent,
        ...ComponentsArr,
        BaseConfigComponent,
        ReferralLinkComponent,
        DistributionChannelsComponent,
    ],
    providers: [
        SdkDetailService,
        MisBasicService,
        ...mis_services
    ]
})
export class MisModule {

}