import {Routes} from "../router";
import {ComponentsObj} from "./pages/index";

export const mis_routing: Routes = [
    {
        path: 'mis',
        component: ComponentsObj.BasicComponent,
        title: '基本信息'
    },
    {
        path: 'mis/basic',
        component: ComponentsObj.BasicComponent,
        title: '基本信息'
    },
    {
        path: 'mis/sdk/:sdkId',
        component: ComponentsObj.JoinSdkComponent,
        title: 'SDK接入'
    },
    {
        path: 'mis/sdk/detail/:id',
        component: ComponentsObj.SdkdetailComponent,
        title: 'sdk详情'
    }
];