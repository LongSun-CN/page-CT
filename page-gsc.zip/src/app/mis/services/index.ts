import {MisJoinSdkService} from "./joinsdk.service";

export const mis_services = [
    MisJoinSdkService
];