import {Injectable} from "@angular/core";
import {HttpService} from "../../shared/services/httpx.service";
import {Store} from "@ngrx/store";
import {environment} from "../../../environments/environment";
import {AddedOperations, AddedOperationsState, MIS_ADDED_OPERATIONS} from "../reducers/joinsdk.reducer";
import {Observable} from "rxjs/Observable";

@Injectable()
export class MisJoinSdkService {

    constructor(private http: HttpService,
                private store$: Store<any>) {
    }

    loadAddedOperationsState(tabId: string, deviceGroupId: string, operateLineName: string, operateLineId: string): void {
        this.http
            .post(environment.getUrl('mis2/business/getBusinesslist.htm'), {
                deviceGroupId,
                operateLineName,
                operateLineId
            })
            .map((response) => response.json())
            .subscribe((result) => {
                if (result.status == '0') {
                    let addedOperations: AddedOperations = {
                        criteria: {operateLineName, operateLineId},
                        page: {
                            currentPage: 1,
                            pageSize: result.data.length,
                            total: result.data.length,
                            rows: result.data
                        }
                    };
                    let addedOperationsState: AddedOperationsState = {
                        [`${tabId}_${deviceGroupId}`]: addedOperations
                    };
                    this.store$.dispatch({
                        type: MIS_ADDED_OPERATIONS,
                        payload: addedOperationsState
                    });
                }
            });
    }

    loadUnAddedOperationsState(deviceGroupId: string, operateLineName: string, operateLineId: string): Observable<any> {
        return this.http
            .post(environment.getUrl('mis2/business/getOperationList.htm'), {
                exclude: true,
                deviceGroupId,
                operateLineName,
                operateLineId
            })
            .map((response) => response.json());
    }

    addOperationsState(deviceGroupId: string, operationIds: string[]): Observable<any> {
        return this.http
            .post(environment.getUrl('mis2/business/saveBusiness.htm'), {
                deviceGroupId,
                operationIds: operationIds.join(',')
            })
            .map((response) => response.json());
    }
}