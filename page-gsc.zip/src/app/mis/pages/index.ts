/**
 * Created by admin on 2017/10/31.
 */
import {SdkdetailComponent} from "./sdkdetail/sdkdetail.component";
import {BasicComponent} from "./basic/basic.component";
import {ComponentsArr as subComponetsArr, ComponentsObj as subComponetsObj} from "./sdkdetail/subPages/index";
import {JoinSdkComponent} from "./joinsdk/joinsdk.component";
import {JoinSdkAddComponent} from "./joinsdk/add/joinsdk-add.component";

export const ComponentsArr = [
    SdkdetailComponent,
    BasicComponent,
    JoinSdkComponent,
    JoinSdkAddComponent,
    ...subComponetsArr
];

export const ComponentsObj = {
    SdkdetailComponent,
    BasicComponent,
    JoinSdkComponent,
    ...subComponetsObj
};