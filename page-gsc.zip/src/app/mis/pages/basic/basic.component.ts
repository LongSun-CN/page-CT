import {Component, OnInit} from "@angular/core";
import { FileUploader } from 'ng2-file-upload';
import {environment} from "../../../../environments/environment";
import { NgModel } from '@angular/forms';
import {MisBasicService} from "./mis-basic.service";
import {ToastService} from "../../../shared/services/toast.service"
import {urlParam} from "../../../shared/url-param.const";
@Component({
    selector: 'mis-basic',
    templateUrl: './basic.component.html',
    styleUrls:['./basic.component.css']
})
export class BasicComponent implements OnInit{
    public uploader:FileUploader;
    isAllowEditAddress:boolean = false;
    isAllowEditInfo:boolean;
    productInfo:any ={};
    productInfoBackUp:any ={};
    addressInfo:any={};
    constructor(private service:MisBasicService,private toast:ToastService){
        this.uploader = new FileUploader({
            url:environment.getUrl(' /mis2/productLanguage/updateIcon.htm'),
            queueLimit:1,
            autoUpload:true,
            removeAfterUpload:true,
            headers:[{name:'request-productid',value:urlParam.product.toString()},{name:'request-locale',value:urlParam.language.toString()}]
        });
        this.uploader.onSuccessItem =(fileItem,response) =>{
            let responseData =JSON.parse(response);
            if (responseData.status == 0){
                this.toast.translate('success','操作成功');
                this.updateIconUrl()
            }
        }
    }
    // 更新图片的地址
    private updateIconUrl(){
        if(this.productInfo.iconPath.search('version')>=0){
            this.productInfo.iconPath=this.productInfo.iconPath.replace(/version=\d+/,('version='+Date.now()));
            console.log(this.productInfo.iconPath)
        }else {
            this.productInfo.iconPath += ('?version='+Date.now())
        }
    }
    ngOnInit(){
        this.getProductInfo()
    }
    //icon url
    private getIconUrl(iconPath){
        return environment.getMisIconUrl()+ iconPath.slice(iconPath.search('original')-1);
    }
    // get product info
    getProductInfo(){
        this.service.getProductInfo().then(res => {
            if(res.status == 0){
                let responseData = res.data;
                responseData.iconPath = this.getIconUrl(responseData.iconPath );
                this.productInfo = res.data;
                this.productInfoBackUp= res.data;
                this.addressInfo = {
                    deliverAddress:this.productInfo.deliverAddress,
                    gameServiceAddress:this.productInfo.gameServiceAddress,
                    gifAddress:this.productInfo.gifAddress
                }
            }
        })
    }
    // cancel edit
    cancelEdit(type:number){
        switch (type){
            case 1 :
                this.isAllowEditInfo = false;
                this.productInfo =this.productInfoBackUp;
                break;
            case 2:
                this.isAllowEditAddress = false;
                this.addressInfo = {
                    deliverAddress:this.productInfoBackUp.deliverAddress,
                    gameServiceAddress:this.productInfoBackUp.gameServiceAddress,
                    gifAddress:this.productInfoBackUp.gifAddress
                };
                break;
        }
    }
    // save edit
    saveProductInfo(){
        let param ={
            nickName:this.productInfo.nickName,
            secretKey:this.productInfo.secretKey,
            statisticOnOff:this.productInfo.statisticOnOff,
            status:this.productInfo.status
        };
        this.service.updateProductInfo(param).then(res => {
            if (res.status == 0){
                this.toast.translate("success",'保存成功');
                this.productInfoBackUp = Object.assign(this.productInfoBackUp,param);
                this.isAllowEditInfo = false
            }
        })
    }
    saveAddress(){
        let param ={
            deliverAddress:this.addressInfo.deliverAddress,
            gameServiceAddress:this.addressInfo.gameServiceAddress,
            gifAddress:this.addressInfo.gifAddress
        };
        this.service.updateAddressInfo(param).then(res =>{
            if (res.status == 0){
                this.toast.translate("success",'保存成功');
                this.productInfoBackUp=Object.assign(this.productInfoBackUp,param);
                this.isAllowEditAddress = false
            }
        })
    }
}