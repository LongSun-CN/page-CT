import {Injectable} from "@angular/core";
import {HttpService} from "../../../shared/services/httpx.service";
import {Store} from "@ngrx/store";
import {ToastService} from "../../../shared/services/toast.service";
import {TranslateService} from "@ngx-translate/core";
import {urlParam} from "../../../shared/url-param.const";
import {environment} from "../../../../environments/environment";
import {toPromise} from "rxjs/operator/toPromise";
import {Url} from "url";

@Injectable()
export class MisBasicService{
    constructor(private http: HttpService,
                private $store: Store<any>,
                private toast: ToastService,
                private translate: TranslateService,
    ) {
        this.http.setHeaders({
            'request-productid': urlParam.product,
        });
    }
     basicInfo={
         'request-locale':urlParam.language,
         'request-productid':urlParam.product
    };
    getProductInfo(){
        return this.http.get(environment.getUrl("mis2/productLanguage/getProductLanguage.htm"),this.basicInfo)
            .map(res => res.json())
            .toPromise()
    }
    updateProductInfo(param):Promise<any>{
        return this.http.post(environment.getUrl('mis2/productLanguage/updateProductLanguage.htm'),Object.assign(param,this.basicInfo))
            .map(res => res.json())
            .toPromise()
    }
    updateAddressInfo(param):Promise<any>{
        return this.http.post(environment.getUrl('mis2/productLanguage/updateAddress.htm'),Object.assign(param,this.basicInfo))
            .map(res =>res.json())
            .toPromise()
    }
}