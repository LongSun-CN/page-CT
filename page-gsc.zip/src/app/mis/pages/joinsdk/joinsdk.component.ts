import {Component} from "@angular/core";
import {OurpalmTable, TableConfig} from "ngx-ourpalm-table";
import {Params, Router} from "../../../router";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs/Observable";
import {AddedOperationsState} from "../../reducers/joinsdk.reducer";
import {MisJoinSdkService} from "../../services/joinsdk.service";

@Component({
    selector: 'mis-joinsdk',
    templateUrl: './joinsdk.component.html'
})
export class JoinSdkComponent implements OnSearchBtnWorking {

    /** 联运名称 */
    operateLineName: string;
    /** 联运ID */
    operateLineId: string;
    sdkId: string;

    table: OurpalmTable;
    misAddedOperations$: Observable<AddedOperationsState>;

    constructor(private router: Router,
                private store$: Store<any>,
                private service: MisJoinSdkService,
                private tableConfig: TableConfig) {
        this.misAddedOperations$ = this.store$.select('misAddedOperations');
        //初始化表格
        this.table = this.tableConfig.create({
            pagination: false,
            cacheColumns: false,
            cachePageSize: false,
            autoLoadData: false,
            onDbClickRow: (rowIndex, rowData) => {
                this.router.navigateByUrl(`mis/sdk/detail/${rowData.operateLineId}`, {queryParamsHandling: 'merge'});
            },
            rowMenus: [
                {
                    text: '前进',
                    iconCls: 'fa fa-arrow-right',
                    disabled: () => !this.router.canGo(),
                    onclick: () => this.router.go()
                }, {
                    text: '后退',
                    iconCls: 'fa fa-arrow-left',
                    disabled: () => !this.router.canBack(),
                    onclick: () => this.router.back()
                }, {
                    text: '详情',
                    iconCls: 'fa fa-info-circle',
                    show: () => this.table.getCheckedRows().length == 1,
                    onclick: () => {
                        let rowData = this.table.getCheckedRows()[0];
                        this.router.navigateByUrl(`mis/sdk/detail/${rowData.operateLineId}`, {queryParamsHandling: 'merge'});
                    }
                }
            ]
        });
    }

    onSelectSearchItem(param: CustomQueryParam) {
        this.onResumeSearchItem(param);
    }

    onSearch() {
        this.service.loadAddedOperationsState(`${this.router.tab.tabId}`, this.sdkId, this.operateLineName, this.operateLineId);
    }

    onSearchAdding(): StringOrResolver {
        return () => {
            return JSON.stringify({
                operationName: this.operateLineName,
                operationId: this.operateLineId
            })
        };
    }

    onResumeSearchItem(param: CustomQueryParam) {
        let params = JSON.parse(param.query);
        this.operateLineName = params.operateLineName;
        this.operateLineId = params.operateLineId;
        this.onSearch();
    }

    onResumeSearchNothing() {
        //init
        Observable
            .combineLatest(this.router.tab.params, this.misAddedOperations$, (params: Params, state: AddedOperationsState) => {
                return {params: params, operations: state[`${this.router.tab.tabId}_${params['sdkId']}`]};
            })
            .subscribe(({params, operations}) => {
                this.sdkId = params['sdkId'];
                if (!operations) {
                    this.onSearch();
                } else {
                    this.operateLineName = operations.criteria.operateLineName;
                    this.operateLineId = operations.criteria.operateLineId;
                    this.table.setPageData(operations.page);
                }
            });
    }
}