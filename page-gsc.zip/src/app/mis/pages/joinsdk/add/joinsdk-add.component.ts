import {Component, EventEmitter, Output, ViewChild} from "@angular/core";
import {OurpalmTable, TableConfig} from "ngx-ourpalm-table";
import {ModalDirective} from "ngx-bootstrap";
import {MisJoinSdkService} from "../../../services/joinsdk.service";
import {Router} from "../../../../router/router";
import {ToastService} from "../../../../shared/services/toast.service";

@Component({
    selector: 'mis-joinsdk-add',
    templateUrl: './joinsdk-add.component.html'
})
export class JoinSdkAddComponent {

    /** 联运名称 */
    operationName: string;
    /** 联运ID */
    operateLineId: string;

    table: OurpalmTable;

    @ViewChild('addModal') addModal: ModalDirective;

    @Output() successFn: EventEmitter<void> = new EventEmitter<void>();

    constructor(private router: Router,
                private toastService: ToastService,
                private service: MisJoinSdkService,
                private tableConfig: TableConfig) {
        //初始化表格
        this.table = this.tableConfig.create({
            pagination: false,
            autoLoadData: false
        });
    }

    search() {
        this.service
            .loadUnAddedOperationsState(this.router.snapshot.params.sdkId, this.operationName, this.operateLineId)
            .subscribe((result) => {
                if (result.status == '0') {
                    this.table.setPageData({
                        rows: result.data,
                        currentPage: 1,
                        pageSize: result.data.length,
                        total: result.data.length
                    });
                }
            });
    }

    addOperation() {
        let ids = this.table.getCheckedRows().map((row) => row.operateLineId);
        if (ids.length == 0) {
            return this.toastService.pop('error', '请至少选择一行数据');
        }

        this.service
            .addOperationsState(this.router.snapshot.params.sdkId, ids)
            .subscribe((result) => {
                if (result.status == '0') {
                    this.toastService.pop('error', '添加成功');
                    this.addModal.hide();
                    this.successFn.emit();
                } else {
                    this.toastService.pop('error', result.desc);
                }
            });
    }

    show() {
        this.operationName = '';
        this.operateLineId = '';
        this.search();
        this.addModal.show();
    }
}