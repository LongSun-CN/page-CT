import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sdkdetail',
  templateUrl: './sdkdetail.component.html',
  styleUrls: ['./sdkdetail.component.css']
})
export class SdkdetailComponent implements OnInit {

  sdkInfo = {
    name:'不良人',
    version:'4.3.2'
  }

  constructor() { }

  onClosing(){

  }

  ngOnInit() {
  }

}
