import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DistributionChannelsComponent } from './distribution-channels.component';

describe('DistributionChannelsComponent', () => {
  let component: DistributionChannelsComponent;
  let fixture: ComponentFixture<DistributionChannelsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DistributionChannelsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DistributionChannelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
