import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'base-config',
  templateUrl: './base-config.component.html',
  styleUrls: ['./base-config.component.css']
})
export class BaseConfigComponent implements OnInit {

  @Input()
  Info:{name:string,version:string,operaInfos:{name:string,value:string}[]}

  operaInfos:{name:string,value:string}[];

  constructor() { }

  ngOnInit() {
      this.operaInfos = this.Info.operaInfos||[
              {
                  name:'联运名称',
                  value:''
              },{
                  name:'联运ID',
                  value:''
              },{
                  name:'业务ID',
                  value:''
              },{
                  name:'添加人',
                  value:''
              },{
                  name:'添加时间',
                  value:''
              }
          ];
  }

}
