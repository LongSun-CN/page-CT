import {Component, OnInit, ViewChild} from '@angular/core';
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {SdkDetailService} from "../../sdk-detail.service";
import {CustomQueryParam} from "../../../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {StringOrResolver} from "../../../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {Router} from "../../../../../router/router";
import {Subscription} from "rxjs/Subscription";
import {Observable} from "rxjs/Observable";
import {ModalDirective} from "ngx-bootstrap";

@Component({
    selector: 'referral-link',
    templateUrl: './referral-link.component.html',
    styleUrls: ['./referral-link.component.css']
})
export class ReferralLinkComponent implements OnInit {

    table: OurpalmTable;
    search: any;
    $tableSubscription:Subscription;
    @ViewChild('addModal')
    addModal: ModalDirective;


    constructor(private service:SdkDetailService,  private route: Router,) {
    }

    ngOnInit() {
        this.table = new OurpalmTable({
            cacheKey: "mis-sdkdetailReferralLinkSearch-main",
            autoLoadData: false,
            pagePosition: 'bottom',
            defaultPageSize: 100,
            pageList: [100, 200],
            showRefreshBtn: false,
            showSettingBtn: false,
            fixTop: true,
            distanceTop: 50,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                this.searchCommition();
            }
        });
    }

    searchCommition() {
       // this.service.queryAllBigCustomerPage( this.search, this.table.getOptions())
    }


    onSelectSearchItem(param: CustomQueryParam) {
        let params = JSON.parse(param.query);
        this.search = {...params,_product:params.product};
        this.searchCommition();
    }

    onSearch() {
        this.searchCommition();
    }

    onSearchAdding(): StringOrResolver {
        return JSON.stringify(this.search);
    }

    onResumeSearchItem(param: CustomQueryParam) {
        this.onResumeSearchNothing();
        this.onSelectSearchItem(param);

    }

    onResumeSearchNothing() {
        // this.$tableSubscription = Observable.combineLatest(this.route.params,this.$BigcustomerSearchState, (params: any, state: BigcustomerSearchState)=>[params,state])
        //     .subscribe(([param,result])=>{
        //         if (result && !result.isInit) {
        //             this.table.setPageData(result.data);//表格数据
        //             let params = JSON.parse(result.search);
        //             this.search = {...params, _product: params.product};
        //         }
        //     })

    }


    add(){
        this.addModal.show();
    }


    exportData(){

    }





}
