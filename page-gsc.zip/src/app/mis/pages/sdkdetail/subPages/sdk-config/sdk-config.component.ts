import {Component} from "@angular/core";

@Component({
    selector: 'mis-sdkconfig',
    templateUrl: './sdk-config.component.html'
})
export class MisSdkConfigComponent {

}