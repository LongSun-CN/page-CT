import {Component} from "@angular/core";

@Component({
    selector: 'mis-sdkconfig-add',
    templateUrl: './sdkconfig-add.component.html',
    styleUrls: ['./sdkconfig-add.component.css']
})
export class MisSdkConfigAddComponent {

    step = 1;
}