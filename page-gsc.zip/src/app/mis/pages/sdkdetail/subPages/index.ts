import {BaseConfigComponent} from "./base-config/base-config.component";
import {ReferralLinkComponent} from "./referral-link/referral-link.component";
import {DistributionChannelsComponent} from "./distribution-channels/distribution-channels.component";
import {MisSdkConfigComponent} from "./sdk-config/sdk-config.component";
import {MisSdkConfigAddComponent} from "./sdk-config/add-sdk/sdkconfig-add.component";

/**
 * Created by admin on 2017/11/2.
 */
export const ComponentsArr = [
    BaseConfigComponent,
    ReferralLinkComponent,
    DistributionChannelsComponent,
    MisSdkConfigComponent,
    MisSdkConfigAddComponent
];

export const ComponentsObj = {
    BaseConfigComponent,
    ReferralLinkComponent,
    DistributionChannelsComponent
};