import {NgModule} from "@angular/core";
import {LogCenterService} from "./logcenter.service";
import {WidgetModule} from "../widgets/widget.module";
import {logcenter_components} from "./pages/index";
import {SharedModule} from "../shared/shared.module";
import {BillingOrderService} from "./pages/main/order/billing-order.service";
import {AccountManageService} from "./pages/main/account/account-manage.service";
import {FileUploadModule} from "ng2-file-upload";

@NgModule({
    declarations: [
        ...logcenter_components
    ],
    imports: [
        WidgetModule,
        SharedModule,
        FileUploadModule
    ],
    providers: [
        LogCenterService,
        BillingOrderService,
        AccountManageService
    ]
})
export class LogCenterModule {
}
