import {IndexComponent} from "./pages/index/index.component";
import {MainComponent} from "./pages/main/main.component";
import {MainDetailComponent} from "./pages/detail/detail.component";
import {Routes} from "../router";

export const logcenter_routing: Routes = [
    {
        path: 'logcenter',
        component: IndexComponent,
        title: '日志中心首页'
    },
    {
        path: 'logcenter/:logType',
        component: MainComponent,
        title: '日志中心'
    },
    {
        path: 'logcenter/:logType/detail',
        component: MainDetailComponent,
        title: '日志详情'
    }
];
