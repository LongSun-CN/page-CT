import {Injectable} from "@angular/core";
import {HttpService} from "../shared/services/httpx.service";
import {environment} from "../../environments/environment";
import {Observable} from "rxjs/Observable";
import {mask, no_mask} from "../shared/services/httpx.interceptor";
import {INIT_TABLE_COLUMNS, INIT_TABLE_DATA, LogColumnState, LogTableState} from "./reducers/main.reducers";
import {Store} from "@ngrx/store";
import {ToastService} from "../shared/services/toast.service";

@Injectable()
export class LogCenterService {

    constructor(private http: HttpService,
                private toastService: ToastService,
                private store$: Store<any>) {
    }

    /**
     * 获取联运数据
     * @param productId 产品id
     * @param localId 语言id
     */
    loadLianYun(productId: string, localId): Observable<any> {
        return this.http
            .post(environment.getUrl('mis/operationLine/getOperationLineList.htm'), {
                productId,
                localId,
                ...no_mask
            })
            .map((response) => response.json())
    }

    /**
     * 获取游戏服数据
     * @param productId 产品id
     * @param localId 语言id
     */
    loadGameServer(productId: string, localId): Observable<any> {
        return this.http
            .post(environment.getUrl('mis/logicServer/getLogicServerList.htm'), {
                productId,
                localId,
                ...no_mask
            })
            .map((response) => response.json())
    }

    /**
     * 获取主渠道数据
     * @param productId 产品id
     * @param operationLineId 联运id
     */
    loadZhuQuDao(productId, operationLineId) {
        return this.http
            .post(environment.getUrl('mis/channel/getChannelList.htm'), {
                productId,
                operationLineId,
                ...no_mask
            })
            .map((response) => response.json())
    }

    /**
     * 日志版块名称
     * @param logType 日志类型
     */
    logName(logType: string): string {
        let logNames = {
            '1': '启动数据',
            '2': '心跳数据',
            '3': '用户注册',
            '4': '用户登录',
            '5': '玩家下单',
            '6': '物品变更',
            '7': '登录游戏',
            '8': '创建角色',
            '9': '属性变更',
            '10': '卡牌变更',
            '11': '密码修改',
            '12': '游戏任务',
            '13': '游戏关卡',
            '14': '其他事件',
            '15': '玩家交互',
            '16': '崩溃数据',
            '17': '广告推广',
            '18': '发货成功',
            '19': '卡顿数据',
            '20': '日志检索',
            '21': '用户继承',
            '22': '异常数据',
            '23': '货币变更',
            '24': '礼包领取',
            '25': '用户数据',
            '26': '订单数据'
        };
        return logNames[logType];
    }

    logOperateName(logType: string): string {
        let logNames = {
            '1': 'launch-log', //启动日志
            '2': 'heartbeat-log', //心跳日志
            '3': 'register-log', //: '用户注册',
            '4': 'userlogin-log', //: '用户登录',
            '5': 'order-log', //: '玩家下单',
            '6': 'goodschange-log', //: '物品变更',
            '7': 'logingame-log', //: '登录游戏',
            '8': 'createrole-log', //: '创建角色',
            '9': 'changeprop-log', //: '属性变更',
            '10': 'changecard-log', //: '卡牌变更',
            '11': 'modifypassword-log', //: '密码修改',
            '12': 'gametask-log', //: '游戏任务',
            '13': 'gamelevel-log', //: '游戏关卡',
            '14': 'otherevent-log', //: '其他事件',
            '15': 'playercommu-log', //: '玩家交互',
            '16': 'breakdown-log', //: '崩溃日志',
            '17': 'adseo-log', //: '广告推广',
            '18': 'deliverok-log', //: '发货成功',
            '19': 'kadun-log', //: '卡顿日志',
            '20': 'all-log', //: '全部日志',
            '21': 'userextend-log', //: '用户继承',
            '22': 'exception-log', //: '异常日志',
            '23': 'changemoney-log', //: '货币变更',
            '24': 'getpackage-log',//礼包领取
            '25': 'accountdata-log', //账户数据
            '26': 'billingOrder-log'//订单数据
        };
        return logNames[logType];
    }

    /**
     * 日志 服务器地址
     * @param logType 日志类型
     */
    private pageLogUrl(logType: string) {
        switch (logType) {
            case '1': //启动日志
                return 'log/logQuery/getStartLog.htm';
            case '2': //心跳日志
                return 'log/logQuery/getHeartbeatLog.htm';
            case '3': //用户注册
                return 'log/logQuery/getUserRegLog.htm';
            case '4': //用户登陆
                return 'log/logQuery/getUserLoginLog.htm';
            case '5': //玩家下单
                return 'log/logQuery/getPlayerOrderLog.htm';
            case '6': //玩家物品变更
                return 'log/logQuery/getPlayerItemChangeLog.htm';
            case '7': //玩家登录
                return 'log/logQuery/getPlayerLoginLog.htm';
            case '8': //玩家注册
                return 'log/logQuery/getPlayerRegLog.htm';
            case '9': //玩家属性变更
                return 'log/logQuery/getPlayerAttrChangeLog.htm';
            case '10': //玩家卡牌属性变更
                return 'log/logQuery/getPlayerCardAttrChangeLog.htm';
            case '11': //密码修改
                return 'log/logQuery/getPwdUpdateLog.htm';
            case '12': //玩家任务
                return 'log/logQuery/getPlayerTaskLog.htm';
            case '13': //玩家关卡
                return 'log/logQuery/getPlayerStageLog.htm';
            case '16': //崩溃日志
                return 'log/logQuery/getCrashLog.htm';
            case '14': //其他事件
                return 'log/logQuery/getPlayerAlternatelyEventLog.htm';
            case '15': //玩家交互
                return 'log/logQuery/getOtherEventLog.htm';
            case '17': //海外广告推广
                return 'log/logQuery/getOverseasPopularizeLog.htm';
            case '18': //通知发货成功
                return 'log/logQuery/getNoticeSendSuccessLog.htm';
            case '23': //货币变更
                return 'log/logQuery/getCurrencyChangeLog.htm';
            case '19': //卡顿日志
                return 'log/logQuery/getLagLog.htm';
            case '21': //用户继承日志
                return 'log/logQuery/getUserExtendsLog.htm';
            case '22': //异常信息日志
                return 'log/logQuery/getExceptionMessageLog.htm';
            case '20': //全部日志
                return 'log/logQuery/queryAllLog.htm';
            case '24': //礼包领取
                return 'log/logQuery/getFetchGameCodeLog.htm';
            case '25'://账户数据
                return 'gsc/userAccount/getUserInfoPage.htm';
            case '26'://点单数据
                return 'gsc/billingOrder/findPage.htm';
        }
    }

    /**
     * 日志 服务器地址
     * @param logType 日志类型
     */
    private exportLogUrl(logType: string) {
        switch (logType) {
            case '1': //启动日志
                return 'log/logQuery/exportStartLog.htm';
            case '2': //心跳日志
                return 'log/logQuery/exportHeartbeatLog.htm';
            case '3': //用户注册
                return 'log/logQuery/exportUserRegLog.htm';
            case '4': //用户登陆
                return 'log/logQuery/exportUserLoginLog.htm';
            case '5': //玩家下单
                return 'log/logQuery/exportPlayerOrderLog.htm';
            case '6': //玩家物品变更
                return 'log/logQuery/exportPlayerItemChangeLog.htm';
            case '7': //玩家登录
                return 'log/logQuery/exportPlayerLoginLog.htm';
            case '8': //玩家注册
                return 'log/logQuery/exportPlayerRegLog.htm';
            case '9': //玩家属性变更
                return 'log/logQuery/exportPlayerAttrChangeLog.htm';
            case '10': //玩家卡牌属性变更
                return 'log/logQuery/exportPlayerCardAttrChangeLog.htm';
            case '11': //密码修改
                return 'log/logQuery/exportPwdUpdateLog.htm';
            case '12': //玩家任务
                return 'log/logQuery/exportPlayerTaskLog.htm';
            case '13': //玩家关卡
                return 'log/logQuery/exportPlayerStageLog.htm';
            case '16': //崩溃日志
                return 'log/logQuery/exportCrashLog.htm';
            case '14': //其他事件
                return 'log/logQuery/exportOtherEventLog.htm';
            case '15': //玩家交互
                return 'log/logQuery/exportPlayerAlternatelyEventLog.htm';
            case '17': //海外广告推广
                return 'log/logQuery/exportOverseasPopularizeLog.htm';
            case '18': //通知发货成功
                return 'log/logQuery/exportNoticeSendSuccessLog.htm';
            case '23': //货币变更
                return 'log/logQuery/exportCurrencyChangeLog.htm';
            case '19': //卡顿日志
                return 'log/logQuery/exportLagLog.htm';
            case '21': //用户继承日志
                return 'log/logQuery/exportUserExtendsLog.htm';
            case '22': //异常信息日志
                return 'log/logQuery/exportExceptionMessageLog.htm';
            case '20': //全部日志
                return 'log/logQuery/exportAllLog.htm';
            case '24': //礼包领取
                return 'log/logQuery/exportFetchGameCodeLog.htm';
        }
    }

    /**
     * 分页获取日志记录
     * @param logType 日志类型
     * @param params  查询参数
     */
    pageLogData(productId: string, language: string, tabId: string, logType: string, currentPage: number, pageSize: number, params: any = {}, totalCount: number, sort: string = '', order: string = '') {
        this.http
            .post(environment.getUrl(this.pageLogUrl(logType)), {
                groupId: logType,
                currentPage,
                pageSize,
                sort,
                order,
                ...params,
                ...mask,
                totalCount: totalCount > 0 ? totalCount : ''
            })
            .map((response) => response.json())
            .subscribe((result: any) => {
                if (result.status == '0') {
                    let logData: LogTableState = {
                        productId,
                        language,
                        tabId,
                        logType,
                        params,
                        page: {
                            currentPage,
                            pageSize,
                            total: result.data.totalCount,
                            rows: result.data.list
                        }
                    };
                    this.toastService.pop('success', `数据加载完成 ${result.data.totalCount} 条`);
                    this.store$.dispatch({
                        type: INIT_TABLE_DATA,
                        payload: logData
                    });
                }
            });
    }

    /**
     * 获取日志列定义
     * @param logType 日志类型
     */
    loadLogColumns(logType: string) {
        return this.http
            .post(environment.getUrl('log/logQuery/getAllColumnList.htm'), {
                groupId: logType,
                ...mask
            })
            .map((response) => response.json())
            .subscribe(result => {
                if (result.status == '0') {
                    let columns = result.data.columnList;
                    let state: LogColumnState = {
                        logType: logType,
                        columns: columns
                    };
                    this.store$.dispatch({
                        type: INIT_TABLE_COLUMNS,
                        payload: {
                            [logType]: state
                        }
                    });
                }
            });
    }

    /**
     * 根据查询条件导出日志
     * @param logType 日志类型
     * @param fileType 文件类型 1: csv | 2: excel
     * @param params 查询条件
     * @param columns [{"columnName": "username", "columnView": "用户名0"}, {"columnName": "nickname", "columnView": "用户昵称"}]
     */
    exportLogs(logType: string, fileType: string, params: any, columns: string) {
        this.http.download(environment.getUrl(this.exportLogUrl(logType)), {
            ...params,
            groupId: logType,
            exportFileType: fileType,
            columns,
            ...no_mask
        });
    }

    /**
     * 加载logcat详情
     */
    logCatDetail(url: string) {
        return this.http
            .post(environment.getUrl('log/logQuery/downLoadLogCatFile.htm'), {
                url,
                ...no_mask
            })
            .map((response) => response.json())
    }

    /**
     * 查询是否存在十六进制日志
     */
    isExistHexlog(localeId: string, productId: string, startTime: any, endTime: any, esid: any) {
        return this.http
            .post(environment.getUrl('log/logQuery/isExistHexlog.htm'), {
                localeId,
                productId,
                startTime,
                endTime,
                esid,
                ...no_mask
            })
            .map((response) => response.json())
    }

    downloadLogFile(url: string) {
        this.http.download(environment.getUrl('log/logQuery/downloadLogFile.htm'), {
            url,
            ...no_mask
        });
    }
}
