import {Component} from "@angular/core";

@Component({
    selector: 'logcenter-index',
    templateUrl: './index.component.html'
})
export class IndexComponent {

}