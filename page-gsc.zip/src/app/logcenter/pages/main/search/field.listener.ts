export interface ValidateResult {
    isValid: boolean,
    errorDesc?: string
}

export interface IFieldListener {

    getValue(): object;

    setValue(params: any): void;

    validate(): ValidateResult;
}

/**
 * 检查一组中至少一个不能为空
 */
export interface IGroupEmptyCheckListener {
    /**
     * 当前控件值是否为空
     */
    isGroupEmpty(): boolean;

    /**
     * 是否需要对当前日志类型进行检查
     */
    isCheckGroup(logType: string): boolean;
}

/**
 * 根据权限检查一组中至少一个不能为空
 */
export interface IAuthGroupEmptyCheckListener {
    /**
     * 当前控件值是否为空
     */
    isAuthGroupEmpty(): boolean;

    /**
     * 是否需要对当前日志类型进行检查
     */
    isCheckAuthGroup(logType: string): boolean;
}

export function instanceofGroupEmptyCheckListener(obj: any): obj is IGroupEmptyCheckListener {
    return 'isGroupEmpty' in obj;
}

export function instanceofAuthGroupEmptyCheckListener(obj: any): obj is IAuthGroupEmptyCheckListener {
    return 'isAuthGroupEmpty' in obj;
}