import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-custom',
    template: `
        <ng-container *ngIf="['6','23'].includes(type)">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'自定义'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      name="custom">
            </gw-input>
        </ng-container>
    `
})
export class CustomFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {
            custom: this.value
        }
    }

    setValue(params: any): void {
        this.value = params['custom'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}