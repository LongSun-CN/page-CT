import {ProductFieldComponent} from "./product-field.component";
import {TimeFieldComponent} from "./time-field.component";
import {UserInfoFieldComponent} from "./userinfo-field.component";
import {QueryFromFieldComponent} from "./queryfrom-field.component";
import {ZhuQuDaoFieldComponent} from "./zhuqudao-field.component";
import {ServiceTypeFieldComponent} from "./servicetype-field.component";
import {LianYunFieldComponent} from "./lianyun-field.component";
import {GameServerFieldComponent} from "./gameserver-field.component";
import {DetailFieldComponent} from "./detail-field.component";
import {UpdateTypeFieldComponent} from "./updatetype-field.component";
import {CustomFieldComponent} from "./custom-field.component";
import {PropFieldComponent} from "./prop-field.component";
import {PlatformFieldComponent} from "./platform-field.component";
import {AdvertiserFieldComponent} from "./advertiser-field.component";
import {EventKeyFieldComponent} from "./eventkey-field.component";
import {UserTypeFieldComponent} from "./usertype-field.component";
import {StatusFieldComponent} from "./status-field.component";
import {DeviceInfoFieldComponent} from "./deviceinfo-field.component";
import {OrderNumberFieldComponent} from "./ordernumber-field.component";
import {KeyWordFieldComponent} from "./keyword-field.component";
import {OrderTypeFieldComponent} from "./ordertype-field.component";
import {isOrderRebuildFieldComponent} from "./isrebuldorder-field.component";
import {UserBindStatusComponent} from "./user-bind-status.component";
import {UserBindPhoneComponent} from "./user-bind-phone.component";
import {UserBindEmailComponent} from "./user-bind-email.component";
import {UserTestStatusComponent} from "./user-test-status.component";
import {UserCloseStatusComponent} from "./user-close-status.component";
import {OrderStatusFieldComponent} from "./orderstatus-field.component";
export const field_components = [
    ProductFieldComponent,
    QueryFromFieldComponent,
    TimeFieldComponent,
    LianYunFieldComponent,
    ZhuQuDaoFieldComponent,
    UserInfoFieldComponent,
    ServiceTypeFieldComponent,
    GameServerFieldComponent,
    DetailFieldComponent,
    UpdateTypeFieldComponent,
    CustomFieldComponent,
    PropFieldComponent,
    PlatformFieldComponent,
    AdvertiserFieldComponent,
    EventKeyFieldComponent,
    UserTypeFieldComponent,
    StatusFieldComponent,
    DeviceInfoFieldComponent,
    OrderNumberFieldComponent,
    KeyWordFieldComponent,
    OrderStatusFieldComponent,
    OrderTypeFieldComponent,
    isOrderRebuildFieldComponent,
    UserBindStatusComponent,
    UserBindPhoneComponent,
    UserBindEmailComponent,
    UserTestStatusComponent,
    UserCloseStatusComponent
];
