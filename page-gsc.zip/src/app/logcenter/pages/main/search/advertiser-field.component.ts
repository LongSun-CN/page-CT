import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-advertiser',
    template: `
        <ng-container *ngIf="['17'].includes(type)">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'广告商'"
                              [(ngModel)]="value"
                              [closeable]="true"
                              [data]="[{text: 'google', id: 'google'},{text: 'adjust', id: 'adjust'},{text: 'facebook', id: 'facebook'}]"
                              name="advertiserTo">
            </gw-single-select>
        </ng-container>
    `
})
export class AdvertiserFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {advertiserTo: this.value};
    }

    setValue(params: any): void {
        this.value = params['advertiserTo'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}