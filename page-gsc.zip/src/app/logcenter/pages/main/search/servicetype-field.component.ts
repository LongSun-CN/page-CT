import {Component, Input} from "@angular/core";
import {IAuthGroupEmptyCheckListener, IFieldListener, IGroupEmptyCheckListener, ValidateResult} from "./field.listener";
import {SelectModal} from "glowworm";

@Component({
    selector: 'logcenter-search-servicetype',
    template: `
        <span [class.hidden]="!['12','13','6','10','20','23','26'].includes(type)">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'业务信息'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      [showSelect]="true"
                      [selectData]="options"
                      name="serviceType">
            </gw-input>
        </span>
    `
})
export class ServiceTypeFieldComponent implements IFieldListener, IAuthGroupEmptyCheckListener, IGroupEmptyCheckListener {

    @Input() toolbar: any;
    type: string;
    value: SelectModal = {value: '', selectValue: ''};

    options: any[] = [];

    @Input('type') set _type(type: string) {
        this.type = type;
        switch (type) {
            case '12': //游戏任务
                this.options = [
                    {text: '任务名称', id: 'taskName'},
                    {text: '任务ID', id: 'taskId'}
                ];
                break;
            case '13': //游戏关卡
                this.options = [
                    {text: '关卡名称', id: 'stageName'},
                    {text: '关卡ID', id: 'stageId'}
                ];
                break;
            case '6': //物品变更
                this.options = [
                    {text: '物品名称', id: 'itemName'},
                    {text: '物品ID', id: 'itemId'}
                ];
                break;
            case '10': //卡牌变更
                this.options = [
                    {text: '卡牌名称', id: 'cardName'},
                    {text: '卡牌ID', id: 'cardId'}
                ];
                break;
            case '20':
                this.options = [
                    {text: '商品名称', id: 'itemName'},
                    {text: '商品ID', id: 'itemId'},
                    {text: '卡牌名称', id: 'cardName'},
                    {text: '卡牌ID', id: 'cardId'},
                    {text: '关卡ID', id: 'stageId'},
                    {text: '任务ID', id: 'taskId'},
                    {text: '动作ID', id: 'actId'},
                    {text: '自定义', id: 'custom'}
                ];
                break;
            case '23': //货币变更
                this.options = [
                    {text: '货币名称', id: 'itemName'},
                    {text: '货币ID', id: 'itemId'}
                ];
                break;
            case '26':
                this.options = [
                    {text: '订单号', id: 'orderId'},
                    {text: '合作订单号', id: 'relateOrder'},
                    {text: '商品ID', id: 'propId'},
                    {text: '商品名称', id: 'propName'},
                    {text: '手机号码', id: 'phoneNum'},
                    {text: '终端型号', id: 'deviceName'},
                    {text: '游戏版本', id: 'clientVersion'},
                    {text: '测试账号', id: 'isTestUser'},
                    {text: '返利状态', id: 'rebateStatus'}
                ];
                break;

        }
        this.options = [{text: '请选择', id: ''}, ...this.options];
    }

    getValue(): object {
        this.value = this.value || {selectValue: '', value: ''};
        return {
            serviceType: this.value.selectValue,
            serviceText: this.value.value
        };
    }

    setValue(params: any): void {
        this.value = {
            value: params['serviceText'] || '',
            selectValue: params['serviceType'] || ''
        }
    }

    validate(): ValidateResult {
        return {isValid: true};
    }

    isAuthGroupEmpty(): boolean {
        return this.value.value ? false : true;
    }

    isCheckAuthGroup(logType: string): boolean {
        return ['12', '13', '6', '10'].includes(logType);
    }

    isGroupEmpty(): boolean {
        return this.value.value ? false : true;
    }

    isCheckGroup(logType: string): boolean {
        return ['20'].includes(logType);
    }
}
