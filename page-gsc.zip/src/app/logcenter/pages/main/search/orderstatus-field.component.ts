import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
  selector: 'logcenter-search-order-status',
  template: `
    <ng-container *ngIf="['26'].includes(type)">
      <gw-single-select  #gwcontrol
                         [toolbar]="toolbar"
                         [label]="'状态'"
                         [data]="[{id: '0-0', text: '下单成功'}, {id: '0--1', text: '支付失败'}, {id: '1-1', text: '支付成功'}, { id: '1-2',  text: '通知成功' }, {id: '1--2', text: '通知失败'}]"
                         [(ngModel)]="value"
                         [closeable]="true"
                         [enabled]="true"
                         [showSelect]="true"
                         [selectData]="[{id: '0', text: '未支付'}, {id: '1', text: '已支付'}]"
                         [linkAge]="true"
      ></gw-single-select>
    </ng-container>
  `
})
export class OrderStatusFieldComponent implements IFieldListener {

  @Input()
  toolbar: any;
  @Input()
  type: string;
  @Input()
  value: any = '';

  getValue(): object {
    let p = (this.value&&this.value.selectValue)||(this.value&&this.value.value&&this.value.value.substr(0,1))||'';
    let c = '';
    if(p===''){
        c='';
    }else if(this.value&&this.value.value){
        c= this.value.value.replace(p+'-','');
    }

    return {
      payStatus: p,
      callStatus:c
    }
  }

  setValue(params: any): void {
    this.value = params['payStatus'] || '';
  }

  validate(): ValidateResult {
    return {isValid: true};
  }
}
