import {Component, EventEmitter, Input, OnInit, Output} from "@angular/core";
import {urlParam} from "../../../../shared/url-param.const";

@Component({
    selector: 'logcenter-search-product',
    template: ` `
})
export class ProductFieldComponent implements OnInit {

    @Output() onSave: EventEmitter<any> = new EventEmitter<any>();

    @Input() toolbar: any;
    @Input() type: string;

    ngOnInit(): void {
        this.onSelect(urlParam.product);
    }

    onSelect($event) {
        console.log('onSelect', $event);
        this.onSave.emit($event);
    }
}


// @Component({
//     selector: 'logcenter-search-product',
//     template: `
//         <ng-container
//                 *ngIf="['1','2','3','4','21','18','8','7','12','13','6','10','9','15','14','5','16','19','17','20','22','23','24','11'].includes(type)">
//             <!--<gw-single-select #gwcontrol-->
//                               <!--[toolbar]="toolbar"-->
//                               <!--[label]="'产品'"-->
//                               <!--[(ngModel)]="value"-->
//                               <!--[closeable]="false"-->
//                               <!--[data]="(product$ | async).data"-->
//                               <!--(onSave)="onSelect($event)"-->
//                               <!--name="product">-->
//             <!--</gw-single-select>-->
//         </ng-container>
//     `
// })
// export class ProductFieldComponent implements IFieldListener, OnDestroy {
//
//     @Input() toolbar: any;
//     @Input() type: string;
//     @Output() onSave: EventEmitter<any> = new EventEmitter<any>();
//
//     _subscript: Subscription;
//
//     product$: Observable<any>;
//     value: string;
//     locale: string;
//
//     constructor(private store$: Store<any>) {
//         this.product$ = this.store$.select('product');
//         this._subscript = this.store$.select('lan').subscribe((result: any) => {
//             if (result.data && result.data.length > 0) {
//                 this.locale = result.data[0].value;
//             }
//         });
//     }
//
//     getValue(): object {
//         if (this.value.length == 0)
//             return {product: ''};
//         return {product: this.value, locale: this.locale};
//     }
//
//     setValue(params: any): void {
//         this.value = params['product'];
//         if (this.value) {
//             this.product$.pluck('data').take(1).subscribe((items: any[]) => {
//                 let value = items.filter((item: any) => item.id == this.value);
//                 value.length > 0 && this.onSelect(value[0].id);
//             });
//         }
//     }
//
//
//     validate(): ValidateResult {
//         return !this.value ? {isValid: false, errorDesc: '请选择产品'} : {isValid: true};
//     }
//
//     onSelect($event) {
//         this.onSave.emit($event);
//     }
//
//     ngOnDestroy(): void {
//         this._subscript.unsubscribe();
//     }
// }