import {Component, Input} from "@angular/core";
import {IAuthGroupEmptyCheckListener, IFieldListener, IGroupEmptyCheckListener, ValidateResult} from "./field.listener";
import {SelectModal} from "glowworm";

@Component({
    selector: 'logcenter-search-deviceinfo',
    template: `
        <span [class.hidden]="!enabled">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'设备信息'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      [showSelect]="true"
                      [selectData]="options"
                      name="deviceInfoType">
            </gw-input>
        </span>
    `
})
export class DeviceInfoFieldComponent implements IFieldListener, IAuthGroupEmptyCheckListener, IGroupEmptyCheckListener {

    @Input() toolbar: any;
    value: SelectModal = {value: '', selectValue: ''};

    options: any[] = [];
    enabled: boolean = true;

    @Input('type')
    set type(type: string) {
        this.enabled = true;

        let mac = {text: 'MAC', id: 'mac'};
        let idfa = {text: 'IDFA', id: 'idfa'};
        let udid = {text: 'UDID', id: 'udid'};
        let ip = {text: 'IP', id: 'ip'};
        let idfv = {text: 'IDFV', id: 'idfv'};
        let dUniqueID = {text: 'palmDeviceId', id: 'dUniqueID'};

        if (['1', '2', '3', '4', '8', '7', '12', '13', '23', '6', '10', '9', '15', '14', '5', '16', '19', '22', '17', '20'].includes(type)) {
            this.options = [mac, idfa, udid, ip];
        } else if (['21', '11'].includes(type)) {
            this.options = [mac, idfa, idfv, udid, ip, dUniqueID];
        } else if (['24'].includes(type)) {
            this.options = [ip];
        } else if (['18', '25'].includes(type)) {
            this.options = [mac, idfa, udid];
        } else if (['26'].includes(type)) {
            this.options = [mac, idfa, ip];
        } else {
            this.enabled = false;
        }
        this.options = [{text: '请选择', id: ''}, ...this.options];
    }

    getValue(): object {
        if (!this.value) {
            return {
                selectValue: '',
                value: ''
            };
        } else {
            return {
                deviceInfoType: this.value.selectValue,
                deviceInfoText: this.value.value
            };
        }
    }

    setValue(params: any): void {
        this.value = {
            value: params['deviceInfoText'] || '',
            selectValue: params['deviceInfoType'] || ''
        }
    }

    validate(): ValidateResult {
        return {isValid: true};
    }

    isAuthGroupEmpty(): boolean {
        return this.value.value ? false : true;
    }

    isCheckAuthGroup(logType: string): boolean {
        return ['1', '2', '3', '4', '21', '11', '24', '18', '8', '7', '12', '13', '23', '6', '10', '9', '15', '14', '5', '16', '19', '22', '17'].includes(logType);
    }

    isGroupEmpty(): boolean {
        return this.value.value ? false : true;
    }

    isCheckGroup(logType: string): boolean {
        return ['20'].includes(logType);
    }
}
