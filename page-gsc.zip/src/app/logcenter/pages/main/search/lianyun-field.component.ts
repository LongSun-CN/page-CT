import {Component, EventEmitter, Input, OnInit, Output} from "@angular/core";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs/Observable";
import {IFieldListener, ValidateResult} from "./field.listener";
import {LogCenterService} from "../../../logcenter.service";
import {urlParam} from "../../../../shared/url-param.const";

@Component({
    selector: 'logcenter-search-lianyun',
    template: `
        <ng-container *ngIf="enabled">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'联运'"
                              [(ngModel)]="value"
                              [closeable]="true"
                              [data]="lianyun$ | async"
                              (onSave)="onSelected($event)"
                              name="operationLineId">
            </gw-single-select>
        </ng-container>
    `
})
export class LianYunFieldComponent implements IFieldListener, OnInit {

    @Input() toolbar: any;
    @Output() onSave: EventEmitter<any> = new EventEmitter<any>();

    lianyun$: Observable<any>;
    value: string;
    enabled: boolean;

    @Input() set type(type: string) {
        if (['1', '2', '3', '4', '21', '18', '8', '7', '12', '13', '6', '10', '9', '15', '14', '5', '16', '19', '17', '20', '22', '23', '24', '11','26','25'].includes(type)) {
            this.enabled = true;
        } else {
            this.enabled = false;
        }
    }

    constructor(private service: LogCenterService,
                private store$: Store<any>) {
    }

    ngOnInit(): void {
        this.lianyun$ = this.service.loadLianYun(urlParam.product, urlParam.language).map(result => {
            if (result.status == '0') {
                return result.data.map(item => {
                    return {
                        text: item.name,
                        id: item.oplId
                    }
                });
            }
            return [];
        });
    }

    getValue(): object {
        return {operationLineId: this.value};
    }

    setValue(params: any): void {
        this.value = params['operationLineId'];
        if (this.value) {
            this.lianyun$.take(1).subscribe((items: any[]) => {
                let value = items.filter((item: any) => item.id == this.value);
                value.length > 0 && this.onSelected(value[0]);
            });
        }
    }

    validate(): ValidateResult {
        return {isValid: true};
    }

    onSelected(lianyunId: string) {
        this.onSave.emit({
            lianyunId: lianyunId
        });
    }

    // onProductChange(productId: string) {
    //
    // }
}
