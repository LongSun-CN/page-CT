import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-status',
    template: `
        <ng-container *ngIf="['24'].includes(type)">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'状态'"
                              [data]="[{id: '0', text: '失败'},{id: '1', text: '成功'}]"
                              [(ngModel)]="value"
                              [closeable]="true"
                              name="status">
            </gw-single-select>
        </ng-container>
    `
})
export class StatusFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {status: this.value};
    }

    setValue(params: any): void {
        this.value = params['status'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}