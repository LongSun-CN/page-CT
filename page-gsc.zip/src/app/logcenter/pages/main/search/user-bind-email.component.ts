import {Component, Input} from "@angular/core";
import {IAuthGroupEmptyCheckListener, IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'user-bind-email',
    template: `
        <ng-container *ngIf="['25'].includes(type)">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'绑定邮箱'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      name="bingEmails">
            </gw-input>
        </ng-container>
    `
})
export class UserBindEmailComponent implements IFieldListener, IAuthGroupEmptyCheckListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {
          bingEmails: this.value
        }
    }

    setValue(params: any): void {
        this.value = params['bingEmails'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }

    isAuthGroupEmpty(): boolean {
        return this.value ? false : true;
    }

    isCheckAuthGroup(logType: string): boolean {
        return ['18'].includes(logType);
    }
}
