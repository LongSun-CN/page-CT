import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'user-close-status',
    template: `
        <ng-container *ngIf="['25'].includes(type)">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'封停状态'"
                              [data]="[{id: '0', text: '封停'},{id: '1', text: '正常'}]"
                              [(ngModel)]="value"
                              [closeable]="true"
                              name="closeState">
            </gw-single-select>
        </ng-container>
    `
})
export class UserCloseStatusComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {closeState: this.value};
    }

    setValue(params: any): void {
        this.value = params['closeState'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}
