import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'user-test-status',
    template: `
        <ng-container *ngIf="['25'].includes(type)">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'是否是测试用户'"
                              [data]="[{id: '0', text: '否'},{id: '1', text: '是'}]"
                              [(ngModel)]="value"
                              [closeable]="true"
                              name="isTestUser">
            </gw-single-select>
        </ng-container>
    `
})
export class UserTestStatusComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {isTestUser: this.value};
    }

    setValue(params: any): void {
        this.value = params['isTestUser'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}
