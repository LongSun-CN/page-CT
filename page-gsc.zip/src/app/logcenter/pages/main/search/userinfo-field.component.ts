import {Component, Input} from "@angular/core";
import {IAuthGroupEmptyCheckListener, IFieldListener, IGroupEmptyCheckListener, ValidateResult} from "./field.listener";
import {SelectModal} from "glowworm";

@Component({
    selector: 'logcenter-search-userinfo',
    template: `
        <span [class.hidden]="!enabled">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'用户信息'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      [showSelect]="true"
                      [selectData]="options"
                      name="userInfoType">
            </gw-input>
        </span>
    `
})
export class UserInfoFieldComponent implements IFieldListener, IAuthGroupEmptyCheckListener, IGroupEmptyCheckListener {

    @Input() toolbar: any;

    value: SelectModal = {value: '', selectValue: ''};

    options: any[] = [];
    enabled: boolean = true;

    @Input('type')
    set type(type: string) {
        this.enabled = true;

        let google = {text: '谷歌广告ID', id: 'googleleadsId'};
        let uname = {text: '用户名', id: 'userName'};
        let uid = {text: '用户ID', id: 'userId'};
        let rname = {text: '角色名', id: 'roleName'};
        let rid = {text: '角色ID', id: 'roleId'};

        if (['1'].includes(type)) {
            this.options = [google];
        } else if (['2', '18', '8', '7', '12', '13', '23', '6', '10', '9', '15', '14', '5', '16', '19', '22', '17', '20', '26'].includes(type)) {
            this.options = [uid, uname, rname, rid, google];
        } else if (['3', '4', '21', '11'].includes(type)) {
            this.options = [uid, uname, google];
        } else if (['24', '25'].includes(type)) {
            this.options = [uid, uname];
        } else {
            this.enabled = false;
        }
        this.options = [{text: '请选择', id: ''}, ...this.options];
    }

    getValue(): object {
        this.value = this.value || {selectValue: '', value: ''};
        return {
            userInfoType: this.value.selectValue,
            userInfoText: this.value.value
        };
    }

    setValue(params: any): void {
        this.value = {
            value: params['userInfoText'] || '',
            selectValue: params['userInfoType'] || ''
        }
    }

    validate(): ValidateResult {
        return {isValid: true};
    }

    isAuthGroupEmpty(): boolean {
        return this.value.value ? false : true;
    }

    isCheckAuthGroup(logType: string): boolean {
        return ['1', '2', '3', '4', '21', '11', '24', '18', '8', '7', '12', '13', '23', '6', '10', '9', '15', '14', '5', '16', '19', '22', '17'].includes(logType);
    }

    isGroupEmpty(): boolean {
        return this.value.value ? false : true;
    }

    isCheckGroup(logType: string): boolean {
        return ['20'].includes(logType);
    }
}
