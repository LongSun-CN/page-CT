import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-usertype',
    template: `
        <ng-container *ngIf="['24'].includes(type)">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'用户类型'"
                              [data]="[{id: '1', text: '论坛账户ID'},{id: '2', text: '游戏账户ID'},{id: '3', text: '手机号码'},{id: '4', text: '邮箱'},{id: '5', text: 'fb账户'}, {id: '6', text: '微信账户'}]"
                              [(ngModel)]="value"
                              [closeable]="true"
                              name="userType">
            </gw-single-select>
        </ng-container>
    `
})
export class UserTypeFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {userType: this.value};
    }

    setValue(params: any): void {
        this.value = params['userType'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}