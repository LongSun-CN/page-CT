import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-eventkey',
    template: `
        <ng-container *ngIf="['17'].includes(type)">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'事件Key'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      name="eventKey">
            </gw-input>
        </ng-container>
    `
})
export class EventKeyFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {
            eventKey: this.value
        }
    }

    setValue(params: any): void {
        this.value = params['eventKey'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}