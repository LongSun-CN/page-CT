import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-detail',
    template: `
        <ng-container *ngIf="['12','13','14'].includes(type)">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'明细'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      name="detail">
            </gw-input>
        </ng-container>
    `
})
export class DetailFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {
            detail: this.value
        }
    }

    setValue(params: any): void {
        this.value = params['detail'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}