import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";
import {DatepickerConfig} from "glowworm/lib/datepicker";

@Component({
    selector: 'logcenter-search-time',
    template: `
        <span [class.hidden]="_hidden">
            <gw-datepicker #gwcontrol
                           [toolbar]="toolbar"
                           [label]="'时间'"
                           [(ngModel)]="value"
                           [closeable]="false"
                           [options]="{singleDatePicker:false}"

                           name="time">
            </gw-datepicker>
        </span>
    `
})
export class TimeFieldComponent implements IFieldListener {

    _hidden: boolean;

    @Input() toolbar: any;
    value: any = {};

    private _type: string;
    private _today_start: any;
    private _today_end: any;

    constructor(private config: DatepickerConfig) {
        const format = this.config.locale.format, timePickerIncrement = this.config.timePickerIncrement;
        this._today_start = moment(moment().format('YYYY-MM-DD')).format(format);
        this._today_end = moment(this._today_start).add(1, 'days').subtract(timePickerIncrement, 'minute').format(format);
    }

    @Input() set type(type: string) {
        this._type = type;
        this._hidden = !['1', '2', '3', '4', '21', '18', '8', '7', '12', '13', '6', '10', '9', '15', '14', '5', '16', '19', '17', '20', '22', '23', '24', '11', '26', '25'].includes(type);
    }

    get type() {
        return this._type;
    }

    getValue(): object {
        this.value = this.value || {
                start: this._today_start,
                range: '今天',
                end: this._today_end
            };

        return {
            startTime: this.value.start,
            endTime: this.value.end,
            rangeTime: this.value.range
        }
    }

    setValue(params: any): void {
        if (params['startTime']) {
            this.value = {
                start: params['startTime'],
                end: params['startTime'],
                range: params['rangeTime']
            }
        } else {
            this.value = {
                start: this._today_start,
                range: '今天',
                end: this._today_end
            };
        }
    }

    validate(): ValidateResult {
        return {isValid: true};
        // if (this.type.includes('26')) {
        //     return {isValid: true};
        // }
        // return (!this.value || !this.value.start) ? {isValid: false, errorDesc: '请选择时间'} : {isValid: true};
    }
}
