import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
  selector: 'logcenter-search-order-type',
  template: `
    <ng-container *ngIf="['26'].includes(type)">
      <gw-single-select  #gwcontrol
                         [toolbar]="toolbar"
                         [label]="'类型'" 
                         [selectData]="[{id: '1', text: '正常订单'}, {id: '2', text: '异常订单'}, {id: '3', text: '测试订单'}, {id: '4', text: '补单订单'}]"
                         [(ngModel)]="value"
                         [closeable]="true"
                         [enabled]="true"
                         [showSelect]="true"
                         [data]="[
          {id: '1-1', text: '应用内计费发货'}, {id: '1-2', text: '应用外计费发货'}, {id: '1-3', text: '应用外计费不发货'}, {id: '1-11', text: '应用内重复回调发货'},
          {id: '2-4', text: '代充订单'}, {id: '2-10', text: '退费订单'}, {id: '2-5', text: '非法货币/地区支付'},
          {id: '3-6', text: '沙盒发货订单'}, {id: '3-7', text: '沙盒不发货订单'},
          {id: '4-8', text: '正常补单'}, {id: '4-9', text: '作弊补单'}
        ]"
                         [linkAge]="true"
      ></gw-single-select>
    </ng-container> 
  `
})
export class OrderTypeFieldComponent implements IFieldListener {

  @Input()
  toolbar: any;
  @Input()
  type: string;
  @Input()
  value: any = '';

  getValue(): object {
    let p = (this.value&&this.value.selectValue)||(this.value&&this.value.value&&this.value.value.substr(0,1))||'';
    let c = '';
    if(p===''){
        c='';
    }else if(this.value&&this.value.value){
        c= this.value.value.replace(p+'-','');
    }

    return {
      gameOrderType: p,
      gameOrderInfoType:c
    }
  }

  setValue(params: any): void {
    this.value = params['payStatus'] || '';
  }

  validate(): ValidateResult {
    return {isValid: true};
  }
}
