import {Component, EventEmitter, Input, OnInit, Output} from "@angular/core";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs/Observable";
import {IFieldListener, ValidateResult} from "./field.listener";
import {LogCenterService} from "../../../logcenter.service";
import {urlParam} from "../../../../shared/url-param.const";

@Component({
    selector: 'logcenter-search-gameserver',
    template: `
        <ng-container *ngIf="enabled">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'游戏服'"
                              [(ngModel)]="value"
                              [closeable]="true"
                              [data]="gameserver$ | async"
                              (onSave)="onSelected($event)"
                              name="server">
            </gw-single-select>
        </ng-container>
    `
})
export class GameServerFieldComponent implements IFieldListener, OnInit {

    @Input() toolbar: any;
    @Output() change: EventEmitter<any> = new EventEmitter<any>();

    gameserver$: Observable<any>;
    value: string;
    locale: string;
    enabled: boolean;

    @Input() set type(type: string) {
        if (['18', '8', '7', '12', '13', '6', '10', '9', '15', '14', '5', '23'].includes(type)) {
            this.enabled = true;
        } else {
            this.enabled = false;
        }
    }

    constructor(private service: LogCenterService,
                private store$: Store<any>) {
    }

    ngOnInit() {
        this.gameserver$ = this.service.loadGameServer(urlParam.product, urlParam.language).map(result => {
            if (result.status == '0') {
                return result.data.map(item => {
                    return {
                        text: item.name,
                        id: item.code
                    }
                });
            }
            return [];
        });
    }

    getValue(): object {
        return {server: this.value};
    }

    setValue(params: any): void {
        this.value = params['server'];
        if (this.value) {
            this.gameserver$.take(1).subscribe((items: any[]) => {
                let value = items.filter((item: any) => item.id == this.value);
                value.length > 0 && this.onSelected(value[0]);
            });
        }
    }

    validate(): ValidateResult {
        return {isValid: true};
    }

    onSelected(lianyun: any) {
        this.change.emit({
            lianyunId: lianyun.id
        });
    }

    // onProductChange(productId: string) {
    //     // if (!this.enabled) return;
    //
    //     this.value = '';
    //     this.productId = productId;
    //
    //     if (!productId) {
    //         this.setValue({});
    //         this.change.emit();
    //         return;
    //     }
    //
    //     this.store$.select('lan').take(1).map((item: any) => item.data[0].value).toPromise().then(localeId => {
    //         this.locale = localeId;
    //
    //     });
    // }
}