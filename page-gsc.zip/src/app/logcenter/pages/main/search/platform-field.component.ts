import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-platform',
    template: `
        <ng-container *ngIf="['16','19','22',25].includes(type)">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'平台'"
                              [(ngModel)]="value"
                              [closeable]="true"
                              [data]="[{text: '全部', id: ''},{text: 'IOS', id: '1'},{text: 'Android', id: '0'}]"
                              name="platform">
            </gw-single-select>
        </ng-container>
    `
})
export class PlatformFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {platform: this.value};
    }

    setValue(params: any): void {
        this.value = params['platform'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}
