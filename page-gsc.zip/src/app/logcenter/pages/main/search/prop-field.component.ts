import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-prop',
    template: `
        <ng-container *ngIf="['10','9'].includes(type)">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'属性标识'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      name="propKey">
            </gw-input>
        </ng-container>
    `
})
export class PropFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    @Input() value: string = '';

    getValue(): object {
        return {
            propKey: this.value
        }
    }

    setValue(params: any): void {
        this.value = params['propKey'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}