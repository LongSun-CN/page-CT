import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-queryfrom',
    template: `
        <ng-container
                *ngIf="['1','2','3','4','21','18','8','7','12','13','6','10','9','15','14','5','17','20','23','11'].includes(type)">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'日志来源'"
                              [(ngModel)]="value"
                              [closeable]="true"
                              [data]="[{text: '服务端', id: '0'},{text: '客户端', id: '1'}]"
                              name="queryFrom">
            </gw-single-select>
        </ng-container>
    `
})
export class QueryFromFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {queryFrom: this.value};
    }

    setValue(params: any): void {
        this.value = params['queryFrom'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}