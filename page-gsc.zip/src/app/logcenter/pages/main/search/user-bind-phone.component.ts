import {Component, Input} from "@angular/core";
import {IAuthGroupEmptyCheckListener, IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'user-bind-phone',
    template: `
        <ng-container *ngIf="['25'].includes(type)">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'绑定手机'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      name="bindPhones">
            </gw-input>
        </ng-container>
    `
})
export class UserBindPhoneComponent implements IFieldListener, IAuthGroupEmptyCheckListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {
          bindPhones: this.value
        }
    }

    setValue(params: any): void {
        this.value = params['bindPhones'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }

    isAuthGroupEmpty(): boolean {
        return this.value ? false : true;
    }

    isCheckAuthGroup(logType: string): boolean {
        return ['18'].includes(logType);
    }
}
