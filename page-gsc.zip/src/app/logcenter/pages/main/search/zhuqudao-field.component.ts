import {Component, Input} from "@angular/core";
import {Observable} from "rxjs/Observable";
import {IFieldListener, ValidateResult} from "./field.listener";
import {LogCenterService} from "../../../logcenter.service";
import {urlParam} from "../../../../shared/url-param.const";

@Component({
    selector: 'logcenter-search-zhuqudao',
    template: `
        <ng-container
                *ngIf="['1','2','3','4','21','18','8','7','12','13','6','10','9','15','14','5','16','19','17','20','22','23','24','11','25'].includes(type)">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'主渠道'"
                              [(ngModel)]="value"
                              [closeable]="true"
                              [data]="qudao$ | async"
                              name="parentchannelId">
            </gw-single-select>
        </ng-container>
    `
})
export class ZhuQuDaoFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;

    qudao$: Observable<any>;
    value: string;

    constructor(private service: LogCenterService) {
    }

    getValue(): object {
        return {parentchannelId: this.value};
    }

    setValue(params: any): void {
        this.value = params['parentchannelId'];
    }

    validate(): ValidateResult {
        return {isValid: true};
    }

    onZhuQuDaoChange(item: any) {
        this.setValue({});

        if (!item)return;

        this.qudao$ = this.service.loadZhuQuDao(urlParam.product, item.lianyunId).map(result => {
            if (result.status == '0') {
                return result.data.map(item => {
                    return {
                        id: item.cprId,
                        text: item.cprName
                    }
                });
            }
            return [];
        });
    }
}
