import {Component, Input} from "@angular/core";
import {IAuthGroupEmptyCheckListener, IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-ordernumber',
    template: `
        <ng-container *ngIf="['18'].includes(type)">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'订单号'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      name="orderno">
            </gw-input>
        </ng-container>
    `
})
export class OrderNumberFieldComponent implements IFieldListener, IAuthGroupEmptyCheckListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {
            orderId: this.value
        }
    }

    setValue(params: any): void {
        this.value = params['orderId'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }

    isAuthGroupEmpty(): boolean {
        return this.value ? false : true;
    }

    isCheckAuthGroup(logType: string): boolean {
        return ['18'].includes(logType);
    }
}
