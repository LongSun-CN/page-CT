import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-keyword',
    template: `
        <ng-container *ngIf="['26','25'].includes(type)">
            <gw-input #gwcontrol
                      [toolbar]="toolbar"
                      [label]="'关键字'"
                      [(ngModel)]="value"
                      [closeable]="true"
                      name="propKey">
            </gw-input>
        </ng-container>
    `
})
export class KeyWordFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    @Input() value: string = '';

    getValue(): object {
        return {
            myKeywords: this.value
        }
    }

    setValue(params: any): void {
        this.value = params['myKeywords'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}
