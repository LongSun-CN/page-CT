import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-isrebuildorder',
    template: `
        <ng-container *ngIf="false"> 
          <gw-single-select #gwcontrol
                            [toolbar]="toolbar"
                            [label]="'是否补单'"
                            [(ngModel)]="value"
                            [closeable]="true"
                            [data]="[{text: '是', id: '1'},{text: '否', id: '0'}]"
                            name="advertiserTo">
          </gw-single-select>
        </ng-container>
    `
})
export class isOrderRebuildFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    @Input() value: string = '';

    getValue(): object {
        return {
          isRepair: this.value
        }
    }

    setValue(params: any): void {
        this.value = params['isRepair'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}
