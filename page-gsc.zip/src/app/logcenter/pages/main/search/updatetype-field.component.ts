import {Component, Input} from "@angular/core";
import {IFieldListener, ValidateResult} from "./field.listener";

@Component({
    selector: 'logcenter-search-updatetype',
    template: `
        <ng-container *ngIf="['6','23'].includes(type)">
            <gw-single-select #gwcontrol
                              [toolbar]="toolbar"
                              [label]="'变更类型'"
                              [data]="[{id: '0', text: '消耗'}, {id: '1', text: '获得'}]"
                              [(ngModel)]="value"
                              [closeable]="true"
                              name="updateType">
            </gw-single-select>
        </ng-container>
    `
})
export class UpdateTypeFieldComponent implements IFieldListener {

    @Input() toolbar: any;
    @Input() type: string;
    value: string = '';

    getValue(): object {
        return {updateType: this.value};
    }

    setValue(params: any): void {
        this.value = params['updateType'] || '';
    }

    validate(): ValidateResult {
        return {isValid: true};
    }
}