import {OurpalmTable} from "ngx-ourpalm-table";
/**
 1，行双击事件，跳转至的详情页和当前数据类型有关系；目前存在三种详情页分别对应如下：
 用户数据：双击时跳转至账户详情页（争光提供）；
 订单数据：双击时跳转至订单详情页（赵伟提供）；
 角色数据：双击时跳转至角色详情页（目前未开发，可以先跳转至日志详情页，后续下周单独提供出来）；
 其他    ：双击时跳转至日志详情页；

 2，行上的右键菜单

 --详情
 --用户详情（单行数据可用，行中存在用户ID列，且值不为空时可显示）
 --角色详情（单行数据可用，行中存在角色ID列，且值不为空时可显示）
 --订单详情（单行数据可用，行中存在订单ID列，且值不为空时可显示）

 --封停
 --角色封停（单行多行数据都可用，行中存在角色ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 --用户封停（单行多行数据都可用，行中存在用户ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 --设备封停（单行多行数据都可用，行中存在MAC或IDFA时且值不为空时可显示；若多行数据只要一列符合即可显示）
 --IP封停（单行多行数据都可用，行中存在IP列，且值不为空时可显示；若多行数据只要一列符合即可显示）

 --禁言
 --角色禁言（单行多行数据都可用，行中存在角色ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 --用户禁言（单行多行数据都可用，行中存在用户ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 --设备禁言（单行多行数据都可用，行中存在MAC或IDFA时且值不为空时可显示；若多行数据只要一列符合即可显示）
 --IP禁言（单行多行数据都可用，行中存在IP列，且值不为空时可显示；若多行数据只要一列符合即可显示）

 --重置密码（单行数据可用，行中存在用户ID列和用户系统列，且值都不为空时并且用户系统为掌趣官网用户时可显示）

 --绑定账号（单行数据可用，行中存在用户ID列和是否游客列，且值都不为空时并且属于游客用户时可显示）

 --标记测试号（单行多行数据都可用，行中存在用户ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）

 --补单（单行存在订单号列和订单状态列和订单类型列，且都不为空，并且订单状态符合需要补单的状态时可以显示）

 --重新发货（单行存在订单号列和订单状态列和订单类型列，且都不为空，并且订单状态符合需要可以重新发货的状态时可以显示）

 --discover
 --discover日志
 --按角色（单行数据可用，行中存在角色ID列，且值不为空时可显示）
 --按账户（单行数据可用，行中存在用户ID列，且值不为空时可显示）
 --按MAC（单行数据可用，行中存在MAC列，且值不为空时可显示）
 --按IDFA（单行数据可用，行中存在IDFA列，且值不为空时可显示）
 --按IP（单行数据可用，行中存在IP列，且值不为空时可显示）
 --discover订单
 --按角色（单行数据可用，行中存在角色ID列，且值不为空时可显示）
 --按账户（单行数据可用，行中存在用户ID列，且值不为空时可显示）
 --按MAC（单行数据可用，行中存在MAC列，且值不为空时可显示）
 --按IDFA（单行数据可用，行中存在IDFA列，且值不为空时可显示）
 --按IP（单行数据可用，行中存在IP列，且值不为空时可显示）
 */

/**
 * 详情 --> 用户详情（单行数据可用，行中存在用户ID列，且值不为空时可显示）
 */
export function isShowUserDetail(table: OurpalmTable): boolean {
    return !!(table.getSelectedRows().length == 1 && table.getSelectedRows()[0].userId && table.getSelectedRows()[0].userId !== '-');
}

/**
 * 详情 --> 角色详情（单行数据可用，行中存在角色ID列，且值不为空时可显示）
 */
export function isShowRoleDetail(table: OurpalmTable): boolean {
    return !!(table.getSelectedRows().length == 1 && table.getSelectedRows()[0].roleId && table.getSelectedRows()[0].roleId !== '-');
}

/**
 * 详情 --> 订单详情（单行数据可用，行中存在订单ID列，且值不为空时可显示）
 */
export function isShowOrderDetail(table: OurpalmTable): boolean {
    return !!(table.getSelectedRows().length == 1 && table.getSelectedRows()[0].orderId && table.getSelectedRows()[0].orderId !== '-');
}

/**
 * 封停 --> 角色封停（单行多行数据都可用，行中存在角色ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 */
export function isShowRoleFengTing(table: OurpalmTable): boolean {
    return table.getSelectedRows().filter((row) => !!row.roleId && row.roleId !== '-').length > 0;
}

/**
 * 封停 --> 用户封停（单行多行数据都可用，行中存在用户ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 */
export function isShowUserFengTing(table: OurpalmTable): boolean {
    return table.getSelectedRows().filter((row) => !!row.userId && row.userId !== '-').length > 0;
}

/**
 * 封停 --> 设备封停（单行多行数据都可用，行中存在MAC或IDFA时且值不为空时可显示；若多行数据只要一列符合即可显示）
 */
export function isShowDeviceFengTing(table: OurpalmTable): boolean {
    return table.getSelectedRows().filter((row) => (!!row.mac && row.mac !== '-') || (!!row.idfa && row.idfa !== '-')).length > 0;
}

/**
 * 封停 --> IP封停（单行多行数据都可用，行中存在IP列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 */
export function isShowIpFengTing(table: OurpalmTable): boolean {
    return table.getSelectedRows().filter((row) => !!row.ip && row.ip !== '-').length > 0;
}

/**
 * 禁言 --> 角色禁言（单行多行数据都可用，行中存在角色ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 */
export function isShowRoleJingYan(table: OurpalmTable): boolean {
    return table.getSelectedRows().filter((row) => !!row.roleId && row.roleId !== '-').length > 0;
}

/**
 * 禁言 --> 用户禁言（单行多行数据都可用，行中存在用户ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 */
export function isShowUserJingYan(table: OurpalmTable): boolean {
    return table.getSelectedRows().filter((row) => !!row.userId && row.userId !== '-').length > 0;
}

/**
 * 禁言 --> 设备禁言（单行多行数据都可用，行中存在MAC或IDFA时且值不为空时可显示；若多行数据只要一列符合即可显示）
 */
export function isShowDeviceJingYan(table: OurpalmTable): boolean {
    return table.getSelectedRows().filter((row) => (!!row.mac && row.mac !== '-') || (!!row.idfa && row.idfa !== '-')).length > 0;
}

/**
 * 禁言 --> IP禁言（单行多行数据都可用，行中存在IP列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 */
export function isShowIpJingYan(table: OurpalmTable): boolean {
    return table.getSelectedRows().filter((row) => !!row.ip && row.ip).length > 0;
}

/**
 * 重置密码（单行数据可用，行中存在用户ID列和用户系统列，且值都不为空时并且用户系统为掌趣官网用户时可显示）
 */
export function isShowResetPassword(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if ((row.userId && row.userPlatformId === '0001')) {
            return true;
        }
    }
    return false;
}

/**
 * 绑定账号（单行数据可用，行中存在用户ID列和是否游客列，且值都不为空时并且属于游客用户时可显示）
 */
export function isShowBindAccount(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if ((row.userId && row.touristStatus === '1')) {
            return true;
        }
    }
    return false;
}

/**
 * 标记测试号（单行多行数据都可用，行中存在用户ID列，且值不为空时可显示；若多行数据只要一列符合即可显示）
 */
export function isShowMarkAsTestAccount(table: OurpalmTable): boolean {
    return table.getSelectedRows().filter((row) => !!row.userId && row.userId !== '-').length > 0;
}

/**
 * 补单（单行存在订单号列和订单状态列和订单类型列，且都不为空，并且订单状态符合需要补单的状态时可以显示）
 * 订单列：orderId  订单状态: orderStatus        订单类型：deliverReset  返利状态: fillStatus
 */
export function isShowBuDan(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.orderId && (row.orderStatus == '-1' || row.orderStatus == '0' || row.deliverReset == '3000' || row.deliverReset == '3003')
            && row.fillStatus == '0' && row.deliverReset != '1004' && row.deliverReset != '3001'
            && row.deliverReset != '1005' && row.deliverReset != '3002') {
            // 补单操作
            return true;
        }
    }
    return false;
}

/**
 * 重新发货（单行存在订单号列和订单状态列和订单类型列，且都不为空，并且订单状态符合需要可以重新发货的状态时可以显示）
 */
export function isShowChongXinFaHuo(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.status == '1' && (row.deliverreset != '3003' || row.deliverreset != '3000')) {
            return true;
        }
    }
    return false;
}

/**
 * discover日志 --> 按角色（单行数据可用，行中存在角色ID列，且值不为空时可显示）
 */
export function isShowRoleLog(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.roleId) {
            return true;
        }
    }
    return false;
}

/**
 * discover日志 --> 按账户（单行数据可用，行中存在用户ID列，且值不为空时可显示）
 */
export function isShowAccountLog(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.userId) {
            return true;
        }
    }
    return false;
}

/**
 * discover日志 --> 按MAC（单行数据可用，行中存在MAC列，且值不为空时可显示）
 */
export function isShowMacLog(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.mac) {
            return true;
        }
    }
    return false;
}

/**
 * discover日志 --> 按IDFA（单行数据可用，行中存在IDFA列，且值不为空时可显示）
 */
export function isShowIdfaLog(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.idfa) {
            return true;
        }
    }
    return false;
}

/**
 * discover日志 --> 按IP（单行数据可用，行中存在IP列，且值不为空时可显示）
 */
export function isShowIpLog(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.ip) {
            return true;
        }
    }
    return false;
}

/**
 * discover订单 --> 按角色（单行数据可用，行中存在角色ID列，且值不为空时可显示）
 */
export function isShowRoleOrder(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.roleId) {
            return true;
        }
    }
    return false;
}

/**
 * discover订单 --> 按账户（单行数据可用，行中存在用户ID列，且值不为空时可显示）
 */
export function isShowAccountOrder(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.userId) {
            return true;
        }
    }
    return false;
}

/**
 * discover订单 --> 按MAC（单行数据可用，行中存在MAC列，且值不为空时可显示）
 */
export function isShowMacOrder(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.mac) {
            return true;
        }
    }
    return false;
}

/**
 * discover订单 --> 按IDFA（单行数据可用，行中存在IDFA列，且值不为空时可显示）
 */
export function isShowIdfaOrder(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.idfa) {
            return true;
        }
    }
    return false;
}

/**
 * discover订单 --> 按IP（单行数据可用，行中存在IP列，且值不为空时可显示）
 */
export function isShowIpOrder(table: OurpalmTable): boolean {
    if (table.getSelectedRows().length == 1) {
        let row: any = table.getSelectedRows()[0];
        if (row.ip) {
            return true;
        }
    }
    return false;
}