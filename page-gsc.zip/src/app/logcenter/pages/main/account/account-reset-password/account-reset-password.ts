import {Component, OnInit, Output, TemplateRef, ViewChild} from "@angular/core";
import {BsModalRef, BsModalService} from "ngx-bootstrap";
import {AccountManageService} from "../account-manage.service";
import {HttpService} from "../../../../../shared/services/httpx.service";
import {ToastService} from "../../../../../shared/services/toast.service";
import {urlParam} from "../../../../../shared/url-param.const";

@Component({
    selector: 'account-reset-password',
    template:`
        <ng-template #template>
            <div class="modal-header">
                <h4 class="modal-title pull-left">{{'重置密码' | translate}}</h4>
                <button type="button" class="close pull-right" aria-label="Close" (click)="modalRef.hide()">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-horizontal">
                    <div class="form-group">
                        <label class="col-sm-2 control-label">
                            {{'用户ID'| translate}}
                        </label>
                        <input class="col-sm-8" [value]="userId" readonly/>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">
                            {{'发送方式'| translate}}
                        </label>
                        <select class="custom-select col-sm-5" [(ngModel)]="sendType">
                            <option value="1">{{'手机' | translate}}</option>
                            <option value="2">{{'邮箱' | translate}}</option>
                        </select>
                    </div>
                    <div class="form-group"   *ngIf="sendType == 1">
                        <label class="col-sm-2 control-label">
                            {{'手机号'| translate}}
                        </label>
                        <input [(ngModel)]="sendPhone" type="tel" class="col-sm-5" placeholder="{{'目前只支持大陆手机号'|translate}}">
                    </div>
                    <div class="form-group"   *ngIf="sendType == 2">
                        <label class="col-sm-2 control-label" >
                            {{'邮箱'| translate}}
                        </label>
                        <input [(ngModel)]="sendEmail" type="email" class="col-sm-5" placeholder="{{'请输入正确邮箱'|translate}}">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary btn-md" (click)="resetPassword()">{{'修改密码'|translate}}</button>
                <button type="button" class="btn btn-default btn-md" (click)="modalRef.hide()">{{'取消'|translate}}</button>
            </div>
        </ng-template>`,
    styles:['']
})
export class AccountResetPasswordComponent implements OnInit {
    @Output()
    modalRef: BsModalRef;
    @ViewChild('template', {read: TemplateRef})
    template: TemplateRef<any>;

    sendType:number;
    sendPhone:string;
    sendEmail:string;
    userId:string;

    constructor(private modalService: BsModalService,
                private service:AccountManageService,
                private http:HttpService,
                private toast:ToastService) {
    }
    ngOnInit() {
        this.sendType =1
    }
    show(row:any) {
        if (row.bindMobileNum && row.bindMobileNum!= ''){
            this.sendType = 1;
            this.sendPhone = row.bindMobileNum;
        }else if(row.bindEmailAddress && row.bindEmailAddress != ''){
            this.sendType = 2;
            this.sendEmail = row.bindEmailAddress;
        }
        this.userId = row.userId;
        this.modalRef = this.modalService.show(this.template, {class: 'modal-md'});
    }
    resetPassword(){
        let param ={
            localeId: urlParam.language,
            productId: urlParam.product,
            sendType:this.sendType,
            value:this.sendType == 1 ? this.sendPhone : this.sendEmail ,
            userId:this.userId
        };
        if(this.sendType == 1 && (this.sendPhone == '' || !!!this.sendPhone)){
            this.toast.translate('warning','手机号不能为空');
            return false
        }
        if(this.sendType == 2 && (this.sendEmail == '' || !!!this.sendPhone)){
            this.toast.translate('warning','邮箱号不能为空');
            return false
        }
        this.service.resetPassword(param).then(res => {
            if(res.status == '0'){
                this.toast.translate('success','修改密码成功');
                this.modalRef.hide()
            }else {
                this.toast.translate('error',res.desc)
            }
        })

    }
}