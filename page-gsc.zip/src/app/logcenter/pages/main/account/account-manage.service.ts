import {Injectable} from "@angular/core";
import {HttpService} from "../../../../shared/services/httpx.service";
import {Store} from "@ngrx/store";
import {ToastService} from "../../../../shared/services/toast.service";
import {TranslateService} from "@ngx-translate/core";
import {DateFormatterPipe} from "../../../../widgets/ourpalm-pipes/date-formatter.pipe";
import {urlParam} from "../../../../shared/url-param.const";
import {environment} from "../../../../../environments/environment";

@Injectable()
export class AccountManageService {

    constructor(private http: HttpService,
                private $store: Store<any>,
                // private lanservice: LanProTypeService,
                private toast: ToastService,
                private translate: TranslateService,
                private dateformatter: DateFormatterPipe
    ) {}

    getAccountInfo(row: any): Promise<any> {
        let param: { [index: string]: any } = {
            localeId: urlParam.language,
            productId: urlParam.product,
            solrId: `${urlParam.language}-${urlParam.product}-${row.userId}`
        };
        return this.http.get(environment.getUrl('gsc/userAccount/getDetailUserInfo.htm'), param)
            .map(res => res.json())
            .toPromise();
    }

    getAccountList(row: any): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            this.getAccountInfo(row).then((accountInfo) => {
                let initInfo: any = [
                    {
                        name: '用户信息',
                        type: 'form',
                        fields: [
                            {
                                name: '用户ID',
                                key: 'userId',
                                value: ''
                            },
                            {
                                name: '用户名',
                                key: 'userName',
                                value: ''
                            },
                            {
                                name: '用户系统',
                                key: 'userPlatformName',
                                value: ''
                            },
                            {
                                name: '第三方用户',
                                key: 'originalUsername',
                                value: ''
                            },
                            {
                                name: '首登时间',
                                key: 'createTime',
                                value: ''
                            },
                            {
                                name: '封停状态',
                                key: 'closeStatusName',
                                value: ''
                            },
                            {
                                name: '测试用户',
                                key: 'isTestUser',
                                value: ''
                            },
                            {
                                name: '绑定手机',
                                key: 'bindMobileNum',
                                value: ''
                            },
                            {
                                name: '绑定手机时间',
                                key: 'bindMobileCreateTime',
                                value: ''
                            },
                            {
                                name: '绑定邮箱',
                                key: 'bindEmailAddress',
                                value: ''
                            },
                            {
                                name: '绑定邮箱时间',
                                key: 'bindMobileCreateTime',
                                value: ''
                            },
                            {
                                name: '身份认证',
                                key: 'idNum',
                                value: ''
                            },
                            {
                                name: '身份认证时间',
                                key: 'idNumUpdateTime',
                                value: ''
                            },
                        ]
                    },
                    {
                        name: '设备信息',
                        type: 'form',
                        fields: [
                            {
                                name: 'MAC',
                                key: 'mac',
                                value: ''
                            },
                            {
                                name: 'IDFA',
                                key: 'idfa',
                                value: ''
                            },
                            {
                                name: 'UDID',
                                key: 'deviceUdid',
                                value: ''
                            },
                            {
                                name: '谷歌广告ID',
                                key: 'googleleadsId',
                                value: ''
                            },
                            {
                                name: 'palmDeviceId',
                                key: 'devicePlatformId',
                                value: ''
                            },
                            {
                                name: 'IP',
                                key: 'ip',
                                value: ''
                            },
                            {
                                name: '系统版本',
                                key: 'deviceSystemVersion',
                                value: ''
                            },
                            {
                                name: '终端分辨率',
                                key: 'devicereSolution',
                                value: ''
                            },
                            {
                                name: 'IMEI',
                                key: 'imei',
                                value: ''
                            },
                            {
                                name: '厂商',
                                key: 'deviceManufacturer',
                                value: ''
                            },
                            {
                                name: '终端型号',
                                key: 'deviceName',
                                value: ''
                            },
                            {
                                name: '运营商',
                                key: 'serviceOperator',
                                value: ''
                            },
                        ]
                    },
                    {
                        name: '产品信息',
                        type: 'form',
                        fields: [
                            {
                                name: '联运',
                                key: 'operationLineName',
                                value: ''
                            },
                            {
                                name: '主渠道',
                                key: 'channelName',
                                value: ''
                            },
                            {
                                name: '子渠道',
                                key: 'subChannelName',
                                value: ''
                            },
                            {
                                name: '语言',
                                key: 'localeName',
                                value: ''
                            },
                            {
                                name: 'SDK版本',
                                key: 'sdkVersion',
                                value: ''
                            },
                            {
                                name: '游戏版本',
                                key: 'gameVersion',
                                value: ''
                            },
                        ]
                    },
                ];
                initInfo.forEach(item => {
                    item.type === 'form' && item.fields.forEach(li => {
                        li.value = accountInfo.data[li.key] || ''
                    })
                });
                resolve({initInfo, accountInfo})
            })
        })

    };

    resetPassword(param: any): Promise<any> {
        return this.http.get(environment.getUrl('gsc/userAccount/resetPassword.htm'), param)
            .map(res => res.json())
            .toPromise()
    }
    bindAccount(param:any): Promise<any>{
        return this.http.get(environment.getUrl('gsc/userAccount/bindAccount.htm'),param)
            .map(res => res.json())
            .toPromise()
    }
    markTest(param:any): Promise<any>{
        return this.http.get(environment.getUrl('gsc/userAccount/addTestAccount.htm'),param)
            .map(res => res.json())
            .toPromise()
    }
    // 得到用户信息
    getDetailRoleInfo(param:any):Promise<any>{
        param.localeId =  urlParam.language;
        param.productId = urlParam.product;
        return this.http.post(environment.getUrl('gsc/userAccount/getDetailRoleInfo.htm'),param)
            .map(res => res.json())
            .toPromise()
    }
    // 封停或禁言
    roleBanOrClose(param:any):Promise<any>{
        param.localeId =  urlParam.language;
        param.productId = urlParam.product;
        return this.http.post(environment.getUrl('gsc/userAccount/roleBanOrClose.htm'),param)
            .map(res => res.json())
            .toPromise()
    }
}
