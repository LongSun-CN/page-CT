import {Component, OnInit, Output, TemplateRef, ViewChild} from "@angular/core";
import {AccountManageService} from "../account-manage.service";
import {BsModalRef, BsModalService} from "ngx-bootstrap";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {HttpService} from "../../../../../shared/services/httpx.service";
import {ToastService} from "../../../../../shared/services/toast.service";
import {environment} from "../../../../../../environments/environment";
import {urlParam} from "../../../../../shared/url-param.const";

@Component({
  selector: 'account-manage-modal-detail',
  templateUrl: 'account-manage-modal-detail.component.html',
  styleUrls: ['./account-manage-modal-detail.component.css']
})
export class AccountManageModalDetailComponent implements OnInit {
  accountInfo: any;

  @Output()
  modalRef: BsModalRef;

  @ViewChild('template', {read: TemplateRef})
  template: TemplateRef<any>;
  constructor(private service: AccountManageService,
              private modalService: BsModalService,
              private http: HttpService,
              private toast:ToastService
              ) {
  }

  groups: any[];
  releaseTable:OurpalmTable = new OurpalmTable({
  customClass:'nowrap-table',
  autoLoadData:false,
  showSettingBtn:false,
  columns:[
    {
      header:'用户ID',
      field:'userId',
      show:true
    },
    {
      header:'用户系统',
      field:'userPlatformName',
      show:true
    },
    {
      header:'首登时间',
      field:'createTime',
      show:true
    },
  ],
  pageSize:100,
  pageList:[50,100,200],
})
  handlerTable: OurpalmTable = new OurpalmTable({
    customClass: 'nowrap-table-order-handler',
    autoLoadData: false,
    showSettingBtn: false,
    pageSize: 500,
    pageList: [500, 1000],
    columns: [
      {
        field: 'createUserName',
        header: '操作人',
        show: true
      },
      {
        field: 'createTime',
        header: '操作时间',
        show: true

      },
      {
        field: 'logType',
        header: '日志类型',
        show: true

      },
      {
        field: 'reason',
        header: '操作原因',
        show: true

      },
      {
        field: 'result',
        header: '操作结果',
        show: true

      }
    ],

  });


  ngOnInit() {

  }
  show(obj:any){
    this.handlerTable.setOptions(this.getLoadData('gsc/optLog/getOptLogList.htm',{"userId":obj.userId}));
    this.service.getAccountList(obj).then((resultInfo) => {
      this.accountInfo =resultInfo.initInfo;
      this.modalRef = this.modalService.show(this.template,{class: 'modal-lg'});
      this.releaseTable.setOptions(this.getLoadData('gsc/userAccount/getRelateUserInfoByIds.htm',{'bindIds':resultInfo.accountInfo.data.bindingSolrIds}))
    });

    this.handlerTable.firstPage();
    this.releaseTable.firstPage()
  }


  getLoadData(url:string,row:any){
    return {
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        let param = {localeId: urlParam.language, ...table.getOptions(), ...row};
        setTimeout(() => {
          this.http.get(environment.getUrl(url), param)
              .map(res => res.json())
              .subscribe(result => {
                if (result.status === '0') {
                  callback({
                    currentPage: param.currentPage,
                    pageSize: param.pageSize,
                    total: result.data.length || 0,
                    rows: (result.data) || []
                  })
                }
              })
        });
      }
    }
  }
}
