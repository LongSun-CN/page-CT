import { Component, OnInit ,Output,ViewChild,TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from "ngx-bootstrap";
import {AccountManageService} from '../account-manage.service';
import {ToastService} from '../../../../../shared/services/toast.service';
import {urlParam} from "../../../../../shared/url-param.const";

@Component({
    selector: 'account-manage-mark-test',
    template: `
    <ng-template #template>
        <div class="modal-header">
            <h4 class="modal-title pull-left">{{'标记测试账号' | translate}}</h4>
            <button type="button" class="close pull-right" aria-label="Close" (click)="modalRef.hide()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="form-horizontal">
                <div class="form-group">
                    <label class="col-sm-2 control-label">
                        {{'开始时间' | translate}}
                    </label>
                    <input class="col-sm-8" [(ngModel)]="startTime" ourpalm-daterangepicker 
                           options='{singleDatePicker:true,timePickerIncrement :1,locale:{ format: "YYYY-MM-DD HH:mm:ss"}}'  
                           readonly   placeholder="请选择绑定时间"  />
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary btn-md"  (click)="markTest()">{{'标记'|translate}}</button>
            <button type="button" class="btn btn-default btn-md" (click)="modalRef.hide()">{{'取消'|translate}}</button>
        </div>
    </ng-template>
    `,
    styles: ['']
})
export class AccountManageMarkTest implements OnInit{
    @Output()
    modalRef: BsModalRef;
    @ViewChild('template', {read: TemplateRef})
    template: TemplateRef<any>;

    userIds:any[];
    startTime:string;
    constructor (private modalService: BsModalService,
                 private service:AccountManageService,
                 private toast:ToastService){

    }
    ngOnInit(){
        this.userIds = [];
    }
    // 支持选择多行  同时标记
    show(rows){
        this.startTime = "";
        this.userIds = [];
        rows.map(row => {
            this.userIds.push(row.userId)
        });
        console.log(this.userIds);
        this.modalRef = this.modalService.show(this.template, {class: 'modal-md'});
    }
    markTest(){
        let param={
            localeId: urlParam.language,
            userIds:this.userIds,
            startTime:this.startTime
        };
        console.log(param);
        this.service.markTest(param).then(res =>{
            if(res.status == '0'){
                this.toast.translate('success','标记为测试账号成功');
                this.modalRef.hide()
            }
        })

    }
}