import {AccountManageModalDetailComponent} from "./account-manage-modal-detail/account-manage-modal-detail.component";
import {AccountResetPasswordComponent} from "./account-reset-password/account-reset-password";
import {AccountManageMarkTest} from "./account-manage-mark-test/account-manage-mark-test.component"
import {AccountManageBindAccount} from './account-manage-bind-account/account-manage-bind-account.component'
import {AccountManageBlockAccount} from "./account-manage-block-account/account-manage-block-account.component"
export const accountManageComponent = [
    AccountManageModalDetailComponent,
    AccountResetPasswordComponent,
    AccountManageMarkTest,
    AccountManageBindAccount,
    AccountManageBlockAccount
];
