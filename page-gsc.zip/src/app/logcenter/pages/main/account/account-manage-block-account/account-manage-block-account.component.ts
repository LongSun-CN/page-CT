import { Component, OnInit ,Output,ViewChild,TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from "ngx-bootstrap";
import {AccountManageService} from '../account-manage.service';
import {ToastService} from '../../../../../shared/services/toast.service';
import {environment} from "../../../../../../environments/environment";
import { FileSelectDirective, FileDropDirective, FileUploader } from 'ng2-file-upload';

@Component({
    selector: 'account-manage-block-account',
    templateUrl: 'account-manage-block-account.component.html',
    styles: [`
    .block-role-id,.block-role-name {
        padding: 0 5px;
        min-width: 300px;
    }
        table thead tr th{
            text-align: center;
            border-left:1px solid #fff;
        }
        textarea{
            resize: vertical;
        }
    `]
})

export class AccountManageBlockAccount implements OnInit{
    @Output()
    modalRef: BsModalRef;
    @ViewChild('template', {read: TemplateRef})
    template: TemplateRef<any>;

    // 发送到服务器进行请求的 id
    targetIds:any[];
    // 封停 类型  0;角色 1.用户 2.设备 3.地址
    blockType:number;
    roleIdList:any[];
    reason:string | number;
    limitUnit: string | number = 1;
    limitValue:string | number = "";
    imageList:any =[];
    // 操作类型  1 禁言 3  封停
    operateType  = "";
    sendRoleIdList:any[] = [];
    // 文件上传的地址
    public uploader:FileUploader;

    constructor (private modalService: BsModalService,
                 private service:AccountManageService,
                 private toast:ToastService,
){
        this.uploader = new FileUploader({
            url:environment.getUrl('gsc/optLog/uploadLogImageFile.htm'),
            queueLimit:5,
            autoUpload:true
        });
        // 对上传失败的处理
        this.uploader.onSuccessItem = function(fileItem,response){
            let responseData = JSON.parse(response);
            if(responseData.status == 1){
                fileItem.isSuccess = false;
                fileItem.isUploaded = false;
                fileItem.isError = true;
            }else{
                fileItem.url = responseData.data.fileName
            }
        }
    }
    ngOnInit(){
        this.targetIds = [];
    }
    // 选中的事件  是否选中全部
    private isCheckedAll(){
        return this.roleIdList.every(role => role._ischecked)
    }
    // 选中事件  选中全部 全不选
    private toggleSelectAll(ev){
        this.roleIdList.forEach(role =>{
            role._ischecked = ev.target.checked;
        })
    }

    // 封停或者禁言
    roleBanOrClose(){
        if(this.limitValue == ''){
            this.toast.translate('warning','请填写封停时间');
            return false
        }
        this.sendRoleIdList = [];
        this.roleIdList.forEach(item => {
            if (item._ischecked){
                this.sendRoleIdList.push(item.roleId)
            }
        });
        if (this.sendRoleIdList.length == 0){
            this.toast.translate('warning','请选择封停账号');
            return false
        }
        this.uploader.queue.forEach(item => {
            if(item.isUploaded && item.isSuccess){
                this.imageList.push(item.url)
            }
        });
        let params= {
            roleIds:this.sendRoleIdList,
            operateType:this.operateType,
            reason:this.reason,
            limitUnit:this.limitUnit,
            limitValue:this.limitValue,
            logImageNames:this.imageList
        };
        this.service.roleBanOrClose(params).then(res => {
            if (res.status == '0') {
                this.modalRef.hide();
                this.toast.translate('success', '操作成功')
            }
        })
    }
    // operateType  1 禁言 3  封停 type 0;角色 1.用户 2.设备 3.地址

    show(operateType,type,rows:any){
        // 初始化
        this.targetIds = [];
        this.reason = "";
        this.uploader.clearQueue();
        this.imageList = [];
        this.blockType = type;
        this.operateType = operateType;

        switch (this.blockType) {
            // 用户封停  用户禁言
            case 0:
                rows.map(row => {
                    // roleId  有问题 需要处理一下
                    let list = row.roleId.trim().split(" ");
                    this.targetIds = this.targetIds.concat(list);
                });
                this.showList({roleIds:this.targetIds});
                break;
            //    账号封停  账号禁言
            case 1:
                rows.map(row => {
                    this.targetIds.push(row.userId)
                });
                this.showList({userIds:this.targetIds});
                break;

        }
    }
    // 显示模板
    private showList(param){
        this.service.getDetailRoleInfo(param).then(res => {
            if(res.status == '0'){
                this.roleIdList = res.data;
                this.roleIdList.map( item =>{
                    item._ischecked = false;
                });
                this.modalRef = this.modalService.show(this.template, {class: 'modal-lg'});
            }
        })
    }
}