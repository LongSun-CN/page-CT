import { Component, OnInit ,Output,ViewChild,TemplateRef} from '@angular/core';
import {BsModalRef, BsModalService} from "ngx-bootstrap";
import {AccountManageService} from '../account-manage.service';
import {ToastService} from '../../../../../shared/services/toast.service';
import {urlParam} from "../../../../../shared/url-param.const";

@Component({
    selector: 'account-manage-bind-account',
    template: `
    <ng-template #template>
        <div class="modal-header">
            <h4 class="modal-title pull-left">{{'绑定账号' | translate}}</h4>
            <button type="button" class="close pull-right" aria-label="Close" (click)="modalRef.hide()">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="form-horizontal">
                <div class="form-group">
                    <label class="col-sm-2 control-label">
                        {{'快登账号'| translate}}
                    </label>
                    <input class="col-sm-8" [value]="oldUserId" readonly/>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label">
                        {{'官网账户'| translate}}
                    </label>
                    <input type="text" class="col-sm-8" [(ngModel)]="newUserId" placeholder="{{'请输入40位官网账户ID'|translate}}"/>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary btn-md" [disabled]="(!newUserId || newUserId.length != 40 )" (click)="bindAccount()">{{'绑定账号'|translate}}</button>
            <button type="button" class="btn btn-default btn-md" (click)="modalRef.hide()">{{'取消'|translate}}</button>
        </div>
    </ng-template>
    `,
    styles: ['']
})
export class AccountManageBindAccount implements OnInit{
    @Output()
    modalRef: BsModalRef;
    @ViewChild('template', {read: TemplateRef})
    template: TemplateRef<any>;
    oldUserId:string;
    newUserId:string;

    constructor (private modalService: BsModalService,
                 private service:AccountManageService,
                 private toast:ToastService){

    }
    ngOnInit(){
    }
    show(row:any){
        this.newUserId = "";
        this.oldUserId = row.userId;
        this.modalRef = this.modalService.show(this.template, {class: 'modal-md'});
    }
    bindAccount(){
        if(this.newUserId == this.oldUserId){
            this.toast.translate('warning',"两账号ID相同");
            return false
        }
        if(this.oldUserId.length != 40){
            this.toast.translate('warning',"快登账号长度不正确");
            return false
        }
        if(this.newUserId.substring(2,6) != '0001'){
            this.toast.translate('warning',"官网账号ID格式不正确");
            return false
        }

        let param={
            localeId: urlParam.language,
            productId: urlParam.product,
            newUserId:this.newUserId,
            oldUserId:this.oldUserId
        };
        this.service.bindAccount(param).then(res =>{
            if(res.status == '0'){
                this.toast.translate('success','绑定账号成功');
                this.modalRef.hide()
            }
        })

    }
}