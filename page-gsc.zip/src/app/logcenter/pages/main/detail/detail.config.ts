export type FieldComponent = 'text' | 'textarea' | 'tab';
export type FieldFormatter = (value, field, row) => string;

export class Field {
    name: string;
    field: string;
    component?: FieldComponent = 'text';
    formatter?: FieldFormatter = (value, field, row) => value;

    constructor(name: string, field: string, component?: FieldComponent, formatter?: FieldFormatter) {
        this.name = name;
        this.field = field;
        this.component = component || this.component;
        this.formatter = formatter || this.formatter;
    }

    static of(name: string, field: string, component?: FieldComponent, formatter?: FieldFormatter) {
        return new Field(name, field, component, formatter);
    }
}

export interface FieldGroup {
    name: string; //group name
    fields: Field[];
}

/**
 * 启动日志
 */
const log_groups: FieldGroup[] = [
    {
        name: '设备信息',
        fields: [
            {name: 'MAC', field: 'mac'},
            {name: 'IDFA', field: 'idfa'},
            {name: 'UDID', field: 'udid'},
            {name: 'deviceUniqueId', field: 'deviceUniqueId'},
            {name: 'palmDeviceId', field: 'dUniqueID'},
            {name: '谷歌广告ID', field: 'advertisingId'},
            {name: 'IDFV', field: 'idfv'},
            {name: 'IMEI', field: 'imei'},
            {name: 'IMSI', field: 'IMSI'},
            {name: '手机号', field: 'phoneNumber'},
            {name: '设备厂商', field: 'company'},
            {name: '终端型号', field: 'deviceDesc'},
            {name: '系统版本', field: 'osVersion'},
            {name: '终端分辨率', field: 'deviceResolution'},
            {name: '终端平台', field: 'platformId'},
            {name: '网络类型', field: 'workNetType'},
            {name: '网络子类型', field: 'networkSubType'},
            {name: 'IP', field: 'ip'},
            {name: '设备内存', field: 'ram'},
            {name: 'CPU核数', field: 'cpuCores'},
            {name: 'CPU主频', field: 'cpuHz'},
            {name: 'cpuType', field: 'cpuType'},
            {name: 'cpu架构信息 （卡顿异常）', field: 'cpuabi'},

            {name: 'MAC(前)', field: 'originMac'},
            {name: 'IDFA(前)', field: 'originIdfa'},
            {name: 'UDID(前)', field: 'originUdid'},
            {name: 'DEVICEUNIQUEID(前)', field: 'originDeviceuniqueid'},
            {name: 'dUniqueID(前)', field: 'originDUniqueID'},
            {name: '谷歌广告ID(前)', field: 'originAdvertisingId'},
            {name: 'IDFV(前)', field: 'originIdfv'},
            {name: 'IMEI(前)', field: 'originImei'},
            {name: 'IMSI(前)', field: 'originImsi'},
            {name: '手机号(前)', field: 'originPhoneNumber'},
            {name: '厂商(前)', field: 'originCompany'},
            {name: '设备名称(前)', field: 'originDeviceDesc'},
            {name: '系统版本(前)', field: 'originOsVersion'},
            {name: '分辨率(前)', field: 'originDeviceResolution'},
            {name: '网络类型(前)', field: 'originWorkNetType'},
            {name: '网络子类型(前)', field: 'originNetworkSubType'},
            {name: 'IP(前)', field: 'originIp'}
        ]
    },
    {
        name: '账户信息',
        fields: [
            {name: '用户ID', field: 'uid'},
            {name: '用户名', field: 'accountName'},
            {name: '角色ID', field: 'roleId'},
            {name: '角色名', field: 'roleName'},
            {name: '角色等级', field: 'roleLevel'},
            {name: '角色VIP等级', field: 'roleVipLevel'},
            {name: '逻辑服', field: 'server'}
        ]
    },
    {
        name: '产品信息',
        fields: [
            {name: '产品ID', field: 'product'},
            {
                name: '产品名称',
                field: 'product_name',
                formatter: (value, field, row) => `${row.product_name}(${row.product})`
            },
            {name: '语言', field: 'locale'},
            {name: '联运方ID', field: 'operatingLine'},
            {
                name: '联运方',
                field: 'operatingLine_name',
                formatter: (value, field, row) => `${row.operatingLine_name}(${row.operatingLine})`
            },
            {name: '主渠道ID', field: 'parentChannel'},
            {
                name: '主渠道',
                field: 'parentChannel_name',
                formatter: (value, field, row) => `${row.parentChannel_name}(${row.parentChannel})`
            },
            {name: '子渠道ID', field: 'channel'},
            {
                name: '子渠道名称',
                field: 'channel_name',
                formatter: (value, field, row) => `${row.channel_name}(${row.channel})`
            },
            {name: '机型组', field: 'platform'},
            {name: 'SDK版本', field: 'sdkVersion'},
            {name: '游戏版本', field: 'gameVersion'},
            {name: '客户端资源版本', field: 'resourceVersion'},

            {name: '产品ID(前)', field: 'originProductId'},
            {
                name: '产品(前)',
                field: 'originProduct_name',
                formatter: (value, field, row) => `${row.originProduct_name}(${row.originProductId})`
            },
            {name: '语言(前)', field: 'originLocale'},
            {name: '联运ID(前)', field: 'originOperatingLine'},
            {
                name: '联运方(前)',
                field: 'originOperatingLine_name',
                formatter: (value, field, row) => `${row.originOperatingLine_name}(${row.originOperatingLine})`
            },
            {name: '主渠道ID(前)', field: 'originParentChannel'},
            {
                name: '主渠道(前)',
                field: 'originParentChannel_name',
                formatter: (value, field, row) => `${row.originParentChannel_name}(${row.originParentChannel})`
            },
            {name: '子渠道ID(前)', field: 'originChannel'},
            {
                name: '子渠道(前)',
                field: 'originChannel_name',
                formatter: (value, field, row) => `${row.originChannel_name}(${row.originChannel})`
            },
            {name: '机型组(前)', field: 'originPlatform'},
            {name: 'SDK版本(前)', field: 'originSdkVersion'},
            {name: '游戏版本(前)', field: 'originGameVersion'},
            {name: '客户端资源版本(前)', field: 'originResourceVersion'}
        ]
    },
    {
        name: '业务信息',
        fields: [
            {name: '心跳超时时间', field: 'expiretime'},
            {name: '心跳周期', field: 'period'},
            {name: '注册登录类型', field: 'loginType'},
            {name: '是否新登', field: 'is_first'},
            {name: '动作ID', field: 'actId'},
            {name: '动作名称', field: 'actName'},
            {name: '动作id', field: 'interactId'},
            {name: '动作名称', field: 'interactName'},
            {name: '目标类型', field: 'targetType'},
            {name: '目标代码', field: 'targetCode'},
            {name: '目标详情', field: 'targetInfo'},
            {name: '事件Key', field: 'eventKey'},
            {name: '事件相关信息', field: 'eventParas'},
            {name: '广告商', field: 'advertiserTo'},
            {name: '绑定邮箱', field: 'bindEmail'},
            {name: '绑定手机', field: 'bindPhone'},
            {name: '绑定邮箱(前)', field: 'originBindEmail'},
            {name: '绑定手机(前)', field: 'originBindPhone'},
            {name: '卡牌ID', field: 'cardId'},
            {name: '卡牌名称', field: 'cardName'},
            {name: '属性标识', field: 'propKey'},
            {name: '新属性值', field: 'newValue'},
            {name: '新属性值', field: 'propValue'},
            {name: '变更值', field: 'rangeability'},
            {name: '旧属性值', field: 'oldValue'},
            {name: '变更类型', field: 'updateType'},
            {name: '商品ID（不同日志类型名称不同）', field: 'itemId'},
            {name: '商品名称（不同日志类型名称不同）', field: 'itemName'},
            {name: '商品个数（不同日志类型名称不同）', field: 'itemCount'},
            {name: '珍贵货币', field: 'isPrecious'},
            {name: '剩余货币数', field: 'remains'},
            {name: '关卡ID', field: 'stageId'},
            {name: '关卡名称', field: 'stageName'},
            {name: '任务id', field: 'taskId'},
            {name: '任务名称', field: 'taskName'},

            {name: '礼包码', field: 'gameCode'},
            {name: '礼包名称', field: 'gamePackageName'},
            {name: '礼包ID', field: 'packageId'},
            {name: '礼包来源', field: 'codeSource'},
            {name: '用户类型', field: 'userType'},
            {name: '礼包领取途径', field: 'drawingWay'},
            {name: '领取状态', field: 'status'},
            {name: '状态描述', field: 'statusDesc'},
            {name: '用户动作 （礼包码领取）', field: 'action'},
            {name: '领取用户的UA', field: 'userAgent'},

            {name: '异常标识', field: 'code'},
            {name: '异常摘要', field: 'message'},
            {name: 'osBuild', field: 'osBuild'},
            {name: 'dsymUuid', field: 'dsymUuid'},
            {name: '客户端包名', field: 'packageName'},
            {name: '崩溃上传文件名', field: 'fileName'},

            {name: '订单金额', field: 'currency_amount'},
            {name: '货币类型', field: 'currencyType'},
            {name: '货币类型ID', field: 'currency_type'},
            {name: '货币单位', field: 'mtUnit'},
            {name: '支付方式ID', field: 'pay_channel'},
            {name: '订单号', field: 'orderno'},
            {name: '虚拟币情况', field: 'currency'},
            {name: '客户端Md5签名', field: 'signKey'},
            {name: '自定义', field: 'custom'},
            {name: '明细 （异常明细和任务、事件的明细共用，异常明细需要特殊处理）', field: 'detail', component: 'tab'},
            {name: '页面地址', field: 'pageUrl'},
            {name: '等待时间', field: 'waitTime'},
            {name: '用户中心URL', field: 'ucenterUrl'},

            {name: '解析后异常信息', field: 'detail_parse', component: 'tab'},
            {name: 'parse_conf', field: 'parse_conf', component: 'tab'}
        ]
    },
    {
        name: '基础信息',
        fields: [
            {name: '时间', field: 'nowtime'},
            {name: '终端时间', field: 'time'},
            {name: '继承时间', field: 'extendtime'},
            {name: '上次继承时间', field: 'originExtendtime'},
            {name: '领取时间 （礼包码领取）', field: 'drawingTime'}
        ]
    }
];

log_groups.forEach((group: FieldGroup) => {
    let fields = [];
    group.fields.forEach((field: Field) => {
        fields.push(new Field(field.name, field.field, field.component, field.formatter));
    });
    group.fields = fields;
});

export const LOG_GROUPS = log_groups;

