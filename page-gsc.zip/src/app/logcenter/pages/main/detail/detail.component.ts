import {Component, OnInit} from "@angular/core";
import {Field, FieldGroup, LOG_GROUPS} from "./detail.config";
import {Store} from "@ngrx/store";
import {LogCenterService} from "../../../logcenter.service";
import {LogColumnsState} from "../../../reducers/main.reducers";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {urlParam} from "../../../../shared/url-param.const";


/**
 * 崩溃日志特殊处理
 1.原异常信息
 明细（detail） 字段不包含 .tmp结尾的字符，且 异常标识（code）字段值不是 ourpalm_AndroidNative   显示该tab页，tab内容detail
 2.异常信息
 1).异常标识（code）字段值不是 ourpalm_AndroidGame且ourpalm_AndroidSDK 且联运不是operatingLine(31000800000)  显示该tab页， tab内容detail_parse
 2).异常标识（code）字段值不是 ourpalm_AndroidGame且ourpalm_AndroidSDK 且联运为operatingLine((31000800000)),判断该日志是否存在十六进制日志（调接口），若存在显示该tab页，tab内容detail_parse
 3.符号文件
 判断 parse_conf  解析该字段，该字段值为json对象，若该对象的soFileBeans属性不为空，则显示该tab页，tab内容则为soFileBeans属性。
 4.logCat信息
 判断 parse_conf  解析该字段，该字段值为json对象 若该对象的logCatPath属性不为空，则调用接口，获取该日志的logCat信息，显示在该tab页的内容中
 5.原文件下载按钮
 判断 文件名(fileName) 字段是否为空，若不为空 显示该按钮 (调接口)
 */
@Component({
    selector: 'logcenter-main-modal-detail',
    styleUrls: ['./detail.component.css'],
    templateUrl: './detail.component.html'
})
export class MainModalDetailComponent implements OnInit {

    /*行数据*/
    rowData: any;
    /*列定义*/
    columns: any[];
    /*列分组 格式化信息*/
    groups: FieldGroup[];

    showTab: boolean;
    showTab1: boolean;
    showTab2: boolean;
    showTab3: boolean;
    showTab4: boolean;
    showTab5: boolean;

    tab1Data: any;
    tab2Data: any;
    tab3Data: any;
    tab4Data: any[] = [];
    table: OurpalmTable;

    logLevel: string = 'V';
    logQuery: string;

    constructor(private store$: Store<any>,
                private service: LogCenterService) {
        this.groups = LOG_GROUPS;
        this.table = new OurpalmTable({
            tableClass: 'table table-bordered table-striped table-hover text-center nowrap-table',
            autoLoadData: false,
            showSettingBtn: false,
            pageSize: 500,
            pageList: [500, 1000],
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                let start = (table.currentPage - 1) * table.pageSize + 1;
                let end = start + table.pageSize;

                let reg = {
                    'V': '^.{19}(V|D|I|W|E|A|F)',
                    'D': '^.{19}(D|I|W|E|A|F)',
                    'I': '^.{19}(I|W|E|A|F)',
                    'W': '^.{19}(W|E|A|F)',
                    'E': '^.{19}(E|A|F)',
                    'A': '^.{19}(A|F)',
                    'F': '^.{19}(F)'
                };

                let regex = new RegExp(reg[this.logLevel]);

                let data = [...this.tab4Data].filter((row) => {
                    return regex.test(row);
                }).filter((row) => {
                    return this.logQuery ? row.includes(this.logQuery) : true;
                });

                let total = data.length;
                data = data.slice(start, end);

                if (this.logQuery) {
                    data = data.map((row) => {
                        return (<string>row).replace(new RegExp(this.logQuery, 'g'), `<span style="color:red;">${this.logQuery}</span>`)
                    });
                }

                data = data.map((row) => {
                    return {text: row};
                });

                callback({
                    total: total,
                    rows: data
                });
            }
        });
    }

    ngOnInit(): void {
        //加载行数据
        this.store$.select('logcenterDetail').filter((state: any) => !state.initState).take(1).timeout(500).subscribe((row) => {
            this.rowData = row;
            let logType = row.logGroupId;
            //加载列定义
            this.store$
                .select('logcenterColumns')
                .do((state: LogColumnsState) => {
                    if (logType && !state[logType]) this.service.loadLogColumns(logType);
                })
                .filter((state: LogColumnsState) => !!state[logType])
                .take(1)
                .subscribe((state: LogColumnsState) => {
                    this.columns = state[logType].columns;
                    console.log('日志详情', this.rowData, this.columns);
                    this.parseTab1();
                    this.parseTab2();
                    this.parseTab3();
                    this.parseTab4();
                    this.parseTab5();
                    if (logType == '16' && (this.showTab1 || this.showTab2 || this.showTab3 || this.showTab4)) { //16是崩溃日志
                        this.showTab = true;
                    } else {
                        this.showTab = false;
                    }
                });
        }, () => {
            console.error('获取不到日志详情,页面是否刷新了,跳转到上个页面history.back()');
            window.history.back();
        });
    }

    /**
     * 原异常信息
     */
    parseTab1() {
        if (this.rowData.detail && !(<string>this.rowData.detail).endsWith('.tmp') && this.rowData.code != 'ourpalm_AndroidNative') {
            this.showTab1 = true;
            this.tab1Data = (<string>this.rowData.detail || '').replace(/\\n/g, '<br/>');
        }
    }

    /**
     * 异常信息
     */
    parseTab2() {
        if (this.rowData.code != 'ourpalm_AndroidGame' && this.rowData.code != 'ourpalm_AndroidSDK' && this.rowData.operatingLine != '31000800000') {
            this.showTab2 = true;
            this.tab2Data = (<string>this.rowData.detail_parse || '').replace(/\\n/g, '<br/>');
        }

        if (this.rowData.code != 'ourpalm_AndroidGame' && this.rowData.code != 'ourpalm_AndroidSDK' && this.rowData.operatingLine == '31000800000') {
            let time = this.rowData['nowtime'];
            time = moment(time, 'YYYY-MM-DD HH:mm:SS');
            this.service.isExistHexlog(urlParam.language, urlParam.product, time.startOf('day').format('YYYY-MM-DD HH:mm:SS'), time.endOf('day').format('YYYY-MM-DD HH:mm:SS'), this.rowData['esid']).subscribe((result) => {
                if (result.status == '0' && result.data.isExistHexLog == '1') {
                    this.showTab2 = true;
                    this.tab2Data = (<string>this.rowData.detail_parse || '').replace(/\\n/g, '<br/>');
                }
            });
        }
    }

    /**
     * 符号文件
     */
    parseTab3() {
        if (this.rowData.parse_conf) {
            let bean: any = JSON.parse(this.rowData.parse_conf);
            if (bean.soFileBeans && bean.soFileBeans.length > 0) {
                this.showTab3 = true;
                this.tab3Data = bean;
            }
        }
    }

    /**
     * logcat
     */
    parseTab4() {
        if (this.rowData.parse_conf) {
            let bean: any = JSON.parse(this.rowData.parse_conf);
            if (bean.logCatPath) {
                this.showTab4 = true;
                this.service.logCatDetail(bean.logCatPath).subscribe((result) => {
                    if (result.status == 0 && result.data.length > 0) {
                        this.tab4Data = result.data;
                        this.table.refresh();
                    }
                });
            }
        }
    }

    parseTab5() {
        if (this.rowData.fileName) {
            this.showTab5 = true;
        }
    }

    downloadLogFile() {
        this.service.downloadLogFile(this.rowData.fileName);
    }

    search() {
        this.table.currentPage = 1;
        this.table.refresh();
    }

    isShowField(field: Field): boolean {
        if (typeof this.rowData[field.field] != "undefined" && this.showField(field))
            return true;
        return false;
    }

    private showField(field: Field): boolean {
        let arr = this.columns.filter((column: any) => column.name == field.field);
        return arr.length > 0 ? (arr[0].isDetail == '1' ? true : false) : false;
    }
}
