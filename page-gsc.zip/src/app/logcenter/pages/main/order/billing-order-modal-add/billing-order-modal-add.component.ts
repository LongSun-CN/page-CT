import {Component, OnInit, TemplateRef, ViewChild} from "@angular/core";
import {BillingOrderService} from "../billing-order.service";
import {BsModalRef, BsModalService} from "ngx-bootstrap";
import {OurpalmTable, Page} from "ngx-ourpalm-table";

@Component({
    selector: 'billing-order-modal-add',
    template: `
        <ng-template #template>
            <div class="modal-header">
                <h4 class="modal-title pull-left">{{'后台代充' | translate}}</h4>
                <button type="button" class="close pull-right" aria-label="Close" (click)="modalRef.hide()">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <section class="content-header">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box box-default box-solid">
                                <div class="box-body" style="display:block;">
                                    <div class="form-inline form-search-column" role="form">
                                        <gw-input
                                                label="角色名"
                                                [(ngModel)]="searchForm.roleName"
                                                [closeable]="false"
                                                [enabled]="true"
                                                [showSelect]="false"
                                        ></gw-input>
                                        <gw-input
                                                label="角色Id"
                                                [(ngModel)]="searchForm.roleId"
                                                [closeable]="false"
                                                [enabled]="true"
                                                [showSelect]="false"
                                        ></gw-input>
                                        <!--<gw-select-auto-product-->
                                                <!--key="search"-->
                                                <!--type="1"-->
                                        <!--&gt;-->
                                            <!--&gt;-->
                                        <!--</gw-select-auto-product>-->

                                        <!--<gw-select-auto-server-->
                                                <!--key="search"-->
                                                <!--[(ngModel)]="searchForm.server">-->
                                            <!--&gt;-->
                                        <!--</gw-select-auto-server>-->
                                    </div>
                                    <div class="toolbar">
                                        <div class="box-tools pull-right">
                                            <div class="btn-group">
                                                <button (click)="searchCommition()" type="button"
                                                        class="btn btn-default btn-xs btn-flat"><i
                                                        class="glyphicon glyphicon-cog"></i> {{'查询' | translate}}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <ourpalm-table [table]="table">
                                            <ourpalm-table-column
                                                    [column]="{header: ('角色ID'|translate), field: 'roleId',show:false}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.roleId}}
                                                </ng-template>
                                            </ourpalm-table-column>
                                            <ourpalm-table-column
                                                    [column]="{header: ('角色名称'|translate), field: 'roleName',show:true}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.roleName}}
                                                </ng-template>
                                            </ourpalm-table-column>

                                            <ourpalm-table-column
                                                    [column]="{header: ('区服名称'|translate), field: 'logicServerName',show:true}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.logicServerName}}
                                                </ng-template>
                                            </ourpalm-table-column>
                                            <ourpalm-table-column
                                                    [column]="{header: ('VIP等级'|translate), field: 'vipLevelName'}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.vipLevelName}}
                                                </ng-template>
                                            </ourpalm-table-column>
                                            <ourpalm-table-column
                                                    [column]="{header: ('最后登录时间'|translate), field: 'lastLoginTime'}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.lastLoginTime }}
                                                </ng-template>
                                            </ourpalm-table-column>

                                            <ourpalm-table-column
                                                    [column]="{header: ('创建时间'|translate), field: 'createTime',show:false}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.createTime}}
                                                </ng-template>
                                            </ourpalm-table-column>
                                            <ourpalm-table-column
                                                    [column]="{header: ('操作'|translate),field: 'handler'}">
                                                <ng-template let-row="$row">
                                                    <a (click)="gotoCharge(row)">{{'去代冲' | translate}}</a>
                                                </ng-template>
                                            </ourpalm-table-column>
                                        </ourpalm-table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </ng-template>
        <ng-template #templateDetail>
            <div class="modal-header">
                <h4 class="modal-title pull-left">{{'订单详情' | translate}}</h4>
                <button type="button" class="close pull-right" aria-label="Close" (click)="modalRef.hide()">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <ng-container *ngFor="let group of groups">
                    <div class="box box-default" *ngIf="group.type==='form'">
                        <div class="box-header with-border">
                            <h3 class="box-title">{{group.name}}</h3>
                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                        class="fa fa-minus"></i></button>
                            </div>
                        </div>
                        <div class="box-body">
                            <div class="row" *ngIf="group.fields?.length>0">
                                <div class="col-md-4" *ngFor="let field of group.fields">
                                    <div class="form-group">
                                        <label>{{field.name}}</label>
                                        <input class="form-control input-sm" [value]="field.value" *ngIf="!field.type"
                                               readonly/>
                                        <input class="form-control " [value]="field.value" *ngIf="field.type==='radio'"
                                               type="radio"/>
                                        <select class="form-control input-sm" *ngIf="field.type==='select'">
                                            <option [value]="v.id" *ngFor="let v of field.value"
                                                    [selected]="v.selected">{{v.text}}
                                            </option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="box box-default" *ngIf="group.type==='table'">
                        <div class="box-header with-border">
                            <h3 class="box-title">{{group.name}}</h3>
                            <div class="box-tools" style="left: 10%;top: 1px;">
                                <button type="button" class="btn btn-box-tool" (click)="showAddGoods()"><i
                                        class="fa fa-plus"></i>{{'添加商品' | translate}}
                                </button>
                            </div>
                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                        class="fa fa-minus"></i></button>
                            </div>
                        </div>
                        <div class="box-body">
                            <div class="table-responsive" style="max-height:500px;">
                                <ourpalm-table [table]="productsTable">
                                    <tr ng-repeat="$row in $rows">
                                        <ourpalm-table-column
                                                [column]="{header: ('商品名称'|translate), field: 'goodsName',show:true}"
                                                class="text-left">
                                            <ng-template let-row="$row">
                                                {{row.goodsName}}
                                            </ng-template>
                                        </ourpalm-table-column>
                                        <ourpalm-table-column
                                                [column]="{header: ('商品ID'|translate), field: 'goodsId',show:true}"
                                                class="text-left">
                                            <ng-template let-row="$row">
                                                {{row.goodsId}}
                                            </ng-template>
                                        </ourpalm-table-column>
                                        <ourpalm-table-column
                                                [column]="{header: ('单价'|translate), field: 'goodsCost',show:true}"
                                                class="text-left">
                                            <ng-template let-row="$row">
                                                {{row.goodsCost}}
                                            </ng-template>
                                        </ourpalm-table-column>
                                        <ourpalm-table-column
                                                [column]="{header: ('数量'|translate), field: 'count',show:true}"
                                                class="text-left">
                                            <ng-template let-row="$row">
                                                {{row.goodsName}}
                                            </ng-template>
                                        </ourpalm-table-column>
                                        <ourpalm-table-column
                                                [column]="{header: ('操作'|translate), field: 'handler',show:true}"
                                                class="text-left">
                                            <ng-template let-row="$row">
                                                <a (click)="deleteGoods(row)">{{'删除' | translate}}</a>
                                            </ng-template>
                                        </ourpalm-table-column>
                                    </tr>
                                </ourpalm-table>
                            </div>
                        </div>
                    </div>
                </ng-container>
            </div>
        </ng-template>
        <ng-template #templateGoods>
            <div class="modal-header">
                <h4 class="modal-title pull-left">{{'添加商品' | translate}}</h4>
                <button type="button" class="close pull-right" aria-label="Close" (click)="goodModalRef.hide()">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <section class="content-header">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box box-default box-solid">
                                <div class="box-body" style="display:block;">
                                    <div class="toolbar" style="margin:15px 0  5px 0;">
                                        <div class="btn-group">
                                            <div class="form-group">
                                                <label style="overflow:inherit;width: 60%;">{{'商品组' | translate}}:
                                                    <select class="form-control input-sm" style="display: inline"
                                                            (change)="selectGroup($event.currentTarget)">
                                                        <option [value]="gp.id" *ngFor="let gp of goodGroup">
                                                            {{gp.text}}
                                                        </option>
                                                    </select>
                                                </label>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <ourpalm-table [table]="goodstable">
                                            <ourpalm-table-column
                                                    [column]="{header: ('角色ID'|translate), field: 'roleId',show:false}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.roleId}}
                                                </ng-template>
                                            </ourpalm-table-column>
                                            <ourpalm-table-column
                                                    [column]="{header: ('角色名称'|translate), field: 'roleName',show:true}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.roleName}}
                                                </ng-template>
                                            </ourpalm-table-column>

                                            <ourpalm-table-column
                                                    [column]="{header: ('区服名称'|translate), field: 'logicServerName',show:true}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.logicServerName}}
                                                </ng-template>
                                            </ourpalm-table-column>
                                            <ourpalm-table-column
                                                    [column]="{header: ('VIP等级'|translate), field: 'vipLevelName'}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.vipLevelName}}
                                                </ng-template>
                                            </ourpalm-table-column>
                                            <ourpalm-table-column
                                                    [column]="{header: ('最后登录时间'|translate), field: 'lastLoginTime'}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.lastLoginTime }}
                                                </ng-template>
                                            </ourpalm-table-column>

                                            <ourpalm-table-column
                                                    [column]="{header: ('创建时间'|translate), field: 'createTime',show:false}"
                                                    class="text-left">
                                                <ng-template let-row="$row">
                                                    {{row.createTime}}
                                                </ng-template>
                                            </ourpalm-table-column>
                                            <ourpalm-table-column
                                                    [column]="{header: ('操作'|translate),field: 'handler'}">
                                                <ng-template let-row="$row">
                                                    <a (click)="gotoCharge(row)">{{'去代冲' | translate}}</a>
                                                </ng-template>
                                            </ourpalm-table-column>
                                        </ourpalm-table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </ng-template>
    `,
    styles: ['.content-header{padding-top: 0px}']
})
export class BillingOrderModalAddComponent implements OnInit {

    searchForm = {
        channel: {},
        server: {},
        roleId: null,
        roleName: null
    };
    table: OurpalmTable;
    productsTable: OurpalmTable;
    goodstable: OurpalmTable;
    groups: any[] = [];
    goodGroup: any[] = [];
    selectGoodId: string


    modalRef: BsModalRef;
    goodModalRef: BsModalRef;
    @ViewChild('template', {read: TemplateRef})
    template: TemplateRef<any>;
    @ViewChild('templateDetail', {read: TemplateRef})
    templateDetail: TemplateRef<any>;
    @ViewChild('templateGoods', {read: TemplateRef})
    templateGoods: TemplateRef<any>;

    goodList: { [index: string]: string }[];

    constructor(private modalService: BsModalService, private service: BillingOrderService) {
    }

    ngOnInit() {
        this.productsTable = new OurpalmTable({
            cacheKey: "billingOrder-products-edit",
            autoLoadData: false,
            pagination: false,
            defaultPageSize: 100,
            pageList: [100],
            showRefreshBtn: false,
            showSettingBtn: false,
            fixTop: false,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                callback({
                    currentPage: table.getOptions().currentPage,
                    pageSize: table.getOptions().pageSize,
                    total: this.goodList.length,
                    rows: this.goodList
                })
            }
        });
        this.goodstable = new OurpalmTable({
            cacheKey: "billingOrder-goods-edit",
            autoLoadData: false,
            pagination: false,
            defaultPageSize: 100,
            pageList: [100],
            showRefreshBtn: false,
            showSettingBtn: false,
            fixTop: false,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                this.service.getGoodsList({goodsGroupId: this.selectGoodId}).then(res => {
                    callback({
                        currentPage: table.getOptions().currentPage,
                        pageSize: table.getOptions().pageSize,
                        total: (res.data && res.data.totalCount) || 0,
                        rows: res.data || []
                    })
                }, erro => {
                    console.log('查询失败！')
                })
            }
        });
        this.table = new OurpalmTable({
            cacheKey: "billingOrder-bigcustomerSearch",
            autoLoadData: false,
            pagePosition: 'bottom',
            defaultPageSize: 20,
            pageList: [20, 40],
            showRefreshBtn: false,
            showSettingBtn: false,
            fixTop: true,
            distanceTop: 50,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                this.service.queryAllBigCustomerPage(this.searchForm, table.getOptions()).then(res => {
                    callback({
                        currentPage: table.getOptions().currentPage,
                        pageSize: table.getOptions().pageSize,
                        total: (res.data.list && res.data.totalCount) || 0,
                        rows: (res.data && res.data.list) || []
                    })
                }, erro => {
                    console.log('查询失败！')
                })
            }
        });
    }

    show() {
        this.modalRef = this.modalService.show(this.template, {class: 'modal-lg'});
    }


    searchCommition() {
        this.table.firstPage();
    }

    gotoCharge(row: any) {
        this.modalRef.hide();
        this.groups = this.service.getOrderAddInit();
        this.groups.forEach(item => {
            item.type === 'form' && item.fields.map(filed => {
                filed.value = row[filed.key] || filed.value;
            })
        })
        this.modalRef = this.modalService.show(this.templateDetail, {class: 'modal-lg'});
    }

    deleteGoods(row: any) {

    }

    showAddGoods() {
        this.service.getGoodsGroupList().then(res => {
            if (res.status === '0') {
                (res.data || []).forEach(item => {
                    this.goodGroup.push({id: item.ggId, text: item.ggName})
                });
            }
        });
        this.goodModalRef = this.modalService.show(this.templateGoods);
    }

    selectGroup(ev: any) {
        this.selectGoodId = ev.value;
        this.goodstable.firstPage();
    }

}

