import {Component, OnInit, Output, TemplateRef, ViewChild} from '@angular/core';
import {BillingOrderService} from "../billing-order.service";
import {BsModalRef, BsModalService} from "ngx-bootstrap";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {environment} from "../../../../../../environments/environment.hmr";
import {HttpService} from "../../../../../shared/services/httpx.service";
import {DateFormatterPipe} from "../../../../../widgets/ourpalm-pipes/date-formatter.pipe";
import {urlParam} from "../../../../../shared/url-param.const";

const TableUrls = {
    PROCESSURL:'gsc/billingOrder/getOrderFlowLog.htm',
    HANDLEURL:'gsc/billingOrder/getOperateOrderLog.htm',
    RELATEURL:'gsc/billingOrder/getRelationOrderByOrderId.htm'
}

@Component({
    selector: 'billing-order-modal-detail',
    templateUrl: './billing-order-modal-detail.component.html',
    styleUrls: ['./billing-order-modal-detail.component.css']
})
export class BillingOrderModalDetailComponent implements OnInit {


    groups: any[];

    @Output()
    modalRef: BsModalRef;

    @ViewChild('template', {read: TemplateRef})
    template: TemplateRef<any>;

    processTable: OurpalmTable = new OurpalmTable({
        customClass: 'nowrap-table-order-process',
        autoLoadData: false,
        showSettingBtn: false,
        pageSize: 500,
        pageList: [500, 1000],
        columns: [
            {
                field: 'logSendTimeMillis',
                header: '日志发送时间'
            }, {
                field: 'orderId',
                header: '订单号'
            }, {
                field: 'step',
                header: '步骤顺序',
                formatter: (val) => {
                    switch (val) {
                        case '1000':
                            return '玩家下单';
                        case '1001':
                            return '选择通道';
                        case '2000':
                            return '支付回调';
                        case '3000':
                            return '通知游戏';
                        default:
                            return '';
                    }
                }
            }, {
                field: 'stepDESC',
                header: '步骤描述'
            }
        ],

    });
    handlerTable: OurpalmTable = new OurpalmTable({
        customClass: 'nowrap-table-order-handler',
        autoLoadData: false,
        showSettingBtn: false,
        pageSize: 500,
        pageList: [500, 1000],
        columns: [
            {
                field: 'description',
                header: '描述信'
            },
            {
                field: 'operateTime',
                header: '补单操作时'
            },
            {
                field: 'operateUser',
                header: '操作人I'
            },
            {
                field: 'operateUserName',
                header: '操作'
            },
            {
                field: 'orderId',
                header: '订单'
            },
            {
                field: 'repairOrderId',
                header: '补单订单'
            },
            {
                field: 'status',
                header: '状'
            },
            {
                field: 'type',
                header: '类'
            },
        ],

    });

    relateTable: OurpalmTable = new OurpalmTable({
        customClass: 'nowrap-table-order-relate',
        autoLoadData: false,
        showSettingBtn: false,
        columns: [

            {
                header: '订单id',
                field: 'orderId',
                show: true
            },


            {
                header: '用户id',
                field: 'userId',
                show: true
            },


            {
                header: '角色ID',
                field: 'roleId',
                show: true
            },

            {
                header: '角色名',
                field: 'roleName',
                show: true
            },


            {
                header: '游戏服',
                field: 'logicServerName',
                show: true
            },


            {
                header: '订单金额',
                field: 'cost',
                show: true
            },


            {
                header: '货币单位',
                field: 'moneyType',
                show: true
            },


            {
                header: '创建时间',
                field: 'createTime',
                show: true
            },


            {
                header: '订单状态',
                field: 'status',
                show: true
            },


            {
                header: '订单类型',
                field: 'gameOrderType',
                show: true
            },


            {
                header: '实际金额',
                field: 'actualCost',
                show: false
            },

            {
                header: '第三方订单号',
                field: 'billingCooperationId',
                show: false
            },

            {
                header: '回调参数',
                field: 'callbackParam',
                show: false
            },

            {
                header: '回调时间',
                field: 'callbackTime',
                show: false
            },

            {
                header: '渠道ID',
                field: 'channelId',
                show: false
            },

            {
                header: 'chargeUnitId',
                field: 'chargeUnitId',
                show: false
            },


            {
                header: '礼券',
                field: 'coupon',
                show: false
            },


            {
                header: '货币名称',
                field: 'currencyName',
                show: false
            },

            {
                header: '货币类型',
                field: 'currencyType',
                show: false
            },

            {
                header: '自定义参数',
                field: 'customParam',
                show: false
            },

            {
                header: '重新发货',
                field: 'deliverReset',
                show: false
            },

            {
                header: '发货状态',
                field: 'deliverStatus',
                show: false
            },

            {
                header: '发货地址',
                field: 'deliverUrl',
                show: false
            },

            {
                header: '机型组ID',
                field: 'deviceGroupid',
                show: false
            },

            {
                header: '设备厂商',
                field: 'deviceManufacturer',
                show: false
            },

            {
                header: '设备名称',
                field: 'deviceName',
                show: false
            },

            {
                header: '设备分辨率',
                field: 'deviceResolution',
                show: false
            },

            {
                header: '设备系统版本',
                field: 'deviceSystemVersion',
                show: false
            },

            {
                header: '设备UDID',
                field: 'deviceUdid',
                show: false
            },

            {
                header: '设备UniqueId',
                field: 'deviceUniqueId',
                show: false
            },

            {
                header: '机型组名称',
                field: 'devicegroupName',
                show: false
            },

            {
                header: '返利状态',
                field: 'fillStatus',
                show: false
            },

            {
                header: '客户端版本',
                field: 'gameClientVersion',
                show: false
            },

            {
                header: '游戏服id',
                field: 'gameServerId',
                show: false
            },

            {
                header: 'IDFA',
                field: 'idfa',
                show: false
            },

            {
                header: 'IMSI',
                field: 'imsi',
                show: false
            },

            {
                header: 'IP',
                field: 'ip',
                show: false
            },

            {
                header: '是否已经补单',
                field: 'isRepireOrder',
                show: false
            },

            {
                header: '测试账户',
                field: 'isTestUser',
                show: false
            },

            {
                header: '计费商名称',
                field: 'jfName',
                show: false
            },

            {
                header: '计费点名称',
                field: 'jfdName',
                show: false
            },

            {
                header: '语言',
                field: 'localName',
                show: false
            },

            {
                header: '语言id',
                field: 'localeId',
                show: false
            },


            {
                header: 'MAC',
                field: 'mac',
                show: false
            },

            {
                header: '主渠道名称',
                field: 'mainChannelName',
                show: false
            },


            {
                header: '网源类型',
                field: 'netSourceType',
                show: false
            },

            {
                header: '网源类型名称',
                field: 'netsourceName',
                show: false
            },

            {
                header: '用户昵称',
                field: 'nickName',
                show: false
            },

            {
                header: '详细状态',
                field: 'notifyStatus',
                show: false
            },

            {
                header: '联运名称',
                field: 'operationLineName',
                show: false
            },

            {
                header: '联运Id',
                field: 'operationlineId',
                show: false
            },


            {
                header: '原始回调时间',
                field: 'originalCallbackTime',
                show: false
            },

            {
                header: '原始创建时间',
                field: 'originalCreateTime',
                show: false
            },

            {
                header: '原始订单id',
                field: 'originalOrderId',
                show: false
            },

            {
                header: '原始修改时间',
                field: 'originalUpdateTime',
                show: false
            },

            {
                header: '支付渠道id',
                field: 'payChannelId',
                show: false
            },

            {
                header: '支付渠道名称',
                field: 'payChannelName',
                show: false
            },

            {
                header: '支付渠道类型',
                field: 'payChannelType',
                show: false
            },

            {
                header: '支付国家',
                field: 'payCountry',
                show: false
            },

            {
                header: '支付货币',
                field: 'payCurrency',
                show: false
            },

            {
                header: '支付状态',
                field: 'payStatusName',
                show: false
            },

            {
                header: '手机号',
                field: 'phoneNum',
                show: false
            },

            {
                header: '平台id',
                field: 'platformId',
                show: false
            },

            {
                header: '产品id',
                field: 'productId',
                show: false
            },

            {
                header: '产品名称',
                field: 'productName',
                show: false
            },

            {
                header: '产品类型',
                field: 'productType',
                show: false
            },

            {
                header: '产品类型名称',
                field: 'productTypeName',
                show: false
            },

            {
                header: '商品数量',
                field: 'propCount',
                show: false
            },

            {
                header: '商品ID',
                field: 'propId',
                show: false
            },

            {
                header: '商品名称',
                field: 'propName',
                show: false
            },

            {
                header: '关联订单id',
                field: 'relateOrderId',
                show: false
            },

            {
                header: '备注',
                field: 'remark',
                show: false
            },


            {
                header: 'sdk版本',
                field: 'sdkVersion',
                show: false
            },

            {
                header: '节点',
                field: 'serverNode',
                show: false
            },

            {
                header: '电信服务商',
                field: 'serviceOperator',
                show: false
            },

            {
                header: '短订单id',
                field: 'shortOrderId',
                show: false
            },

            {
                header: 'sp名称',
                field: 'spName',
                show: false
            },

            {
                header: 'sp支付渠道名称',
                field: 'spPayChannelName',
                show: false
            },

            {
                header: 'SPID',
                field: 'spcooperationId',
                show: false
            },
            {
                header: '子渠道名称',
                field: 'subChannelName',
                show: false
            },

            {
                header: '第三方用户',
                field: 'thirdBillingUserId',
                show: false
            },

            {
                header: '更新时间',
                field: 'updateTime',
                show: false
            },
            {
                header: '用户名称',
                field: 'userName',
                show: false
            },

            {
                header: '虚拟币',
                field: 'virtualCoin',
                show: false
            },

            {
                header: '虚拟币数量',
                field: 'virtualCoinUnit',

                show: false
            },

            {
                header: '虚拟币名称',
                field: 'virtualCoinUnitName',

                show: false
            },
        ],
        pageSize: 500,
        pageList: [500, 1000],

    });




    constructor(private service: BillingOrderService, private modalService: BsModalService,
                private http: HttpService,private dateformatter: DateFormatterPipe) {
    }

    ngOnInit() {
        this.groups = this.service.getDetailInit();
    }


    show(obj: any) {
        this.modalRef = this.modalService.show(this.template, {class: 'modal-lg'});
        if (obj) {
            this.processTable.setOptions(this.getLoadData(TableUrls.PROCESSURL, obj));
            this.handlerTable.setOptions(this.getLoadData(TableUrls.HANDLEURL, obj));
            this.relateTable.setOptions(this.getLoadData(TableUrls.RELATEURL, obj));
            this.groups.forEach(item => {
                item.type === 'form' && item.fields.forEach(li => {
                    li.value = obj[li.key] || '';
                })
            });
            this.processTable.firstPage();
            this.handlerTable.firstPage();
            this.relateTable.firstPage();
        }
    }


    getLoadData(url: string, row: any) {
        return {
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                let param = {localeId: urlParam.language, ...table.getOptions(), ...row};
                setTimeout(() => {
                    this.http.get(environment.getUrl(url), param)
                        .map(res => res.json())
                        .subscribe(result => {
                            if (result.status === '0') {
                                let myData = {
                                    currentPage: param.currentPage,
                                    pageSize: param.pageSize,
                                    total: (result.data && result.data.totalCount) || 0,
                                    rows: (result.data && result.data.list) || []
                                };
                                if(url===TableUrls.PROCESSURL){
                                    myData.rows.sort((a,b)=>{
                                        return a.logSendTimeMillis-b.logSendTimeMillis;
                                    }).map(item=>{
                                        item.logSendTimeMillis = this.dateformatter.transform(+item.logSendTimeMillis, 'YYYY-MM-DD HH:mm:ss')
                                    })
                                }

                                callback(myData)
                            }
                        })
                });
            }
        }
    }


}

