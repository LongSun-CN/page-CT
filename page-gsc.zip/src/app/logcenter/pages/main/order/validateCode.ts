import {Component, EventEmitter, OnInit, Output, TemplateRef, ViewChild} from '@angular/core';
import {BillingOrderService} from "./billing-order.service";
import {ToastService} from "../../../../shared/services/toast.service";
import {BsModalRef, BsModalService} from "ngx-bootstrap";



@Component({
  selector: 'billing-order-modal-validateCode',
  template: `
    <ng-template #template>
      <div class="modal-header">
        <h4 class="modal-title pull-left">{{'验证码'|translate}}</h4>
        <button type="button" class="close pull-right" aria-label="Close" (click)="modalRef.hide()">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-horizontal  ">
          <fieldset class="form-two-column">
            <div class="form-group">
              <label class="control-label">
                {{'验证码'|translate}}
              </label>
              <div class="dynamicContent">
                <input [(ngModel)]="randomCode " placeholder="{{'请输入验证码'|translate}}"
                       class="form-control input-sm"/>
              </div>
            </div>
          </fieldset>
        </div>
        <div class="modal-footer">
          <div class="btn-group open">
            <button type="button" class="btn btn-info dropdown-toggle"  data-toggle="dropdown" aria-expanded="true">
              {{'获取验证码'|translate}}<span class="caret"></span>
            </button>
            <ul class="dropdown-menu">
              <li (click)="sendCode('phone')"><a href="javascript:void(0);">{{'手机验证码'|translate}}</a></li>
              <li (click)="sendCode('mail')"><a href="javascript:void(0);">{{'邮箱验证码'|translate}}</a></li>
            </ul>
          </div>
          <button type="button"  *ngIf="!!randomCode"  
                  [ngClass]="{'btn':true,'btn-primary':true}" (click)="next()">
            {{'下一步'|translate}}
          </button>
        </div>
      </div> 
    </ng-template>
  `,
  styles: ['']
})
export class BillingOrderModalValidateCodeComponent implements    OnInit  {


  randomCode:string;
  isShow = false;

  @Output()
  modalRef: BsModalRef;

  @ViewChild('template', {read: TemplateRef})
  template: TemplateRef<any>;

  @Output()
  done: EventEmitter<string> = new EventEmitter<string>();

  constructor(private service:BillingOrderService,private modalService: BsModalService, private  toast: ToastService,) { }

  ngOnInit() {

  }


  show(obj: any){
    if(obj){
      this.service.isValid().then((result:any)=>{
        if(result.status==='0'){
          if(!result.data){
            this.modalRef = this.modalService.show(this.template,{class: 'modal-lg'});
          }else{
            this.next();
          }
        }else{
           this.toast.pop('error',result.desc);
        }
      });
    }
  }

  next(){
       this.service.codeToValidate(this.randomCode).then(res=>{
          if(res.status === '0'){
            if(res.data.pass==='true'){
              this.modalRef&&this.modalRef.hide();
              this.done.emit(this.randomCode);
            }else if(res.data.pass==='phoneCodeError'){
              this.toast.translate('warning','验证码错误')
            }else if(res.data.pass==='expireCodeError'){
              this.toast.translate('warning','验证码过期')
            }else{
              this.toast.translate('warning','验证失败')
            }
          }else{
            this.toast.pop('error',res.desc);
          }
       })

  }


//发送验证码
  sendCode(type:('phone'|'mail')){
    this.service.sendCode(type);
  }



}

