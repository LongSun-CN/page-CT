import {BillingOrderModalDetailComponent} from "./billing-order-modal-detail/billing-order-modal-detail.component";
import {BillingOrderModalRebuildComponent} from "./billing-order-modal-rebuild/billing-order-modal-rebuild.component";
import {BillingOrderModalValidateCodeComponent} from "./validateCode";
import {BillingOrderModalAddComponent} from "./billing-order-modal-add/billing-order-modal-add.component";
/**
 * Created by admin on 2017/9/14.
 */
export const orderComponent = [
  BillingOrderModalDetailComponent,
  BillingOrderModalValidateCodeComponent,
  BillingOrderModalRebuildComponent,
  BillingOrderModalAddComponent
];
