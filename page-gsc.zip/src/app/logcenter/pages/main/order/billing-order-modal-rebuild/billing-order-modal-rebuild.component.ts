import {Component, EventEmitter, OnInit, Output, TemplateRef, ViewChild} from '@angular/core';
import {BillingOrderService} from "../billing-order.service";
import {BsModalRef, BsModalService} from "ngx-bootstrap";
import {ToastService} from "../../../../../shared/services/toast.service";
import {Observable} from "rxjs/Observable";
import {BillingOrderModalValidateCodeComponent} from "../validateCode";


@Component({
  selector: 'billing-order-modal-rebuild',
  template: `
      <billing-order-modal-validateCode #templateCode (done)="showNext($event)"></billing-order-modal-validateCode>
    
    <ng-template #template>
      <div class="modal-header"> 
        <h4 class="modal-title pull-left">{{'补单'|translate}}</h4>
        <button type="button" class="close pull-right" aria-label="Close" (click)="modalRef.hide()">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <div class="modal-body"> 
        <div class="form-horizontal  ">
          <fieldset class="form-two-column">
            <div class="form-group">
              <label class="control-label">
                {{'订单ID'|translate}}
              </label>
              <div class="dynamicContent">
                <input [(ngModel)]="rebuildItem.orderId" placeholder="" [disabled]="true"
                       class="form-control input-sm"/>
              </div>
            </div>
 
            <div class="form-group">
              <label class="control-label">
                {{'实际金额'|translate}}
              </label>
              <div class="dynamicContent">
                <input [(ngModel)]="rebuildItem.actualPrice" [disabled]="!isEdit" placeholder="{{'请输入实际金额'|translate}}"
                       class="form-control input-sm"/>
              </div>
            </div>
 
          </fieldset>
        </div>
        <div class="modal-footer"> 
          <button type="button"   ourpalm-has-permission="kfqa_detail_addKfqaRecord"
                  [ngClass]="{'btn':true,'btn-primary':true}" (click)="repairOrderCommition()">
            {{'确定'|translate}}
          </button>
        </div>
        
      </div>
    </ng-template> 
  `,
  styles: ['']
})
export class BillingOrderModalRebuildComponent implements    OnInit  {


  rebuildItem:any;
  isShow = false;
  isEdit:boolean = false;

  @Output()
  modalRef: BsModalRef;

  @ViewChild('template', {read: TemplateRef})
  template: TemplateRef<any>;

  @ViewChild('templateCode')
  templateCode: BillingOrderModalValidateCodeComponent;

  isRepaired:Observable<any>;
  isValue:Observable<any>;


  @Output()
  done: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(private service:BillingOrderService,private modalService: BsModalService, private  toast: ToastService,) { }

  ngOnInit() {



  }


  show(obj: any){
    if(obj&&obj.orderId){
      this.rebuildItem = obj;
      this.isRepaired = this.service.isRepaired(obj.orderId);
      this.isValue =  this.service.getRealPrice(obj);

      Observable.combineLatest(this.isRepaired,this.isValue,(isRepaired,isValue)=>[isRepaired,isValue])
                 .subscribe(([isRepaired,isValue])=>{
                     if(isRepaired.status ==='0'&&(isValue===-1||isValue.status ==='0')){
                         if(isRepaired.data.isRepaired==='false'){//未补单
                            if(isValue===-1||!!isValue.data.cost){//普通账单或金额不为空
                              if(isValue===-1){
                                this.isEdit=true;
                                this.rebuildItem.actualPrice = '';
                              }else{
                                this.rebuildItem.actualPrice = isValue.data.cost;
                              }
                               this.templateCode.show(obj);
                              //this.modalRef = this.modalService.show(this.templateCode,{class: 'modal-lg'});
                            }else{
                               this.toast.translate('warning','该条数据不能补单');
                            }
                         }else{
                           this.toast.translate('warning','该条数据不能补单');
                         }
                     }else{
                       this.toast.pop('error', isRepaired.data.desc||isValue.data.desc);
                     }
                 })
    }
  }

  showNext(code:any){
    this.modalRef&&this.modalRef.hide();
    this.rebuildItem.randomCode = code;
    this.modalRef = this.modalService.show(this.template,{class: 'modal-lg'});
  }

  //补单
  repairOrderCommition(){
    this.service.repairOrder(this.rebuildItem).then(result => {
      console.log('repairOrder', result);
      if (result.status === '0') {
        this.toast.translate('success', '补单成功');
        this.modalRef.hide();
        this.done.emit(true);
      } else {
        this.toast.pop('error', result.data.desc);
      }
    });
  }



}

