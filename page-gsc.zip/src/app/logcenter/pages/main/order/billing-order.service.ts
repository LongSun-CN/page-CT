import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {TranslateService} from "@ngx-translate/core";
import {DateFormatterPipe} from "../../../../widgets/ourpalm-pipes/date-formatter.pipe";
import {HttpService} from "../../../../shared/services/httpx.service";
import {urlParam} from "../../../../shared/url-param.const";
import {environment} from "../../../../../environments/environment";
import {Observable} from "rxjs/Observable";
import {ToastService} from "../../../../shared/services/toast.service";

@Injectable()
export class BillingOrderService {

    constructor(private http: HttpService,
                private $store: Store<any>,
                // private lanservice: LanProTypeService,
                private  toast: ToastService,
                private translate: TranslateService,
                private dateformatter: DateFormatterPipe) {
    }


    sendCode(type: "phone" | "mail") {
        this.http.post(environment.getUrl('bbs/smsCode/sendCode.htm'), {type: type})
            .map(res => res.json())
            .subscribe(result => {
                console.log(result)
            });
    }

    repairOrder(rebuildItem: any): Promise<any> {
        return this.http.post(environment.getUrl('gsc/billingOrder/repairOrder.htm'), rebuildItem)
            .map(res => res.json())
            .toPromise();
    }

    isValid(): Promise<any> {
        return this.http.get(environment.getUrl('bbs/smsCode/validateCode.htm'))
            .map(res => res.json())
            .toPromise()
    }


    codeToValidate(randomCode: string) {
        return this.http.get(environment.getUrl('/gsc/billingOrder/codeToValidate.htm'), {code: randomCode})
            .map(res => res.json())
            .toPromise()
    }

    reSend(row: any) {
        this.http.post(environment.getUrl('gsc/billingOrder/reSend.htm'), {
            localeId: urlParam.language,
            ...row
        })
            .map(res => res.json())
            .subscribe(result => {
                console.log('reSend', result);
                if (result.status === '0') {
                    this.toast.translate('success', '重新发货成功');
                } else {
                    this.toast.pop('error', result.desc);
                }
            })
    }


    getDetailInit() {

        return [
            {
                name: '订单信息',
                type: 'form',
                fields: [
                    {
                        name: '订单号',
                        key: 'orderId',
                        value: ''
                    }, {
                        name: '合作订单号',
                        key: 'billingCooperationId',
                        value: ''
                    }, {
                        name: '短订单号',
                        key: 'shortOrderId',
                        value: ''
                    }, {
                        name: '创建时间',
                        key: 'createTime',
                        value: ''
                    }, {
                        name: '更新时间',
                        key: 'updateTime',
                        value: ''
                    }, {
                        name: '回调时间',
                        key: 'callbackTime',
                        value: ''
                    }, {
                        name: '支付通道',
                        key: 'payChannelName',
                        value: ''
                    }, {
                        name: '充值金额',
                        key: 'actualCost',
                        value: ''
                    }, {
                        name: '订单金额',
                        key: 'cost',
                        value: ''
                    }, {
                        name: '礼券',
                        key: 'coupon',
                        value: ''
                    }, {
                        name: '返利金额',
                        key: '',
                        value: ''
                    }, {
                        name: '支付国家',
                        key: 'payCountry',
                        value: ''
                    }, {
                        name: '支付货币',
                        key: 'payCurrency',
                        value: ''
                    }, {
                        name: '订单类型',
                        key: 'gameOrderType',
                        value: ''
                    }, {
                        name: '商品名称',
                        key: 'propName',
                        value: ''
                    }, {
                        name: '商品ID',
                        key: 'propId',
                        value: ''
                    }, {
                        name: '商品数量',
                        key: 'propCount',
                        value: ''
                    }, {
                        name: '计费点ID',
                        key: 'billingcooperationid',
                        value: ''
                    }, {
                        name: '计费点货币',
                        key: 'currencyName',
                        value: ''
                    }, {
                        name: '计费点货币单位',
                        key: 'moneyType',
                        value: ''
                    }, {
                        name: '备注',
                        key: 'remark',
                        value: ''
                    }, {
                        name: '自定义参数',
                        key: 'customParam',
                        value: ''
                    }, {
                        name: '发货地址',
                        key: 'deliverUrl',
                        value: ''
                    }, {
                        name: '计费商回调参数',
                        key: 'callbackParam',
                        value: ''
                    }
                ]
            }, {
                name: '用户信息',
                type: 'form',
                fields: [{
                    name: '用户ID',
                    key: 'userId',
                    value: ''
                }, {
                    name: '角色ID',
                    key: 'roleId',
                    value: ''
                }, {
                    name: '角色名',
                    key: 'roleName',
                    value: ''
                }, {
                    name: '游戏服',
                    key: 'logicServerName',
                    value: ''
                }, {
                    name: '测试账户',
                    key: 'isTestUser',
                    value: ''
                },
                ]
            }, {
                name: '设备信息',
                type: 'form',
                fields: [
                    {
                        name: 'MAC',
                        key: 'mac',
                        value: ''
                    }, {
                        name: 'IDFA',
                        key: 'idfa',
                        value: ''
                    }, {
                        name: 'UDID',
                        key: 'deviceUdid',
                        value: ''
                    }, {
                        name: 'IMSI',
                        key: 'imsi',
                        value: ''
                    }, {
                        name: '手机号码',
                        key: 'phoneNum',
                        value: ''
                    }, {
                        name: 'IP',
                        key: 'ip',
                        value: ''
                    }, {
                        name: '运营商',
                        key: 'serviceOperator',
                        value: ''
                    }, {
                        name: '厂商',
                        key: 'deviceManufacturer',
                        value: ''
                    }, {
                        name: '终端型号',
                        key: 'deviceName',
                        value: ''
                    }, {
                        name: '系统版本',
                        key: 'deviceSystemVersion',
                        value: ''
                    }, {
                        name: '谷歌广告ID',
                        key: 'googleadsid',
                        value: ''
                    },
                ]
            }, {
                name: '产品信息',
                type: 'form',
                fields: [
                    {
                        name: '产品',
                        key: 'productName',
                        value: ''
                    }, {
                        name: '联运',
                        key: 'operationLineName',
                        value: ''
                    }, {
                        name: '主渠道',
                        key: 'mainChannelName',
                        value: ''
                    }, {
                        name: '子渠道',
                        key: 'subChannelName',
                        value: ''
                    }, {
                        name: '语言',
                        key: 'localName',
                        value: ''
                    }, {
                        name: '游戏版本',
                        key: 'gameClientVersion ',
                        value: ''
                    }, {
                        name: 'SDK版本',
                        key: 'sdkVersion',
                        value: ''
                    },
                ]
            }
        ]
    }


    //大客户查询
    queryAllBigCustomerPage(search: any, param: any): Promise<any> {
        param = {...search, ...param};
        let _param: any = {
            localeId: urlParam.language,
            productId: urlParam.product,
            server: (param.server && param.server.id) ? param.server.id : '',
            operationLineId: (param.channel && param.channel.id) ? param.channel.id : '',
            vipLevelValue: (param.vipLevel && param.vipLevel.id) ? param.vipLevel.id : '',
        };
        _param = {...param, ..._param};


        if (!_param.productId || _param.productId === '-1' || ((!_param.server || _param.server === '-1') && (!_param.operationLineId || '-1' === _param.operationLineId)
            && (!_param.vipLevelValue || '-1' === _param.vipLevelValue) && !_param.roleId && !_param.roleName)) {

            return new Promise((resolve, reject) => {
                this.toast.translate('warning', '请选择产品和补充条件');
                reject(false);
            });
        }

        return this.http
            .get(environment.getUrl('customService/bigCustomer/queryAllBigCustomerPage.htm'), _param)
            .map((res: any) => {
                res = res.json();
                res.data && res.data.list && res.data.list.map(item => {
                    const fmt = 'YYYY-MM-DD HH:mm:ss';
                    item.lastLoginTime = this.dateformatter.transform(item.lastLoginTime, fmt);
                    item.birthday = this.dateformatter.transform(item.birthday, fmt);
                    item.modifyTime = this.dateformatter.transform(item.modifyTime, fmt);
                    item.createTime = this.dateformatter.transform(item.createTime, fmt);
                    item.certifiedTime = this.dateformatter.transform(item.certifiedTime, fmt);
                    return item;
                });
                return res;
            })
            .toPromise();
    };


    isRepaired(orderId: string): Observable<any> {
        return this.http
            .get(environment.getUrl('gsc/billingOrder/isRepaired.htm'), {orderId})
            .map(res => res.json());
    }

    getRealPrice(item: any): Observable<any> {
        if (item.payChannelId === '210695000012000051014300') {
            return this.getMyCardActualcost(item.orderId);
        } else if (item.payChannelId === '210696000312000051014300') {
            return this.getGashActualcost(item.orderId);
        } else {
            return Observable.of(-1);
        }
    }

    getGashActualcost(orderId: string): Observable<any> {
        return this.http
            .get(environment.getUrl('gsc/billingOrder/getGashActualcost.htm'), {orderId})
            .map(res => res.json());
    }

    getMyCardActualcost(orderId: string): Observable<any> {
        return this.http
            .get(environment.getUrl('gsc/billingOrder/getMyCardActualcost.htm'), {orderId})
            .map(res => res.json());
    }


    getOrderAddInit() {

        return [
            {
                name: '角色信息',
                type: 'form',
                fields: [
                    {
                        name: '角色名',
                        key: 'roleName',
                        value: ''
                    }, {
                        name: '角色ID',
                        key: 'roleId',
                        value: ''
                    }, {
                        name: '游戏服',
                        key: 'logicServerName',
                        value: ''
                    }, {
                        name: '用户ID',
                        key: 'userId',
                        value: ''
                    }
                ]
            }, {
                name: '商品信息',
                type: 'table',
                fields: []
            }, {
                name: '支付发货信息',
                type: 'form',
                fields: [
                    {
                        name: '支付通道',
                        key: 'payChannelId',
                        type: 'select',
                        value: [{id: '', text: '支付宝', selected: true}]
                    }, {
                        name: '通知发货',
                        type: 'radio',
                        key: 'deliveryAddr',
                        value: ''
                    }
                ]
            }
        ]
    }

    getGoodsGroupList(): Promise<any> {
        return this.http
            .get(environment.getUrl('gsc/billingOrder/getGoodsGroupList.htm'), {productId: urlParam.product})
            .map(res => res.json())
            .toPromise();
    }

    getGoodsList(param: { goodsGroupId: string }) {
        return this.http
            .get(environment.getUrl('gsc/billingOrder/getGoodsList.htm'), {...param, productId: urlParam.product})
            .map(res => res.json())
            .toPromise();
    }
}
