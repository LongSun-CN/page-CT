import {
    AfterContentInit,
    Component,
    ElementRef,
    OnDestroy,
    QueryList,
    TemplateRef,
    ViewChild,
    ViewChildren
} from "@angular/core";
import {
    IAuthGroupEmptyCheckListener,
    IFieldListener,
    IGroupEmptyCheckListener,
    instanceofAuthGroupEmptyCheckListener,
    instanceofGroupEmptyCheckListener,
    ValidateResult
} from "./search/field.listener";
import {LogCenterService} from "../../logcenter.service";
import {OurpalmTable, OurpalmTableColumn, TableConfig} from "ngx-ourpalm-table";
import {Subscription} from "rxjs/Subscription";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs/Observable";
import {
    LogColumnsState,
    LogColumnState,
    LogTablesState,
    LogTableState,
    SEND_LOG_DETAIL_DATA
} from "../../reducers/main.reducers";
import {ToastService} from "../../../shared/services/toast.service";
import {UserService} from "../../../widgets/user-box/user.service";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {urlParam} from "../../../shared/url-param.const";
import {BsModalRef, BsModalService} from "ngx-bootstrap";
import {OnSearchButtonWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {BillingOrderModalDetailComponent} from "./order/billing-order-modal-detail/billing-order-modal-detail.component";
import {BillingOrderModalRebuildComponent} from "./order/billing-order-modal-rebuild/billing-order-modal-rebuild.component";
import {BillingOrderService} from "./order/billing-order.service";
import {AccountManageModalDetailComponent} from "./account/account-manage-modal-detail/account-manage-modal-detail.component";
import {AccountResetPasswordComponent} from "./account/account-reset-password/account-reset-password";
import {AccountManageMarkTest} from "./account/account-manage-mark-test/account-manage-mark-test.component";
import {AccountManageBindAccount} from "./account/account-manage-bind-account/account-manage-bind-account.component";
import {AccountManageBlockAccount} from "./account/account-manage-block-account/account-manage-block-account.component";
import {
    isShowAccountLog,
    isShowAccountOrder,
    isShowBindAccount,
    isShowBuDan,
    isShowChongXinFaHuo,
    isShowDeviceFengTing,
    isShowDeviceJingYan,
    isShowIdfaLog,
    isShowIdfaOrder,
    isShowIpFengTing,
    isShowIpJingYan,
    isShowIpLog,
    isShowIpOrder,
    isShowMacLog,
    isShowMacOrder,
    isShowMarkAsTestAccount,
    isShowOrderDetail,
    isShowResetPassword,
    isShowRoleDetail,
    isShowRoleFengTing,
    isShowRoleJingYan,
    isShowRoleLog,
    isShowRoleOrder,
    isShowUserDetail,
    isShowUserFengTing,
    isShowUserJingYan
} from "./row-menus";
import {NEW_TAB_CUSTOM_PARAM} from "../../../widgets/control-sidebar/control-sidebar.component";
import {Router} from "../../../router/router";
import has = Reflect.has;

@Component({
    selector: 'logcenter-main',
    templateUrl: './main.component.html'
})
export class MainComponent extends OnSearchButtonWorking implements AfterContentInit, OnDestroy {

    @ViewChildren('field') fields: QueryList<ElementRef>;

    @ViewChild('orderRebuild')
    orderRebuild: BillingOrderModalRebuildComponent;
    @ViewChild('orderDetail')
    orderDetail: BillingOrderModalDetailComponent;

    @ViewChild('accountDetail')
    accountDetail: AccountManageModalDetailComponent;

    @ViewChild('accountResetPwd')
    accountResetPwd: AccountResetPasswordComponent;

    @ViewChild('accountMarkTest')
    accountMarkTest: AccountManageMarkTest;

    @ViewChild('accountBindAccount')
    accountBindAccount: AccountManageBindAccount;

    @ViewChild('accountBlock')
    accountBlock: AccountManageBlockAccount;

    logcolumns$: Observable<LogColumnsState>;
    logtables$: Observable<LogTablesState>;

    table: OurpalmTable;

    logType: string = '';
    logName: string;
    operateName: string;

    routeSub: Subscription;
    columnSub: Subscription;
    tableSub: Subscription;

    @ViewChild('template', {read: TemplateRef})
    template: TemplateRef<any>;
    modalRef: BsModalRef;

    constructor(private router: Router,
                private userService: UserService,
                private store$: Store<any>,
                private modalService: BsModalService,
                private tableConfig: TableConfig,
                private toastService: ToastService,
                private billingService: BillingOrderService,
                private service: LogCenterService) {
        super();
        this.logType = this.router.snapshot['logType'];
        this.logName = this.service.logName(this.logType);
        this.logcolumns$ = this.store$.select('logcenterColumns');
        this.logtables$ = this.store$.select('logcenterTables');
        this.table = this.tableConfig.create({
            columns: [],
            multiSort: false,
            autoLoadData: false,
            pagePosition: 'bottom',
            showRefreshBtn: false,
            showSettingBtn: false,
            ctrlSelect: true,
            // enabledFloatThead: true,
            loadData: (table: OurpalmTable, callback) => {
                this.onSearch(table.currentPage);
            },
            onDbClickRow: (rowIndex: number, rowData: any) => {
                // 用户数据25：双击时跳转至账户详情页（争光提供）；
                // 订单数据26：双击时跳转至订单详情页（赵伟提供）；
                // 角色数据8：双击时跳转至角色详情页（目前未开发，可以先跳转至日志详情页，后续下周单独提供出来）；
                // 其他    ：双击时跳转至日志详情页；
                if (this.logType == '25') {
                    this.accountDetail.show(rowData);
                } else if (this.logType == '26') {
                    this.orderDetail.show(rowData);
                } else if (this.logType == '8') {
                    this.tip();
                } else {
                    this.store$.dispatch({type: SEND_LOG_DETAIL_DATA, payload: rowData});
                    this.modalRef = this.modalService.show(this.template, {class: 'modal-lg', animated: false});
                }
            },
            rowMenus: [
                {
                    text: '前进',
                    iconCls: 'fa fa-arrow-right',
                    disabled: () => !this.router.canGo(),
                    onclick: () => this.router.go()
                }, {
                    text: '后退',
                    iconCls: 'fa fa-arrow-left',
                    disabled: () => !this.router.canBack(),
                    onclick: () => this.router.back()
                },
                {
                    text: '详情',
                    submenus: [
                        {
                            text: '用户详情',
                            show: () => isShowUserDetail(this.table),
                            onclick: () => {
                                this.accountDetail.show(this.table.getSelectedRows()[0]);

                            }
                        }, {
                            text: '角色详情',
                            show: () => isShowRoleDetail(this.table),
                            onclick: () => {
                                this.tip();
                            }
                        }, {
                            text: '订单详情',
                            show: () => isShowOrderDetail(this.table),
                            onclick: () => {
                                this.orderDetail.show(this.table.getSelectedRows()[0])
                            }
                        }]
                }, {
                    text: '封停',
                    show: () => {
                        return this.userService.hasPermission('data_center_suspension');
                    },
                    submenus: [
                        {
                            text: '角色封停',
                            show: () => isShowRoleFengTing(this.table),
                            onclick: () => {
                                // this.tip();
                                this.accountBlock.show(3, 0, this.table.getSelectedRows())
                            }
                        }, {
                            text: '用户封停',
                            show: () => isShowUserFengTing(this.table),
                            onclick: () => {
                                this.accountBlock.show(3, 1, this.table.getSelectedRows())
                            }
                        }, {
                            text: '设备封停',
                            show: () => isShowDeviceFengTing(this.table),
                            onclick: () => {
                                this.tip();
                            }
                        }, {
                            text: 'IP封停',
                            show: () => isShowIpFengTing(this.table),
                            onclick: () => {
                                this.tip();
                            }
                        }
                    ]
                }, {
                    text: '禁言',
                    show: () => {
                        return this.userService.hasPermission('data_center_ban');
                    },
                    submenus: [
                        {
                            text: '角色禁言',
                            show: () => isShowRoleJingYan(this.table),
                            onclick: () => {
                                this.accountBlock.show(1, 0, this.table.getSelectedRows())
                            }
                        }, {
                            text: '用户禁言',
                            show: () => isShowUserJingYan(this.table),
                            onclick: () => {
                                this.accountBlock.show(1, 1, this.table.getSelectedRows())
                            }
                        }, {
                            text: '设备禁言',
                            show: () => isShowDeviceJingYan(this.table),
                            onclick: () => {
                                this.tip();
                            }
                        }, {
                            text: 'IP禁言',
                            show: () => isShowIpJingYan(this.table),
                            onclick: () => {
                                this.tip();
                            }
                        }]
                }, {
                    text: '重置密码',
                    show: () => this.userService.hasPermission('data_center_resetPwd') ? isShowResetPassword(this.table) : false,
                    onclick: () => {
                        this.accountResetPwd.show(this.table.getSelectedRows()[0]);
                    }
                }, {
                    text: '账号绑定',
                    show: () => this.userService.hasPermission('data_center_accountBind') ? isShowBindAccount(this.table) : false,
                    onclick: () => {
                        this.accountBindAccount.show(this.table.getSelectedRows()[0])
                    }
                }, {
                    text: '标记测试号',
                    show: () => this.userService.hasPermission('data_center_addTest') ? isShowMarkAsTestAccount(this.table) : false,
                    onclick: () => {
                        this.accountMarkTest.show(this.table.getSelectedRows());
                    }
                }, {
                    text: '补单',
                    show: () => this.userService.hasPermission('data_center_repairOrder') ? isShowBuDan(this.table) : false,
                    onclick: () => {
                        this.orderRebuild.show(this.table.getSelectedRows()[0])
                    }
                }, {
                    text: '重新发货',
                    show: () => this.userService.hasPermission('data_center_delivery') ? isShowChongXinFaHuo(this.table) : false,
                    onclick: () => {
                        this.billingService.reSend(this.table.getSelectedRows()[0]);
                    }
                }, {
                    text: '搜索日志',
                    submenus: [
                        {
                            text: '按角色',
                            show: () => isShowRoleLog(this.table),
                            onclick: () => {
                                this.switchAllLogPage('20', {
                                    userInfoType: 'roleId',
                                    userInfoText: this.table.getSelectedRows()[0].roleId
                                });
                            }
                        }, {
                            text: '按账户',
                            show: () => isShowAccountLog(this.table),
                            onclick: () => {
                                this.switchAllLogPage('20', {
                                    userInfoType: 'userId',
                                    userInfoText: this.table.getSelectedRows()[0].userId
                                });
                            }
                        }, {
                            text: '按MAC',
                            show: () => isShowMacLog(this.table),
                            onclick: () => {
                                this.switchAllLogPage('20', {
                                    deviceInfoType: 'mac',
                                    deviceInfoText: this.table.getSelectedRows()[0].mac
                                });
                            }
                        }, {
                            text: '按IDFA',
                            show: () => isShowIdfaLog(this.table),
                            onclick: () => {
                                this.switchAllLogPage('20', {
                                    deviceInfoType: 'idfa',
                                    deviceInfoText: this.table.getSelectedRows()[0].idfa
                                });
                            }
                        }, {
                            text: '按IP',
                            show: () => isShowIpLog(this.table),
                            onclick: () => {
                                this.switchAllLogPage('20', {
                                    deviceInfoType: 'ip',
                                    deviceInfoText: this.table.getSelectedRows()[0].ip
                                });
                            }
                        }
                    ]
                }, {
                    text: '搜索订单',
                    submenus: [
                        {
                            text: '按角色',
                            show: () => isShowRoleOrder(this.table),
                            onclick: () => {
                                this.switchAllLogPage('26', {
                                    userInfoType: 'roleId',
                                    userInfoText: this.table.getSelectedRows()[0].roleId
                                });
                            }
                        }, {
                            text: '按账户',
                            show: () => isShowAccountOrder(this.table),
                            onclick: () => {
                                this.switchAllLogPage('26', {
                                    userInfoType: 'userId',
                                    userInfoText: this.table.getSelectedRows()[0].userId
                                });
                            }
                        }, {
                            text: '按MAC',
                            show: () => isShowMacOrder(this.table),
                            onclick: () => {
                                this.switchAllLogPage('26', {
                                    deviceInfoType: 'mac',
                                    deviceInfoText: this.table.getSelectedRows()[0].mac
                                });
                            }
                        }, {
                            text: '按IDFA',
                            show: () => isShowIdfaOrder(this.table),
                            onclick: () => {
                                this.switchAllLogPage('26', {
                                    deviceInfoType: 'idfa',
                                    deviceInfoText: this.table.getSelectedRows()[0].idfa
                                });
                            }
                        }, {
                            text: '按IP',
                            show: () => isShowIpOrder(this.table),
                            onclick: () => {
                                this.switchAllLogPage('26', {
                                    deviceInfoType: 'ip',
                                    deviceInfoText: this.table.getSelectedRows()[0].ip
                                });
                            }
                        }
                    ]
                }]
        });
    }

    tip() {
        this.toastService.pop('warning', '敬请期待');
    }

    /**
     * 点击display右键菜单，跳转到全部日志页面(20) 或 订单页面(26)
     */
    switchAllLogPage(logType: '20' | '26', query: any) {
        if (this.logType == logType) {
            this.fields.toArray().forEach((field: any) => {
                try {
                    (<IFieldListener>field).setValue({});
                    (<IFieldListener>field).setValue(query);
                } catch (e) {
                    console.error(e);
                }
            });
            setTimeout(() => {
                this.onSearch(1);
            }, 100);
        } else {
            let param: CustomQueryParam = {
                moduleKey: 'logcenter',
                operateKey: this.service.logOperateName(logType),
                name: '右键菜单点击跳转',
                showType: '1',
                systemType: '0',
                groupId: '',
                hash: `#/logcenter/${logType}?` + window.location.hash.split('?')[1],
                query: JSON.stringify(query),
                url: window.location.href
            };
            window.localStorage.setItem(NEW_TAB_CUSTOM_PARAM, JSON.stringify(param));
            //跳转页面
            this.router.navigate([`logcenter/${logType}`], {
                queryParams: urlParam,
                queryParamsHandling: 'merge'
            });
        }
    }

    /**
     * 检查查询条件是否满足
     */
    checkSearchCondition(): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            let fields: any[] = this.fields.toArray();

            //检查普通不能为空
            for (let field of fields) {
                // console.info('validate', field);
                let valid: ValidateResult;
                try {
                    valid = (<IFieldListener>field).validate();
                } catch (e) {
                    console.error(e);
                }
                if (!valid.isValid) {
                    this.toastService.pop('error', valid.errorDesc);
                    console.error(valid.errorDesc);
                    return reject();
                }
            }

            this.userService.hasPermission$('logcenter_limitQuery').take(1).subscribe((hasPermission: boolean) => {
                //检查授权不能为空
                if (!hasPermission) {
                    let checkAuth = false;
                    let isEmpty4Auth = true;
                    for (let field of fields) {
                        if (instanceofAuthGroupEmptyCheckListener(field)) {
                            let listener: IAuthGroupEmptyCheckListener = field;
                            if (listener.isCheckAuthGroup(this.logType)) {
                                checkAuth = true;
                                if (!listener.isAuthGroupEmpty()) {
                                    isEmpty4Auth = false;
                                    break;
                                }
                            }
                        }
                    }
                    if (checkAuth && isEmpty4Auth) {
                        this.toastService.pop('error', '业务信息、用户信息、设备信息至少填一个');
                        console.error('业务信息、用户信息、设备信息至少填一个');
                        return reject();
                    }
                }

                //检查分组验证不能为空
                let isEmpty4Group = true;
                let checkGroup = false;
                for (let field of fields) {
                    if (instanceofGroupEmptyCheckListener(field)) {
                        let listener: IGroupEmptyCheckListener = field;
                        if (listener.isCheckGroup(this.logType)) {
                            checkGroup = true;
                            if (!listener.isGroupEmpty()) {
                                isEmpty4Group = false;
                                break;
                            }
                        }
                    }
                }
                if (checkGroup && isEmpty4Group) {
                    this.toastService.pop('error', '业务信息、用户信息、设备信息至少填一个');
                    console.error('业务信息、用户信息、设备信息至少填一个');
                    return reject();
                }

                return resolve();
            });
        });
    }

    ngAfterContentInit(): void {
        setTimeout(() => this.AfterContentInit());
    }

    /**
     * 在子组件初始化完成后初始化页面监听
     */
    AfterContentInit(): void {
        /**
         * 监听路由变化，所有日志模块在一个页面，故通过监听路由变化来切换页面数据
         */
        this.routeSub = this.router.tab.params.subscribe((params) => {
            //路由变化事件 设置标题
            this.logType = params['logType'];
            this.logName = this.service.logName(this.logType);
            this.operateName = this.service.logOperateName(this.logType);

            //路由变化事件 设置查询参数
            this.logtables$.take(1).subscribe((_state: LogTablesState) => {
                if (this.searchState === 'None') {
                    let state: LogTableState = _state[params['logType']];
                    if (state && !state.initState) {
                        //设置查询条件
                        this.fields.toArray().forEach((field: any) => {
                            (<IFieldListener>field).setValue(state.params);
                        });
                    } else {
                        //清空查询条件
                        this.fields.toArray().forEach((field: any) => {
                            (<IFieldListener>field).setValue({});
                        });
                    }
                }
            });
        });

        /**
         * 监听路由变化，动态设置table的列配置
         */
        this.columnSub = Observable.combineLatest(this.router.tab.params, this.logcolumns$,
            (params: any, state: LogColumnsState) => [params['logType'], state[params['logType']]])
            .subscribe(([logType, state]) => {
                if (state && !state.initState) {
                    let columns: any = (<LogColumnState>state)
                        .columns
                        //列排序
                        .sort((col1, col2) => {
                            if (col1.sort > col2.sort) {
                                return 1;
                            }
                            if (col1.sort < col2.sort) {
                                return -1;
                            }
                            return 0;
                        })
                        //列数据转换
                        .map((column: any) => {
                            return {
                                field: column.name,
                                header: column.content,
                                show: column.view == '1' ? true : false,
                                styler: () => {
                                    return {textAlign: 'left'};
                                },
                                sort: column.isSort == '1' ? true : false,
                                sortOrder: column.order
                            };
                        });

                    //在列数据前面加入序号列
                    columns.unshift({
                        field: 'rownumbers',
                        header: '序号',
                        rownumbers: true,
                        show: false
                    });

                    //设置列缓存 设置列定义
                    this.table.setOptions({
                        cacheKey: 'logcenter-table-logtype' + logType,
                        cachePageSize: true,
                        cacheColumns: true,
                        columns: columns
                    });
                } else {
                    //重新加载列定义
                    this.service.loadLogColumns(logType);
                }
            });

        /**
         * 监听路由变化 设置table和查询条件
         */
        this.tableSub = Observable.combineLatest(this.router.tab.params, this.logtables$,
            (params: any, state: LogTablesState) => [params['logType'], state[`${this.router.tab.tabId}_${params['logType']}_${params.product}_${params.language}`]])
            .subscribe(([logType, _state]) => {
                let state: LogTableState = _state;
                if (state && !state.initState) {
                    //设置table数据
                    this.table.setPageData(state.page);
                } else {
                    //清空table数据
                    this.table.setPageData({
                        currentPage: this.table.currentPage,
                        pageSize: this.table.pageSize,
                        total: 0,
                        rows: []
                    });
                }
            });
    }

    /**
     * 当用户选中下拉查询时触发该事件
     */
    onSelectSearchItem(param: CustomQueryParam) {
        let params = JSON.parse(param.query);
        this.fields.toArray().forEach((field: any) => {
            try {
                (<IFieldListener>field).setValue(params);
            } catch (e) {
                console.error(e);
            }
        });
        setTimeout(() => {
            this.onSearch(1);
        }, 100);
    }

    /**
     * 保存当前查询条件，需要返回当前查询条件
     */
    onSearchAdding(): StringOrResolver {
        let params = {};
        let fields: any[] = this.fields.toArray();
        for (let field of fields) {
            let val = (<IFieldListener>field).getValue();
            params = {...params, ...val};
        }
        return JSON.stringify(params);
    }

    /**
     * 当用户点击控制台，回显查询条件时，会触发该事件，会刷新页面
     */
    onResumeSearchItem(param: CustomQueryParam) {
        this.onSelectSearchItem(param);
    }

    /**
     * 判断不需要从控制台恢复查询时会触发该事件
     */
    onResumeSearchNothing() {
    }

    /**
     * 用户点击查询按钮时触发
     */
    onSearch(currentPage: number = 1) {
        this.checkSearchCondition().then(() => {
            let params: any = {
                product: urlParam.product,
                locale: urlParam.language,
                productId: urlParam.product,
                localeId: urlParam.language
            };
            let fields: any[] = this.fields.toArray();
            // 构建查询参数
            for (let field of fields) {
                try {
                    let val = (<IFieldListener>field).getValue();
                    params = {...params, ...val};
                } catch (e) {
                    console.error(e);
                }
            }

            // 排序字段
            let columns = this.table.getSortColumns().filter((col) => !!col.sortOrder);
            let sortColumn: any = columns.length > 0 ? columns[0] : {};

            // 开始查询
            this.service.pageLogData(params.productId, params.localeId, `${this.router.tab.tabId}`, this.logType, currentPage, this.table.pageSize, params, this.table.total, sortColumn.field, sortColumn.sortOrder);
        }, () => {
            console.warn('reject');
        });
    }

    /**
     * 导出日志文件
     */
    export2File(fileType: string) {
        this.checkSearchCondition().then(() => {
            let params: any = {
                product: urlParam.product,
                locale: urlParam.language,
                productId: urlParam.product,
                localeId: urlParam.language,
            };
            let fields: any[] = this.fields.toArray();
            //构建查询条件
            for (let field of fields) {
                let val = (<IFieldListener>field).getValue();
                params = {...params, ...val};
            }
            let columns = this.table.getDisplayedColumns().map((column: OurpalmTableColumn) => {
                return {columnName: column.field, columnView: column.header}
            });
            this.service.exportLogs(this.logType, fileType, params, JSON.stringify(columns));
        }).catch(() => null);
    }

    ngOnDestroy(): void {
        this.routeSub && this.routeSub.unsubscribe();
        this.columnSub && this.columnSub.unsubscribe();
        this.tableSub && this.tableSub.unsubscribe();
    }

    orderReuildDone() {
        console.log('orderReuildDone');
    }
}
