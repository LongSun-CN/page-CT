import {Component, OnInit} from "@angular/core";
import {Field, FieldGroup, LOG_GROUPS} from "./detail.config";
import {Store} from "@ngrx/store";
import {LogColumnsState} from "../../reducers/main.reducers";
import {LogCenterService} from "../../logcenter.service";

@Component({
    selector: 'logcenter-main-detail',
    templateUrl: './detail.component.html'
})
export class MainDetailComponent implements OnInit {

    /*行数据*/
    rowData: any;
    /*列定义*/
    columns: any[];
    /*列分组 格式化信息*/
    groups: FieldGroup[];
    /*日志版块名称*/
    logName: string;

    constructor(private store$: Store<any>,
                private service: LogCenterService) {
        this.groups = LOG_GROUPS;
    }

    ngOnInit(): void {
        //加载行数据
        this.store$.select('logcenterDetail').filter((state: any) => !state.initState).take(1).timeout(500).subscribe((row) => {
            this.rowData = row;
            this.logName = row.logtype;
            let logType = row.logGroupId;
            //加载列定义
            this.store$
                .select('logcenterColumns')
                .do((state: LogColumnsState) => {
                    if (logType && !state[logType]) this.service.loadLogColumns(logType);
                })
                .filter((state: LogColumnsState) => !!state[logType])
                .take(1)
                .subscribe((state: LogColumnsState) => {
                    this.columns = state[logType].columns;
                    console.log('日志详情', this.rowData, this.columns);
                });
        }, () => {
            console.error('获取不到日志详情,页面是否刷新了,跳转到上个页面history.back()');
            window.history.back();
        });
    }

    isShowField(field: Field): boolean {
        if (typeof this.rowData[field.field] != "undefined" && this.showField(field))
            return true;
        return false;
    }

    private showField(field: Field): boolean {
        let arr = this.columns.filter((column: any) => column.name == field.field);
        return arr.length > 0 ? (arr[0].isDetail == '1' ? true : false) : false;
    }
}
