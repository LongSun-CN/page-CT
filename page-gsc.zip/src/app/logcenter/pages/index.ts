import {IndexComponent} from "./index/index.component";
import {MainComponent} from "./main/main.component";
import {field_components} from "./main/search/index";
import {MainDetailComponent} from "./detail/detail.component";
import {MainModalDetailComponent} from "./main/detail/detail.component";
import {orderComponent} from "./main/order/index";
import {accountManageComponent} from "./main/account/index";

export let logcenter_components = [
    IndexComponent,
    MainComponent,
    MainDetailComponent,
    MainModalDetailComponent,
    ...field_components,
   ...orderComponent,
    ...accountManageComponent
];
