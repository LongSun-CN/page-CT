import {locenterDetailReducer, logcenterColumnsReducer, logcenterTablesReducer} from "./main.reducers";

export const logcenterReducers = {
    logcenterColumns: logcenterColumnsReducer,
    logcenterTables: logcenterTablesReducer,
    logcenterDetail: locenterDetailReducer
};