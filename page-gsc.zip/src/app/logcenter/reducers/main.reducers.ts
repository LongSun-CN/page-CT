import {Action} from "@ngrx/store";
import {Page} from "ngx-ourpalm-table";

/**
 * 表格列定义数据
 */
export const INIT_TABLE_COLUMNS = '[LogCenter] Main Table Columns';

export interface LogColumnState {
    initState?: boolean;
    logType: string;
    columns: any[];
}

export type LogColumnsState = {
    [logType: string]: LogColumnState
};

const initialState: LogColumnsState = {};

export function logcenterColumnsReducer(state: LogColumnsState = initialState, action: Action) {
    switch (action.type) {
        case INIT_TABLE_COLUMNS:
            return {...state, ...(action.payload as LogColumnsState)};
        default:
            return state;
    }
}

/**
 * 表格数据 和 查询参数
 */
export const INIT_TABLE_DATA = '[LogCenter] Main Table Data';

export interface LogTableState {
    initState?: boolean;
    productId: string;
    language: string;
    tabId: string;
    logType: string;
    params: any;
    page: Page;
}

export type LogTablesState = {
    [tabId_logType_productId_language: string]: LogTableState
};

const initTableState: LogTablesState = {};

export function logcenterTablesReducer(state: LogTablesState = initTableState, action: Action) {
    switch (action.type) {
        case INIT_TABLE_DATA:
            let newTableState: LogTableState = action.payload;
            return {...state, ...{[`${newTableState.tabId}_${newTableState.logType}_${newTableState.productId}_${newTableState.language}`]: newTableState}};
        default:
            return state;
    }
}

/**
 * 日志详情 传递数据
 */
export const SEND_LOG_DETAIL_DATA = '[LogCenter Detail] LogCenter Log Detail';

export function locenterDetailReducer(state: any = {initState: true}, action: Action) {
    switch (action.type) {
        case SEND_LOG_DETAIL_DATA:
            return action.payload;
        default:
            return state;
    }
}