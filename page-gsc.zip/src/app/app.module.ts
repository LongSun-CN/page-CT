import {BrowserModule} from "@angular/platform-browser";
import {NgModule} from "@angular/core";
import {AppComponent} from "./app.component";
import {AppRoutingModule} from "./app-routing.module";
import {SharedModule} from "./shared/shared.module";
import {WidgetModule} from "./widgets/widget.module";
import {reducer} from "./shared/reducers/index";
import {StoreModule} from "@ngrx/store";
import {BaseService} from "./shared/services/base.service";
import {UserService} from "./widgets/user-box/user.service";
import {HttpService} from "./shared/services/httpx.service";
import {ToastService} from "./shared/services/toast.service";
import {CachedHttpInterceptor, ServerMaskInterceptor, ServerURLInterceptor} from "./shared/services/httpx.interceptor";
import {InterceptorService} from "ng2-interceptors";
import {RequestOptions, XHRBackend} from "@angular/http";
import {BBSModule} from "./bbs/bbs.module";
import {StoreDevtoolsModule} from "@ngrx/store-devtools";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {LogCenterModule} from "./logcenter/logcenter.module";
import {kfqaModule} from "./kfqa/kfqa.module";
import {PackageModule} from "./package/package.module";
import {MisModule} from "./mis/mis.module";

export function interceptorFactory(xhrBackend: XHRBackend, requestOptions: RequestOptions, URLInterceptor: ServerURLInterceptor, MaskInterceptor: ServerMaskInterceptor, ManageredLocalStorageInterceptor: CachedHttpInterceptor) {
    let service = new InterceptorService(xhrBackend, requestOptions);
    service.addInterceptor(URLInterceptor);
    service.addInterceptor(MaskInterceptor);
    service.addInterceptor(ManageredLocalStorageInterceptor);
    return service;
}

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        SharedModule.forRoot(),
        WidgetModule.forRoot(),
        /* 在全局初始化store */
        StoreModule.provideStore(reducer),
        /* 添加chrome调试工具 */
        StoreDevtoolsModule.instrumentOnlyWithExtension(),
        BBSModule,
        LogCenterModule,
        kfqaModule,
        PackageModule,
        MisModule
    ],
    providers: [
        BaseService,
        UserService,
        HttpService,
        ToastService,
        ServerURLInterceptor,
        ServerMaskInterceptor,
        CachedHttpInterceptor,
        {
            provide: InterceptorService,
            useFactory: interceptorFactory,
            deps: [XHRBackend, RequestOptions, ServerURLInterceptor, ServerMaskInterceptor, CachedHttpInterceptor]
        }
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
