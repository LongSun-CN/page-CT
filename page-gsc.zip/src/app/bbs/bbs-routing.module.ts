import {DashboardComponent} from "./pages/dashboard/dashboard.component";
import {SectionComponent} from "./pages/section/section.component";
import {TopicComponent} from "./pages/topic/topic.component";
import {SubSectionComponent} from "./pages/subsection/subsection.component";
import {UserComponent} from "./pages/user/user.component";
import {NoticeComponent} from "./pages/notice/notice.component";
import {UserDetailComponent} from "./pages/user/detail/user-detail.component";
import {TopicDetailComponent} from "./pages/topic/detail/topic-detail.component";
import {SectionEditComponent} from "./pages/section/edit/section-edit.component";
import {TopicOperateRecordComponent} from "./pages/topic/operate-record/operate-record.component";
import {Routes} from "../router";

export const bbs_routing: Routes = [
    {
        path: 'bbs',
        component: DashboardComponent,
        title: '社区首页'
    },
    {
        path: 'bbs/dashboard',
        component: DashboardComponent,
        title: '社区首页'
    },
    {
        path: 'bbs/section',
        component: SectionComponent,
        title: '主版块'
    },
    {
        path: 'bbs/section/edit/:sectionId',
        component: SectionEditComponent,
        title: '修改版块'
    },
    {
        path: 'bbs/subsection/:sectionId',
        component: SubSectionComponent,
        title: '子版块'
    },
    {
        path: 'bbs/topic/:sectionId?/:subSectionId?/:userType?/:nickname?',
        component: TopicComponent,
        title: '帖子管理'
    },
    {
        path: 'bbs/topic',
        component: TopicComponent,
        title: '帖子管理'
    },
    {
        path: 'bbs/topic_detail/:topicId',
        component: TopicDetailComponent,
        title: '帖子详情'
    },
    {
        path: 'bbs/topic_operate/:topicId',
        component: TopicOperateRecordComponent,
        title: '帖子操作记录'
    },
    {
        path: 'bbs/user',
        component: UserComponent,
        title: '用户管理'
    },
    {
        path: 'bbs/user/:userId',
        component: UserDetailComponent,
        title: '用户详情'
    },
    {
        path: 'bbs/public_notice',
        component: NoticeComponent,
        title: '公告管理'
    }
];