import {Component} from "@angular/core";

@Component({
    selector: 'bbs-speed-nav',
    styleUrls: ['./speed-nav.component.css'],
    templateUrl: './speed-nav.component.html'
})
export class SpeedNavComponent {

}