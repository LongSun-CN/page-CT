const default_ckeditor_opitons: any = {
    extraPlugins: 'emoji,upload', //加载emoji表情插件和图片上传插件
    uploadImageFileUrl: '', //上传图片时服务器的路径 http://localhost:8080/server/uploadImg.do
    uploadImageFileName: 'imageFile', //上传图片时服务器的文件名 <input type="file" name="imageFile"/>
    removeDialogTabs: 'image:advanced',
    image_previewText: ' ',
    customConfig: '',
    toolbarGroups: [
        {name: 'editing', groups: ['find', 'selection', 'spellchecker', 'editing']},
        {name: 'clipboard', groups: ['undo', 'clipboard']},
        {name: 'forms', groups: ['forms']},
        {name: 'basicstyles', groups: ['basicstyles', 'cleanup']},
        {name: 'links', groups: ['links']},
        {name: 'insert', groups: ['insert']},
        {name: 'document', groups: ['mode', 'document', 'doctools']},
        {name: 'tools', groups: ['tools']},
        '/',
        {name: 'colors', groups: ['colors']},
        {name: 'paragraph', groups: ['list', 'indent', 'blocks', 'align', 'bidi', 'paragraph']},
        {name: 'styles', groups: ['styles']},
        {name: 'others', groups: ['others']},
        {name: 'about', groups: ['about']}
    ],
    removeButtons: `Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteFromWord,Replace,Find,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,Image,ImageButton,HiddenField,Subscript,Superscript,CopyFormatting,Outdent,Indent,Blockquote,CreateDiv,BidiLtr,BidiRtl,Language,Anchor,Unlink,Link,Flash,SpecialChar,PageBreak,Iframe,Font,FontSize,ShowBlocks,About,SelectAll`
};

export const ckeditor_options = default_ckeditor_opitons;