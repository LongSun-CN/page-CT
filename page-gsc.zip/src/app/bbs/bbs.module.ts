import {NgModule} from "@angular/core";
import {WidgetModule} from "../widgets/widget.module";
import {declare_components} from "./pages/index";
import {services} from "./services/index";
import {SharedModule} from "../shared/shared.module";

@NgModule({
    imports: [
        WidgetModule,
        SharedModule
    ],
    declarations: [
        ...declare_components
    ],
    providers: [
        ...services
    ]
})
export class BBSModule {
}
