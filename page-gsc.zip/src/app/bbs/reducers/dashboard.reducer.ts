import {Action} from "@ngrx/store";

export const INIT_DASHBOARD = '[Dashboard] Init Dashboard';

export interface State {
    allReplyNum: number;
    allTopicNum: number;
    allUserNum: number;
    onlineUserNum: number;
    todayReplyNum: number;
    todayTopicNum: number;
    hotTopicInfos: any[];
    newTopicInfos: any[];
}

const initialState: State = {
    allReplyNum: 0,
    allTopicNum: 0,
    allUserNum: 0,
    onlineUserNum: 0,
    todayReplyNum: 0,
    todayTopicNum: 0,
    hotTopicInfos: [],
    newTopicInfos: []
};

export function dashboardReducer(state: State = initialState, action: Action) {
    switch (action.type) {
        case INIT_DASHBOARD:
            return action.payload;
        default:
            return state;
    }
}