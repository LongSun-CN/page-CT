import {Action} from "@ngrx/store";
import {Page} from "ngx-ourpalm-table";

/**
 * topic table reducer
 */
export const SEARCH_TOPIC = '[Topic] Search Topic';

export interface TopicState {
    initState?: boolean;
    sectionId: any;
    subSectionId: any;
    title: string;
    userType: string;
    nickname: string;
    startTime: string;
    endTime: string;
    range: string;
    status: string;
    user: string;
    resultId: string;
    page: Page;
}

export type TopicsState = {
    [tabId: string]: TopicState
}

export const initialTopicState: TopicState = {
    initState: true,
    sectionId: '',
    subSectionId: '',
    title: '',
    userType: '1',
    nickname: '',
    startTime: '',
    endTime: '',
    range: '',
    status: '',
    user: '',
    resultId: '',
    page: {
        currentPage: 1,
        pageSize: 10,
        total: 0,
        rows: []
    }
};

const initialState: TopicsState = {};

export function topicReducer(state: TopicsState = initialState, action: Action) {
    switch (action.type) {
        case SEARCH_TOPIC:
            return {...state, ...action.payload};
        default:
            return state;
    }
}

/**
 * topic detail reducer
 */
export const PAGE_TOPIC_DETAIL = '[Topic] Page Topic Detail';

export interface TopicDetailState {
    initState?: boolean;
    topicId: string;
    topicName: string;
    visitUrlPath: string;
    page: Page;
}

export type TopicDetailsState = {
    [topicId: string]: TopicDetailState
}

export const initialTopicDetailState: TopicDetailState = {
    initState: true,
    topicId: '',
    topicName: '',
    visitUrlPath: '',
    page: {
        currentPage: 0,
        pageSize: 10,
        total: 0,
        rows: []
    }
};

const initialTopicDetails: TopicDetailsState = {};

export function topicDetailReducer(states: TopicDetailsState = initialTopicDetails, action: Action) {
    switch (action.type) {
        case PAGE_TOPIC_DETAIL:
            let new_state: TopicDetailState = action.payload;
            let init_state: TopicDetailState = {} as any;
            Object.assign(init_state, initialTopicDetailState);
            let old_state: TopicDetailState = states[new_state.topicId] || init_state;
            if (new_state.page.currentPage != 1) {
                new_state.page.rows = [...old_state.page.rows, ...new_state.page.rows];
                new_state.topicName = new_state.topicName || old_state.topicName;
            }
            states[new_state.topicId] = new_state;
            return {...states};
        default:
            return states;
    }
}


/**
 * topic operate record reducer
 */
export const TOPIC_OPERATE_RECORD = '[Topic] Operate Record';

export interface TopicOperateState {
    initState?: boolean;
    topicId: string;
    records: any[];
}

const initialOperateDetail: TopicOperateState = {
    initState: true,
    topicId: '',
    records: []
};

export function topicOperateReducer(state: TopicOperateState = initialOperateDetail, action: Action) {
    switch (action.type) {
        case TOPIC_OPERATE_RECORD:
            return action.payload;
        default:
            return state;
    }
}
