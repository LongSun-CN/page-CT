import {Action} from "@ngrx/store";
import {Page} from "ngx-ourpalm-table";

export const SEARCH_SECTION = '[Section] Search Section';
export const ALL_SECTIONS = '[Section] All Sections';

export interface SectionState {
    initState?: boolean;
    name: string;
    status: string;
    page: Page;
}

export type SectionsState = {
    [tabId: string]: SectionState
}

const initialState: SectionsState = {};

/**
 * 分页查询 reducer
 */
export function sectionReducer(state: SectionsState = initialState, action: Action) {
    switch (action.type) {
        case SEARCH_SECTION:
            return {...state, ...action.payload};
        default:
            return state;
    }
}


export interface AllSectionState {
    initState?: boolean;
    sections: any[];
}

const initAllSectionState: AllSectionState = {
    initState: true,
    sections: []
};

/**
 * 查询所有 reducer
 */
export function allSectionReducer(state: AllSectionState = initAllSectionState, action: Action) {
    switch (action.type) {
        case ALL_SECTIONS:
            return action.payload;
        default:
            return state;
    }
}
