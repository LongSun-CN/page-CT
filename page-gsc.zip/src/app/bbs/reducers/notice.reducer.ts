import {Action} from "@ngrx/store";
import {Page} from "ngx-ourpalm-table";

export const SEARCH_NOTICE = '[Notice] Search Notice';

export interface NoticeState {
    initState?: boolean;
    criteria: any;
    page: Page;
}

export type NoticesState = {
    [tabId: string]: NoticeState
}

const initialState: NoticesState = {};

/**
 * 分页查询 reducer
 */
export function noticeReducer(state: NoticesState = initialState, action: Action) {
    switch (action.type) {
        case SEARCH_NOTICE:
            return {...state, ...action.payload};
        default:
            return state;
    }
}
