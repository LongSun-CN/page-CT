import {Action} from "@ngrx/store";
import {Page} from "ngx-ourpalm-table";

/**
 * 用户列表
 */
export const SEARCH_USER = '[User] BBS User List';

export interface UserState {
    initState?: boolean;
    criteria: any;
    page: Page;
}

export type UsersState = {
    [tabId: string]: UserState
}

const initialState: UsersState = {};

export function userReducer(state: UsersState = initialState, action: Action) {
    switch (action.type) {
        case SEARCH_USER:
            let new_state: UsersState = action.payload;
            return {...state, ...new_state};
        default:
            return state;
    }
}


/**
 *  用户详情
 */
export const USER_DETAIL = '[User] BBS User Detail';

export interface UserDetailState {
    initState?: boolean;
    user: any;
    logs: any[];
}

export type UsersDetailState = {
    [userId: string]: UserDetailState
}

const initialUserDetailState: UsersDetailState = {};

export function userDetailReducer(state: UsersDetailState = initialUserDetailState, action: Action) {
    switch (action.type) {
        case USER_DETAIL:
            return {...state, ...action.payload};
        default:
            return state;
    }
}


/**
 *  用户积分详情
 */
export const USER_SCORE_DETAIL = '[User] BBS User Score Detail';

export interface UserScoreDetailState {
    initState?: boolean;
    page: Page;
}

export type UsersScoreDetailState = {
    [userId: string]: UserScoreDetailState;
}

const initialUserScoreDetailState: UsersScoreDetailState = {};

export function userScoreDetailReducer(state: UsersScoreDetailState = initialUserScoreDetailState, action: Action) {
    switch (action.type) {
        case USER_SCORE_DETAIL:
            return {...state, ...action.payload};
        default:
            return state;
    }
}
