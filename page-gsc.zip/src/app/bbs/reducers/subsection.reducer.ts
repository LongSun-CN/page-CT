import {Action} from "@ngrx/store";
import {Page} from "ngx-ourpalm-table";

export const SEARCH_SUB_SECTION = '[SubSection] Search SubSection';

export const INIT_ALL_SUBSECTION = '[SubSection] Init All SubSection';
export const ALL_SUB_SECTION = '[SubSection] All SubSection';

export interface SubSectionState {
    initState?: boolean;
    sectionId: any;
    page: Page;
}

export type SubSectionsState = {
    [sectionId: string]: SubSectionState
}

const initialState: SubSectionsState = {};

/**
 * 分页查询 reducer
 */
export function subsectionReducer(state: SubSectionsState = initialState, action: Action) {
    switch (action.type) {
        case SEARCH_SUB_SECTION:
            return {...state, ...action.payload};
        default:
            return state;
    }
}


export interface AllSubSectionState {
    initState?: boolean;
    subSections: any[];
}

const initAllSubSectionState: AllSubSectionState = {
    initState: true,
    subSections: []
};

/**
 * 查询所有 reducer
 */
export function allSubSectionReducer(state: AllSubSectionState = initAllSubSectionState, action: Action) {
    switch (action.type) {
        case ALL_SUB_SECTION:
            return action.payload;
        case INIT_ALL_SUBSECTION:
            return initAllSubSectionState;
        default:
            return state;
    }
}
