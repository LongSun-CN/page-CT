import {topicDetailReducer, topicOperateReducer, topicReducer} from "./topic.reducer";
import {allSubSectionReducer, subsectionReducer} from "./subsection.reducer";
import {allSectionReducer, sectionReducer} from "./section.reducer";
import {dashboardReducer} from "./dashboard.reducer";
import {userDetailReducer, userReducer, userScoreDetailReducer} from "./user.reducer";
import {noticeReducer} from "./notice.reducer";

export const bbsReducers = {
    dashboard: dashboardReducer,
    section: sectionReducer,
    subsection: subsectionReducer,
    topic: topicReducer,
    topicDetail: topicDetailReducer,
    topicOperate: topicOperateReducer,
    allSections: allSectionReducer,
    allSubSections: allSubSectionReducer,
    user: userReducer,
    userDetail: userDetailReducer,
    userScore: userScoreDetailReducer,
    notice: noticeReducer
};