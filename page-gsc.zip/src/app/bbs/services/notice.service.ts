import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {environment} from "../../../environments/environment";
import {HttpService} from "../../shared/services/httpx.service";
import {NoticesState, NoticeState, SEARCH_NOTICE} from "../reducers/notice.reducer";
import {mask} from "../../shared/services/httpx.interceptor";

@Injectable()
export class NoticeService {

    constructor(private httpService: HttpService,
                private store$: Store<any>) {
    }

    pageNotice(tabId: string, currentPage: number, pageSize: number, title: string, startTime: string, endTime: string, createUserId: string): void {
        this.httpService
            .get(environment.getUrl('bbs/notice/getListPage.htm'), {
                id: '',
                title: title,
                startTimestamp: startTime,
                endTimestamp: endTime,
                createUserId: createUserId,
                page: currentPage,
                rows: pageSize,
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result) => {
                console.log(result);
                if (result.status == '0') {
                    let state: NoticeState = {
                        criteria: {
                            title, startTime, endTime, createUserId
                        },
                        page: {
                            currentPage: currentPage,
                            pageSize: pageSize,
                            total: result.data.totalCount,
                            rows: result.data.noticeInfos
                        }
                    };
                    let states: NoticesState = {
                        [tabId]: state
                    };
                    this.store$.dispatch({type: SEARCH_NOTICE, payload: states});
                }
            })
    }

    disabledNotice(ids: Array<any>) {
        return this.httpService
            .get(environment.getUrl('bbs/notice/updateStatus.htm'), {
                status: '2',
                ids: ids.join(','),
                ...mask
            })
            .map((response) => response.json())
    }

    isUserValid(user: string) {
        return this.httpService
            .get(environment.getUrl('bbs/topicuser/checkUser.htm'), {
                useridname: user,
                ...mask
            }).map(response => response.json());
    }

    addNotice(title: string, content: string, isAll: string, users: Array<any>, timeType: string) {
        return this.httpService
            .post(environment.getUrl('bbs/notice/addNotice.htm'), {
                title: title,
                content: content,
                isAll: isAll,
                users: users.join(','),
                timeType: timeType
            }).map(response => response.json());
    };
}