import {NoticeService} from "./notice.service";
import {UserService} from "./user.service";
import {TopicService} from "./topic.service";
import {SubSectionService} from "./subsection.service";
import {SectionService} from "./section.service";
import {DashboardService} from "./dashboard.service";

export const services = [
    DashboardService,
    SectionService,
    SubSectionService,
    TopicService,
    UserService,
    NoticeService
];