import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {environment} from "../../../environments/environment";
import {HttpService} from "../../shared/services/httpx.service";
import {
    PAGE_TOPIC_DETAIL,
    SEARCH_TOPIC,
    TOPIC_OPERATE_RECORD,
    TopicsState,
    TopicState
} from "../reducers/topic.reducer";
import {mask} from "../../shared/services/httpx.interceptor";

@Injectable()
export class TopicService {

    constructor(private httpService: HttpService,
                private store$: Store<any>) {
    }

    pageTopicDetail(currentPage: number, pageSize: number, topicId: string) {
        this.httpService
            .get(environment.getUrl('bbs/topic/getReplyPage.htm'), {
                page: currentPage,
                rows: pageSize,
                topicId,
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result) => {
                console.log(result);
                if (result.status == '0') {
                    let state = {
                        topicId,
                        topicName: result.data.topicName,
                        visitUrlPath: result.data.visitUrlPath,
                        page: {
                            currentPage: currentPage,
                            pageSize: pageSize,
                            total: result.data.totalCount,
                            rows: result.data.replyInfos
                        }
                    };
                    this.store$.dispatch({type: PAGE_TOPIC_DETAIL, payload: state});
                }
            })
    }

    pageTopic(tabId: string, currentPage: number, pageSize: number, sectionId: string, subSectionId: string, title: string, userType: string,
              nickname: string, user: string, startTime: string, endTime: string, range: string, status: string, resultId: any): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            this.httpService
                .get(environment.getUrl('bbs/topic/getListPage.htm'), {
                    sectionid: sectionId,
                    subsectionid: subSectionId,
                    titlekeywords: title,
                    usernicktype: userType,
                    usernickname: nickname,
                    isAdminUser: user,
                    startTimestamp: startTime || '',
                    endTimestamp: endTime || '',
                    status: status,
                    page: currentPage,
                    rows: pageSize,
                    resultId: resultId,
                    ...mask
                })
                .map((response) => response.json())
                .subscribe((result) => {
                    console.log(result);
                    if (result.status == '0') {
                        let state: TopicState = {
                            sectionId,
                            subSectionId,
                            title,
                            userType,
                            nickname,
                            startTime,
                            endTime,
                            range,
                            status,
                            user,
                            resultId: result.data.resultId,
                            page: {
                                currentPage: currentPage,
                                pageSize: pageSize,
                                total: result.data.totalCount,
                                rows: result.data.topicInfos
                            }
                        };
                        let states: TopicsState = {
                            [tabId]: state
                        };
                        this.store$.dispatch({type: SEARCH_TOPIC, payload: states});
                        resolve();
                    }
                })
        });
    }

    changeStatus(status: string, ids: Array<any>) {
        return this.httpService
            .post(environment.getUrl('bbs/topic/updateStatus.htm'), {
                status: status, //[1商用] [2暂停]
                ids: ids.join(','),
                ...mask
            })
            .map((response) => response.json());
    }

    changeTopStatus(status, topicId) {
        return this.httpService
            .post(environment.getUrl('bbs/topic/stickyTopicById.htm'), {
                isTop: status,
                topicId: topicId,
                ...mask
            })
            .map((response) => response.json());
    }

    topicOperate(topicId: string): void {
        this.httpService
            .get(environment.getUrl('bbs/topic/getOperateRecords.htm'), {
                topicId: topicId,
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result: any) => {
                console.log(result);
                if (result.status == '0') {
                    let state = {
                        topicId,
                        records: result.data.operateRecords
                    };
                    this.store$.dispatch({type: TOPIC_OPERATE_RECORD, payload: state});
                }
            })
    }

    moveTopic(topicId: string, sectionId: string, subSectionId: string) {
        return this.httpService
            .post(environment.getUrl('bbs/topic/moveTopicToSubsection.htm'), {
                topicId: topicId,
                sectionId: sectionId,
                subSectionId: subSectionId,
                ...mask
            })
            .map((response) => response.json())
    }

    addTopic(title: string, content: string, isHavePic: boolean, sectionId: string, subSectionId: string) {
        return this.httpService
            .post(environment.getUrl('bbs/topic/addTopic.htm'), {
                title: title,
                content: content,
                isHavePic: isHavePic === true ? '1' : '0',
                sectionId: sectionId,
                subSectionId: subSectionId,
                ...mask
            })
            .map((response) => response.json())
    }

    replyTopic(topicId: string, content: string) {
        return this.httpService
            .post(environment.getUrl('bbs/topic/replyTopic.htm'), {
                topicId: topicId,
                content: content,
                ...mask
            })
            .map((response) => response.json())
    };

    replyFloor(topicId: string, mainReplyId: string, subReplyId: string, content: string) {
        return this.httpService
            .post(environment.getUrl('bbs/topic/replyMainFloorUrl.htm'), {
                topicId: topicId,
                mainReplyId: mainReplyId,
                subReplyId: subReplyId,
                content: content,
                ...mask
            })
            .map((response) => response.json())
    };
    changeFloorStatus(param):Promise<any>{
        return this.httpService
            .post(environment.getUrl('bbs/topic/updateStatus.htm'),param)
            .map((response) => response.json())
            .toPromise()
    }
}