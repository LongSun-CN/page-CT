import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {ALL_SECTIONS, SEARCH_SECTION, SectionsState, SectionState} from "../reducers/section.reducer";
import {environment} from "../../../environments/environment";
import {HttpService} from "../../shared/services/httpx.service";
import {Observable} from "rxjs";
import {mask} from "../../shared/services/httpx.interceptor";

@Injectable()
export class SectionService {

    constructor(private httpService: HttpService,
                private store$: Store<SectionState>) {
    }

    pageSection(tabId: string, currentPage: number, pageSize: number, name: string, status: string): void {
        this.httpService
            .get(environment.getUrl('bbs/section/getListPage.htm'), {
                name: name,
                status: status,
                page: currentPage,
                rows: pageSize,
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result) => {
                console.log(result);
                if (result.status == '0') {
                    let state: SectionState = {
                        name: name,
                        status: status,
                        page: {
                            currentPage: currentPage,
                            pageSize: pageSize,
                            total: result.data.totalCount,
                            rows: result.data.sectionInfos
                        }
                    };
                    let states: SectionsState = {
                        [tabId]: state
                    };
                    this.store$.dispatch({type: SEARCH_SECTION, payload: states});
                }
            })
    }

    getAllSections(): void {
        this.httpService
            .get(environment.getUrl('bbs/section/getListPage.htm'), {
                page: 1,
                rows: 1000,
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result) => {
                if (result.status == '0') {
                    let state = {sections: result.data.sectionInfos};
                    this.store$.dispatch({type: ALL_SECTIONS, payload: state});
                }
            })
    }

    getSection(sectionId: string) {
        return this.httpService
            .get(environment.getUrl('bbs/section/findSectionById.htm'), {
                id: sectionId,
                ...mask
            })
            .map((response) => response.json());
    }

    sectionDetail(sectionId): Observable<any> {
        return this.httpService
            .get(environment.getUrl('bbs/section/getSectionPackage.htm'), {
                sectionId: sectionId,
                ...mask
            })
            .map((response) => response.json());
    }

    changeStatus(status, ids: Array<any>) {
        return this.httpService
            .get(environment.getUrl('bbs/section/updateStatus.htm'), {
                status: status, //[1商用] [2暂停]
                ids: ids.join(','),
                ...mask
            })
            .map((response) => response.json());
    }

    findGamePackagePage(productId: string) {
        return this.httpService
            .get(environment.getUrl('gameCode/gamePackage/findGamePackagePage.htm'), {
                productId,
                isValid: '1',
                currentPage: '-1',
                ...mask
            })
            .map((response) => response.json());
    }

    addSectionPackage(sectionId: string, packageId: string, startTime: string, endTime: string, getPeriod: string, activity: number) {
        return this.httpService
            .post(environment.getUrl('bbs/section/addOrUpdateSectionPackage.htm'), {
                sectionid: sectionId,
                packageid: packageId,
                starttime: startTime,
                endtime: endTime,
                getperiod: getPeriod,
                activity: activity,
                ...mask
            })
            .map((response) => response.json());
    }

    deleteSectionPackage(id: string | number) {
        return this.httpService
            .get(environment.getUrl('bbs/section/deleteSectionPackage.htm'), {
                id,
                ...mask
            })
            .map((response) => response.json());
    };
}