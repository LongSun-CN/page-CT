import {Injectable} from "@angular/core";
import {INIT_DASHBOARD, State} from "../reducers/dashboard.reducer";
import {Store} from "@ngrx/store";
import {environment} from "../../../environments/environment";
import {HttpService} from "../../shared/services/httpx.service";
import {no_mask} from "../../shared/services/httpx.interceptor";

@Injectable()
export class DashboardService {

    constructor(private http: HttpService,
                private store$: Store<State>) {
    }

    loadDashboard(): void {
        this.http
            .get(environment.getUrl('bbs/notice/getIndex.htm'), {...no_mask})
            .map((response) => response.json())
            .subscribe((result) => {
                console.log(result);
                if (result.status == '0' && result.data && result.data.indexData) {
                    let state = result.data.indexData as State;
                    this.store$.dispatch({type: INIT_DASHBOARD, payload: state});
                }
            })
    }

}
