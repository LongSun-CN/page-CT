import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {environment} from "../../../environments/environment";
import {HttpService} from "../../shared/services/httpx.service";
import {ALL_SUB_SECTION, SEARCH_SUB_SECTION, SubSectionsState, SubSectionState} from "../reducers/subsection.reducer";
import {mask} from "../../shared/services/httpx.interceptor";
import {Observable} from "rxjs/Observable";

@Injectable()
export class SubSectionService {

    constructor(private httpService: HttpService,
                private store$: Store<any>) {
    }

    pageSubSection(currentPage: number, pageSize: number, sectionId: any): void {
        this.httpService
            .get(environment.getUrl('bbs/subsection/getListPage.htm'), {
                page: currentPage,
                rows: pageSize,
                sectionId: sectionId,
                name: '',
                status: '',
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result) => {
                console.log(result);
                if (result.status == '0') {
                    let state: SubSectionState = {
                        sectionId: sectionId,
                        page: {
                            currentPage: currentPage,
                            pageSize: pageSize,
                            total: result.data.totalCount,
                            rows: result.data.subSectionInfos
                        }
                    };
                    let states: SubSectionsState = {
                        [sectionId]: state
                    };
                    this.store$.dispatch({type: SEARCH_SUB_SECTION, payload: states});
                }
            })
    }

    getAllSubSection(sectionId: any): void {
        this.httpService
            .get(environment.getUrl('bbs/subsection/getListPage.htm'), {
                page: 1,
                rows: 1000,
                sectionId: sectionId,
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result) => {
                console.log(result);
                if (result.status == '0') {
                    let state = {
                        subSections: result.data.subSectionInfos
                    };
                    this.store$.dispatch({type: ALL_SUB_SECTION, payload: state});
                }
            })
    }

    getAllSubSection$(sectionId: any): Observable<any> {
        return this.httpService
            .get(environment.getUrl('bbs/subsection/getListPage.htm'), {
                page: 1,
                rows: 1000,
                sectionId: sectionId,
                ...mask
            })
            .map((response) => response.json())
    }

    changeStatus(status, ids: Array<any>) {
        return this.httpService
            .get(environment.getUrl('bbs/subsection/updateStatus.htm'), {
                status: status, //[1商用] [2暂停]
                ids: ids.join(','),
                ...mask
            })
            .map((response) => response.json());
    }
}