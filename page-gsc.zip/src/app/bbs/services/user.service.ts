import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {environment} from "../../../environments/environment";
import {HttpService} from "../../shared/services/httpx.service";
import {
    SEARCH_USER,
    USER_DETAIL,
    USER_SCORE_DETAIL,
    UserDetailState,
    UserScoreDetailState,
    UsersDetailState,
    UsersScoreDetailState,
    UsersState,
    UserState
} from "../reducers/user.reducer";
import {mask, no_mask} from "../../shared/services/httpx.interceptor";

@Injectable()
export class UserService {

    constructor(private httpService: HttpService,
                private store$: Store<any>) {
    }

    pageUser(tabId: string, currentPage: number, pageSize: number, username: string, nickname: string, isBan: string, isShutup: string, onlinestatus: string, resultId: string): void {
        this.httpService
            .get(environment.getUrl('bbs/topicuser/getListPage.htm'), {
                username: username,
                nickname: nickname,
                isBan: isBan,
                isShutup: isShutup,
                onlinestatus: onlinestatus,
                resultId: resultId,
                page: currentPage,
                rows: pageSize,
                id: '',
                isReloadResult: '',
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result) => {
                console.log(result);
                if (result.status == '0') {
                    let state: UserState = {
                        criteria: {
                            username, nickname, isShutup, isBan, onlinestatus, resultId
                        },
                        page: {
                            currentPage,
                            pageSize,
                            total: result.data.totalCount,
                            rows: result.data.userInfos
                        }
                    };
                    let states: UsersState = {
                        [tabId]: state
                    };
                    this.store$.dispatch({type: SEARCH_USER, payload: states});
                }
            })
    }

    /**
     * 用户详细信息
     */
    userDetail(userId: string) {
        this.httpService
            .get(environment.getUrl('bbs/topicuser/findTopicUserById.htm'), {
                userId,
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result) => {
                console.log(result);
                if (result.status == '0') {
                    let state: UserDetailState = {
                        user: result.data.userInfo,
                        logs: result.data.operateLogs
                    };
                    let states: UsersDetailState = {
                        [userId]: state
                    };
                    this.store$.dispatch({type: USER_DETAIL, payload: states});
                }
            })
    }

    /**
     * 用户积分变更
     */
    pageUserScore(currentPage: number, pageSize: number, userId: string) {
        this.httpService
            .get(environment.getUrl('bbs/topicuser/findUserPointDetail.htm'), {
                userId,
                page: currentPage,
                rows: pageSize,
                ...mask
            })
            .map((response) => response.json())
            .subscribe((result) => {
                console.log(result);
                if (result.status == '0') {
                    let state: UserScoreDetailState = {
                        page: {
                            currentPage,
                            pageSize,
                            total: result.data.totalCount,
                            rows: result.data.details
                        }
                    };
                    let states: UsersScoreDetailState = {
                        [userId]: state
                    };
                    this.store$.dispatch({type: USER_SCORE_DETAIL, payload: states});
                }
            })
    }

    /**
     * 清空积分
     */
    clearScore(userIds: Array<any>, desc: string) {
        return this.httpService
            .post(environment.getUrl('bbs/topicuser/clearUserActivityPoints.htm'), {
                userId: userIds.join(','),
                desc: desc,
                ...mask
            })
            .map((response) => response.json())
    }

    /**
     * 修改积分
     */
    modifyScore(userIds: Array<any>, increment: number, desc: string) {
        return this.httpService
            .post(environment.getUrl('bbs/topicuser/modifyUserActivityPoints.htm'), {
                userId: userIds.join(','),
                increment: increment,
                desc: desc,
                ...mask
            })
            .map((response) => response.json())
    }

    /**
     * 禁言限制
     */
    muteLimite(userIds: Array<any>, type: any, startTime: any, endTime: any, desc: string) {
        return this.httpService
            .post(environment.getUrl('bbs/topicuser/limitTopicUser.htm'), {
                isBan: '',
                banStartTime: '',
                banEndTime: '',
                isShutup: type,
                shutUpStartTime: startTime,
                shutUpEndTime: endTime,
                content: desc,
                userIds: userIds.join(','),
                ...mask
            })
            .map((response) => response.json())
    }

    /**
     * 封停限制
     */
    closureLimite(userIds: Array<any>, type: any, startTime: any, endTime: any, desc: string,disableCreated:number) {
        return this.httpService
            .post(environment.getUrl('bbs/topicuser/limitTopicUser.htm'), {
                isBan: type,
                banStartTime: startTime,
                banEndTime: endTime,
                disableCreated:disableCreated,
                isShutup: '',
                shutUpStartTime: '',
                shutUpEndTime: '',
                content: desc,
                userIds: userIds.join(','),
                ...mask
            })
            .map((response) => response.json())
    }

    /**
     * 导出用户信息
     */
    exportUser(exportType: string, columns: Array<any>, username: string, nickname: string, onlinestatus: string, ids: Array<any>) {
        return this.httpService
            .download(environment.getUrl('bbs/topicuser/downloadGoodsExcel.htm'), {
                columns: JSON.stringify(columns),
                username: username,
                nickname: nickname,
                status: '',
                onlinestatus: onlinestatus,
                exportType: exportType,
                ids: ids.join(','),
                ...no_mask
            });
    };
}