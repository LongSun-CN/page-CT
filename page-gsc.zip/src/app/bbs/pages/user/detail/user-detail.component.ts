import {Component, OnDestroy} from "@angular/core";
import {Store} from "@ngrx/store";
import {UserService} from "../../../services/user.service";
import {Observable, Subscription} from "rxjs";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {Router} from "../../../../router/router";
import {UsersDetailState, UsersScoreDetailState} from "../../../reducers/user.reducer";

@Component({
    selector: 'bbs-user',
    templateUrl: './user-detail.component.html'
})
export class UserDetailComponent implements OnDestroy {

    /**用户详情和操作记录 */
    userDetail$: Observable<UsersDetailState>;
    userSubscribe: Subscription;

    /**积分变更记录 */
    scoretable$: Observable<any>;
    scoreSubscribe: Subscription;

    table: OurpalmTable;

    userId: string;

    user: any = {};
    logs: any[] = [];

    constructor(private userService: UserService,
                private router: Router,
                private store$: Store<any>) {
        this.userDetail$ = store$.select('userDetail');
        this.scoretable$ = store$.select('userScore');

        this.userId = this.router.snapshot.params.userId;

        //用户详情数据流
        this.userSubscribe = this.userDetail$
            .map((states: UsersDetailState) => states[this.userId])
            .subscribe((state) => {
                if (!state || state.initState) {
                    this.userService.userDetail(this.userId);
                } else {
                    this.user = {...this.user, ...state.user};
                    this.logs = [...state.logs];
                }
            });

        //初始化表格
        this.table = new OurpalmTable({
            cacheKey: 'bbs-user-score-detail',
            cacheColumns: true,
            cachePageSize: true,
            autoLoadData: false,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                this.userService.pageUserScore(this.table.currentPage, this.table.pageSize, this.userId);
            }
        });

        //table数据流
        this.scoreSubscribe = this.scoretable$
            .map((states: UsersScoreDetailState) => states[this.userId])
            .subscribe((state) => {
                if (!state || state.initState) {
                    this.userService.pageUserScore(this.table.currentPage, this.table.pageSize, this.userId);
                } else {
                    this.table.setPageData(state.page);
                }
            });
    }

    ngOnDestroy(): void {
        this.userSubscribe.unsubscribe();
        this.scoreSubscribe.unsubscribe();
    }
}
