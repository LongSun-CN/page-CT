import {Component, OnDestroy, ViewChild} from "@angular/core";
import {Store} from "@ngrx/store";
import {OurpalmTable, Page, TableConfig} from "ngx-ourpalm-table";
import {UsersState, UserState} from "../../reducers/user.reducer";
import {Observable, Subscription} from "rxjs";
import {UserService} from "../../services/user.service";
import {UserService as User} from "../../../widgets/user-box/user.service";
import {ModalDirective} from "ngx-bootstrap";
import {isEmpty} from "ramda";
import {ToastService} from "../../../shared/services/toast.service";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {Router} from "../../../router/router";
import "rxjs/add/operator/map";

@Component({
    selector: 'bbs-user',
    templateUrl: './user.component.html'
})
export class UserComponent implements OnDestroy, OnSearchBtnWorking {

    user$: Observable<UsersState>;
    tableSubscribe: Subscription;

    table: OurpalmTable;

    /** 修改积分dialog */
    @ViewChild('modifyScoreModal')
    modifyScoreModal: ModalDirective;

    /** 清空积分dialog */
    @ViewChild('clearScoreModal')
    clearScoreModal: ModalDirective;

    /** 禁言dialog */
    @ViewChild('muteModal')
    muteModal: ModalDirective;

    /** 封停dialog */
    @ViewChild('closureModal')
    closureModal: ModalDirective;

    /** 修改积分表单 */
    modify: any = {};
    /** 清空积分描述 */
    clearDesc: string;
    /** 禁言表单 */
    mute: any = {};
    /** 封停表单 */
    closure: any = {disableCreated: 2};

    //查询条件对象
    criteria: any = {
        username: '',
        nickname: '',
        isShutup: '',
        isBan: '',
        onlinestatus: '',
        resultId: ''
    };

    tabId: string;

    constructor(private store$: Store<any>,
                private toastService: ToastService,
                private userService: UserService,
                private tableConfig: TableConfig,
                private router: Router,
                private user: User) {
        this.user$ = this.store$.select('user');
        //初始化表格
        this.table = this.tableConfig.create({
            cacheKey: 'bbs-user',
            pagePosition: 'bottom',
            defaultPageSize: 100,
            pageList: [100, 200],
            cacheColumns: true,
            cachePageSize: true,
            autoLoadData: false,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                this.onSearch(table.currentPage);
            },
            onDbClickRow: (rowIndex, rowData) => {
                this.user.hasPermission$('bbs_userManage_getUserInfo').take(1).subscribe((hasPermission: boolean) => {
                    if (hasPermission) {
                        this.router.navigate(['bbs/user', rowData.id], {
                            queryParamsHandling: 'merge'
                        });
                    }
                });
            },
            rowMenus: [{
                text: '前进',
                iconCls: 'fa fa-arrow-right',
                disabled: () => !this.router.canGo(),
                onclick: () => this.router.go()
            }, {
                text: '后退',
                iconCls: 'fa fa-arrow-left',
                disabled: () => !this.router.canBack(),
                onclick: () => this.router.back()
            }, {
                text: '禁言',
                iconCls: 'fa fa-pinterest',
                onclick: () => this.openMuteDialog()
            }, {
                text: '封停',
                iconCls: 'fa fa-pinterest-square',
                onclick: () => this.openClosureDialog()
            }, {
                text: '清空积分',
                iconCls: 'fa fa-drupal',
                onclick: () => this.openClearScoreDialog()
            }, {
                text: '修改积分',
                iconCls: 'fa fa-edit',
                onclick: () => this.openModifyScoreDialog()
            }, {
                text: '详情',
                iconCls: 'fa fa-info-circle',
                disabled: () => this.table.getSelectedRows().length != 1,
                onclick: () => {
                    this.router.navigate(['bbs/user', this.table.getSelectedRows()[0].id], {
                        queryParamsHandling: 'merge'
                    });
                }
            }]
        });
        this.tabId = `${this.router.tab.tabId}`;
    }

    onSelectSearchItem(param: CustomQueryParam) {
        let params = JSON.parse(param.query);
        this.criteria = {...this.criteria, ...params};
        this.onSearch(1);
    }

    onSearch(currentPage: number = 1) {
        this.userService.pageUser(`${this.router.tab.tabId}`, currentPage, this.table.pageSize, this.criteria.username,
            this.criteria.nickname, this.criteria.isBan, this.criteria.isShutup,
            this.criteria.onlinestatus, this.criteria.resultId);
    }

    onSearchAdding(): StringOrResolver {
        return JSON.stringify(this.criteria);
    }

    onResumeSearchItem(param: CustomQueryParam) {
        // 调用初始化
        this.onResumeSearchNothing();
        // 恢复查询条件
        this.onSelectSearchItem(param);
    }

    /**
     * 初始化
     */
    onResumeSearchNothing() {
        this.tableSubscribe = this.user$
            .subscribe((states: UsersState) => {
                let state: UserState = states[this.tabId];
                if (!state || state.initState) {
                    this.table.refresh();
                } else {
                    this.criteria = {...this.criteria, ...state.criteria};
                    this.table.setPageData(state.page);
                }
            });
    }

    openModifyScoreDialog() {
        if (this.table.getSelectedRows().length == 0) {
            return this.toastService.translate('error', '请至少选择一条数据');
        }

        this.modify = {scoreCount: 0, scoreDesc: ''};
        this.modifyScoreModal.show();
    }

    modifyScore() {
        if (isEmpty(this.modify.scoreCount)) {
            return this.toastService.translate('error', '积分不能为空');
        }
        if (isEmpty(this.modify.scoreDesc)) {
            return this.toastService.translate('error', '描述不能为空');
        }
        let ids = this.table.getSelectedRows().map(row => row.id);
        this.userService.modifyScore(ids, this.modify.scoreCount, this.modify.scoreDesc).subscribe(result => {
            if (result.status == '0') {
                this.toastService.translate('success', '修改成功');
                this.modifyScoreModal.hide();
                this.table.refresh();
            } else {
                this.toastService.translate('error', result.desc);
            }
        });
    }

    openClearScoreDialog() {
        if (this.table.getSelectedRows().length == 0) {
            return this.toastService.translate('error', '请至少选择一条数据');
        }

        this.clearDesc = '';
        this.clearScoreModal.show();
    }

    clearScore() {
        if (isEmpty(this.clearDesc)) {
            return this.toastService.translate('error', '清空描述不能为空');
        }
        let ids = this.table.getSelectedRows().map(row => row.id);
        this.userService.clearScore(ids, this.clearDesc).subscribe(result => {
            if (result.status == '0') {
                this.toastService.translate('success', '修改成功');
                this.clearScoreModal.hide();
                this.table.refresh();
            } else {
                this.toastService.translate('error', result.desc);
            }
        });
    }

    openMuteDialog() {
        if (this.table.getSelectedRows().length == 0) {
            return this.toastService.translate('error', '请至少选择一条数据');
        }

        this.mute = {limit: '', time: '', desc: ''};
        this.muteModal.show();
    }

    setMuteLimit() {
        if (isEmpty(this.mute.limit)) {
            return this.toastService.translate('error', '请选择禁言限制');
        }
        if (this.mute.limit == '1' && isEmpty(this.mute.time)) {
            return this.toastService.translate('error', '请设置限制时间');
        }
        if (isEmpty(this.mute.desc)) {
            return this.toastService.translate('error', '描述不能为空');
        }
        let ids = this.table.getSelectedRows().map(row => row.id);
        this.userService.muteLimite(ids, this.mute.limit, this.mute.time.split(' - ')[0], this.mute.time.split(' - ')[1], this.mute.desc
        ).subscribe(result => {
            if (result.status == '0') {
                this.toastService.translate('success', '修改成功');
                this.muteModal.hide();
                this.table.refresh();
            } else {
                this.toastService.translate('error', result.desc);
            }
        });
    }

    openClosureDialog() {
        if (this.table.getSelectedRows().length == 0) {
            return this.toastService.translate('error', '请至少选择一条数据');
        }

        this.closure = {limit: '', time: '', desc: ''};
        this.closureModal.show();
    }

    setClosureLimit() {
        if (isEmpty(this.closure.limit)) {
            return this.toastService.translate('error', '请选择封停限制');
        }
        if (this.closure.limit == '1' && isEmpty(this.mute.time)) {
            return this.toastService.translate('error', '请设置限制时间');
        }
        if (isEmpty(this.closure.desc)) {
            return this.toastService.translate('error', '描述不能为空');
        }
        let ids = this.table.getSelectedRows().map(row => row.id);
        this.userService.closureLimite(ids, this.closure.limit, this.closure.time.split(' - ')[0], this.closure.time.split(' - ')[1], this.closure.desc,
            this.closure.disableCreated
        ).subscribe(result => {
            if (result.status == '0') {
                this.toastService.translate('success', '修改成功');
                this.closureModal.hide();
                this.table.refresh();
            } else {
                this.toastService.translate('error', result.desc);
            }
        });
    }

    exportUser(type: string) {
        let columns = this.table.getDisplayedColumns().map((column) => {
            return {
                columnView: column.header,
                columnName: column.field
            }
        });
        let ids = this.table.getSelectedRows().map(row => row.id);
        this.userService.exportUser(type, columns, this.criteria.username, this.criteria.nickname, this.criteria.onlinestatus, ids);
    }

    ngOnDestroy(): void {
        this.tableSubscribe && this.tableSubscribe.unsubscribe();
    }
}
