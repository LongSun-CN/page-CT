import {Component, OnDestroy} from "@angular/core";
import {Store} from "@ngrx/store";
import {TopicService} from "../../../services/topic.service";
import {Observable} from "rxjs/Observable";
import {TopicOperateState} from "../../../reducers/topic.reducer";
import {Subscription} from "rxjs/Subscription";
import {Router} from "../../../../router/router";

@Component({
    selector: 'bbs-topic-operate',
    templateUrl: './operate-record.component.html'
})
export class TopicOperateRecordComponent implements OnDestroy {

    operate$: Observable<TopicOperateState>;
    subscribe: Subscription;

    records: any[] = [];

    constructor(private topicService: TopicService,
                private router: Router,
                private store$: Store<any>) {
        //所有主版块
        this.operate$ = store$.select('topicOperate');
        //表格数据流
        this.subscribe = this.operate$.subscribe((state) => {
            let topicId = this.router.snapshot['topicId'];
            if (state.initState || topicId != state.topicId) {
                this.topicService.topicOperate(topicId);
            } else {
                this.records = state.records;
            }
        });
    }

    ngOnDestroy(): void {
        this.subscribe.unsubscribe();
    }
}