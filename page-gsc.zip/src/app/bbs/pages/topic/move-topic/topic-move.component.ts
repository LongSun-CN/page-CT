import {Component, EventEmitter, OnDestroy, Output, ViewChild} from "@angular/core";
import {ModalDirective} from "ngx-bootstrap";
import {SubSectionService} from "../../../services/subsection.service";
import {TopicService} from "../../../services/topic.service";
import {Store} from "@ngrx/store";
import {AllSectionState} from "../../../reducers/section.reducer";
import {Observable} from "rxjs/Observable";
import {ToastService} from "../../../../shared/services/toast.service";
@Component({
    selector: 'bbs-topic-move',
    templateUrl: './topic-move.component.html'
})
export class TopicMoveComponent implements OnDestroy {

    @ViewChild('moveModal') moveModal: ModalDirective;

    @Output() successFn: EventEmitter<void> = new EventEmitter<void>();

    sections$: Observable<any>;
    subSections$: Observable<any>;

    topic: any = {};
    selectedSection: any[] = [];
    selectedSubSection: any[] = [];

    constructor(private subSectionSevice: SubSectionService,
                private topicService: TopicService,
                private toasterService: ToastService,
                private store$: Store<any>) {
        //所有主版块
        this.sections$ = store$.select('allSections').map((state: AllSectionState) => {
            return state.sections.map((section: any) => {
                return {id: section.id, text: section.name};
            })
        });
    }

    show(topic: any) {
        this.topic = topic;
        this.selectedSection = [{id: this.topic.sectionId, text: this.topic.sectionName}];
        this.selectedSubSection = [{id: this.topic.subSectionId, text: this.topic.subSectionName}];
        this.onSectionSelected(true);
        this.moveModal.show();
    }

    onSectionSelected(isInit: boolean = false) {
        this.subSections$ = this.subSectionSevice.getAllSubSection$(this.selectedSection[0].id)
            .map(result => result.status == '0' ? result.data.subSectionInfos : [])
            .map((subSections: any[]) => {
                if (!isInit) this.selectedSubSection = [];

                return subSections.map((subSection: any) => {
                    return {
                        id: subSection.id,
                        text: subSection.name
                    }
                })
            });
    }

    moveTopicSection() {
        this.topicService.moveTopic(this.topic.id, this.selectedSection[0].id, this.selectedSubSection[0].id)
            .subscribe(result => {
                if (result.status == '0') {
                    this.moveModal.hide();
                    this.successFn.emit();
                    this.toasterService.translate('success', '修改成功');
                } else {
                    this.toasterService.translate('error', result.desc);
                }
            });
    }


    ngOnDestroy(): void {
    }

}