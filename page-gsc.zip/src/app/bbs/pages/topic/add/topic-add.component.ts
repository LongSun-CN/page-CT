import {Component, EventEmitter, Output, ViewChild} from "@angular/core";
import {ModalDirective} from "ngx-bootstrap";
import {ckeditor_options} from "../../../ckeditor.config";
import {Observable} from "rxjs/Observable";
import {AllSectionState} from "../../../reducers/section.reducer";
import {Store} from "@ngrx/store";
import {TopicService} from "../../../services/topic.service";
import {SubSectionService} from "../../../services/subsection.service";
import {isEmpty} from "ramda";
import {environment} from "../../../../../environments/environment";
import {ToastService} from "../../../../shared/services/toast.service";

@Component({
    selector: 'bbs-topic-add',
    templateUrl: './topic-add.component.html'
})
export class TopicAddComponent {

    @ViewChild('addModal') addModal: ModalDirective;

    @Output() successFn: EventEmitter<void> = new EventEmitter<void>();

    sections$: Observable<any>;
    subSections$: Observable<any>;

    ckeditor_config: any;

    title: string;
    content: string;
    isHavePic: boolean;
    selectedSection: any[] = [];
    selectedSubSection: any[] = [];

    constructor(private subSectionSevice: SubSectionService,
                private topicService: TopicService,
                private toasterService: ToastService,
                private store$: Store<any>) {
        //所有主版块
        this.sections$ = store$.select('allSections').map((state: AllSectionState) => {
            return state.sections.map((section: any) => {
                return {id: section.id, text: section.name};
            })
        });

        this.ckeditor_config = {
            ...ckeditor_options,
            uploadImageFileName: 'file',
            uploadImageFileUrl: environment.getUrl('bbs/topic/uploadFile.htm'),
            uploadImageSuccessEvent: (result, resolve, reject) => {
                result = JSON.parse(result);
                if (result.status == '0') {
                    this.isHavePic = true;
                    resolve(result.data.relativePath);
                } else {
                    reject();
                    alert(result.desc);
                }
            },
            uploadImageErrorEvent: (result, resolve, reject) => {
                this.toasterService.translate('error', '网络异常，请稍后再试');
            }
        }
    }

    onSectionSelected(selected: any) {
        this.subSections$ = this.subSectionSevice.getAllSubSection$(selected.id)
            .map(result => result.status == '0' ? result.data.subSectionInfos : [])
            .map((subSections: any[]) => {
                this.selectedSubSection = [];
                return subSections.map((subSection: any) => {
                    return {
                        id: subSection.id,
                        text: subSection.name
                    }
                })
            });
    }

    addTopic() {
        if (this.selectedSection.length == 0) {
            return this.toasterService.translate('error', '请选择主版块');
        }
        if (this.selectedSubSection.length == 0) {
            return this.toasterService.translate('error', '请选择子版块');
        }
        if (isEmpty(this.title)) {
            return this.toasterService.translate('error', '请输入帖子标题');
        }
        if (isEmpty(this.content)) {
            return this.toasterService.translate('error', '请输入帖子正文');
        }

        this.topicService.addTopic(this.title, this.content, this.isHavePic, this.selectedSection[0].id, this.selectedSubSection[0].id)
            .subscribe(result => {
                if (result.status == '0') {
                    this.addModal.hide();
                    this.successFn.emit();
                    this.toasterService.translate('success', '添加成功');
                } else {
                    this.toasterService.translate('error', result.desc);
                }
            });
    }

    show() {
        this.title = '';
        this.content = '';
        this.isHavePic = false;
        this.selectedSection = [];
        this.selectedSubSection = [];
        this.addModal.show();
    }
}