import {Component, OnDestroy} from "@angular/core";
import {Store} from "@ngrx/store";
import {TopicService} from "../../../services/topic.service";
import {initialTopicDetailState, TopicDetailsState, TopicDetailState} from "../../../reducers/topic.reducer";
import {Observable, Subscription} from "rxjs";
import {Router} from "../../../../router";
import {ToastService} from "../../../../shared/services/toast.service";

@Component({
    selector: 'bbs-topic-detail',
    styleUrls: ['./topic-detail.component.css'],
    templateUrl: './topic-detail.component.html'
})
export class TopicDetailComponent implements OnDestroy {

    topicDetail$: Observable<TopicDetailsState>;
    subscribe: Subscription;

    state: TopicDetailState;
    topicId: string;

    constructor(private topicService: TopicService,
                private router: Router,
                private store$: Store<any>,
                private toast: ToastService) {
        this.topicId = this.router.tab.snapshot.params.topicId;
        this.topicDetail$ = this.store$.select('topicDetail');

        this.subscribe = this.topicDetail$
            .map((states: TopicDetailsState) => states[this.topicId] || initialTopicDetailState)
            .subscribe((state) => {
                this.state = {...state, ...{topicId: this.topicId}};
                if (!state || state.initState || this.topicId != state.topicId) {
                    this.topicService.pageTopicDetail(1, this.state.page.pageSize, this.topicId);
                }
            });
    }

    nextPage() {
        this.topicService.pageTopicDetail(this.state.page.currentPage + 1, this.state.page.pageSize, this.state.topicId);
    }

    ngOnDestroy(): void {
        this.subscribe && this.subscribe.unsubscribe();
    }

    changeRevertStatus(topic) {
        let param: any = {
            status: topic.status == 1 ? '2' : '1',
            ids: topic.topicId,
            mainReplyId: topic.mainReplyId
        };
        if (topic.type == '2') {
            param.subReplyId = topic.id
        }
        this.topicService.changeFloorStatus(param).then(res => {
            if (res.status === '0') {
                topic.status = topic.status == 1 ? '2' : '1';
                this.toast.translate('success', '操作成功')
            }
        })

    }
}