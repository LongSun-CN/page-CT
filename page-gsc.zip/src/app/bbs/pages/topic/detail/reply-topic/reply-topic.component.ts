import {Component, EventEmitter, Output, ViewChild} from "@angular/core";
import {TopicService} from "../../../../services/topic.service";
import {ModalDirective} from "ngx-bootstrap";
import {environment} from "../../../../../../environments/environment";
import {ckeditor_options} from "../../../../ckeditor.config";
import {isEmpty} from "ramda";
import {ToastService} from "../../../../../shared/services/toast.service";

@Component({
    selector: 'bbs-topic-reply-topic',
    templateUrl: './reply-topic.component.html'
})
export class TopicReplyTopicComponent {

    @ViewChild('replyModal') replyModal: ModalDirective;
    @Output() successFn: EventEmitter<void> = new EventEmitter<void>();

    ckeditor_config: any;

    topicId: string;

    content: string;

    constructor(private topicService: TopicService,
                private toasterService: ToastService) {
        this.ckeditor_config = {
            ...ckeditor_options,
            uploadImageFileName: 'file',
            uploadImageFileUrl: environment.getUrl('bbs/topic/uploadFile.htm'),
            uploadImageSuccessEvent: (result, resolve, reject) => {
                result = JSON.parse(result);
                if (result.status == '0') {
                    resolve(result.data.relativePath);
                } else {
                    reject();
                    alert(result.desc);
                }
            },
            uploadImageErrorEvent: (result, resolve, reject) => {
                this.toasterService.translate('error', '网络异常，请稍后再试');
            }
        }
    }

    show(topicId) {
        this.topicId = topicId;
        this.content = '';
        this.replyModal.show();
    }

    reply() {
        if (isEmpty(this.content)) return this.toasterService.translate('error', '请输入回复内容');

        this.topicService.replyTopic(this.topicId, this.content)
            .subscribe(result => {
                if (result.status == '0') {
                    this.replyModal.hide();
                    this.successFn.emit();
                    this.toasterService.translate('success', '添加成功');
                } else {
                    this.toasterService.translate('error', result.desc);
                }
            });
    }

}