import {Component, EventEmitter, Output, ViewChild} from "@angular/core";
import {TopicService} from "../../../../services/topic.service";
import {ModalDirective} from "ngx-bootstrap";
import {isEmpty} from "ramda";
import {ToastService} from "../../../../../shared/services/toast.service";

@Component({
    selector: 'bbs-topic-reply-floor',
    templateUrl: './reply-floor.component.html'
})
export class TopicReplyFloorComponent {

    @ViewChild('replyModal') replyModal: ModalDirective;
    @Output() successFn: EventEmitter<void> = new EventEmitter<void>();

    ckeditor_config: any;

    topicId: string;
    topic: any;

    content: string;

    constructor(private topicService: TopicService,
                private toasterService: ToastService) {
        this.ckeditor_config = {
            extraPlugins: 'emoji',
            toolbarGroups: [
                {name: 'document', groups: ['mode', 'document', 'doctools']},
                {name: 'clipboard', groups: ['clipboard', 'undo']},
                {name: 'editing', groups: ['find', 'selection', 'spellchecker', 'editing']},
                {name: 'forms', groups: ['forms']},
                {name: 'basicstyles', groups: ['basicstyles', 'cleanup']},
                {name: 'paragraph', groups: ['list', 'indent', 'blocks', 'align', 'bidi', 'paragraph']},
                {name: 'links', groups: ['links']},
                {name: 'insert', groups: ['insert']},
                {name: 'styles', groups: ['styles']},
                {name: 'colors', groups: ['colors']},
                {name: 'tools', groups: ['tools']},
                {name: 'others', groups: ['others']},
                {name: 'about', groups: ['about']}
            ],
            removeButtons: 'Source,Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Undo,Redo,Replace,Find,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Superscript,Subscript,Strike,Underline,Italic,Bold,CopyFormatting,RemoveFormat,BulletedList,NumberedList,Outdent,Indent,CreateDiv,Blockquote,JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock,Language,BidiRtl,BidiLtr,Link,Unlink,Anchor,Table,Flash,Image,HorizontalRule,SpecialChar,PageBreak,Iframe,Styles,Format,Font,FontSize,TextColor,Maximize,ShowBlocks,BGColor,About'
        };
    }

    show(topicId: string, topic: any) {
        this.topicId = topicId;
        this.topic = topic;
        this.content = '';
        this.replyModal.show();
    }

    reply() {
        if (isEmpty(this.content)) return this.toasterService.translate('error', '请输入回复内容');

        let subReplyId = this.topic.type == '2' ? this.topic.id : '';
        this.topicService.replyFloor(this.topicId, this.topic.mainReplyId, subReplyId, this.content)
            .subscribe(result => {
                if (result.status == '0') {
                    this.replyModal.hide();
                    this.successFn.emit();
                    this.toasterService.translate('success', '添加成功');
                } else {
                    this.toasterService.translate('error', result.desc);
                }
            });
    }
}