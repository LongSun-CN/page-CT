import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: 'ngSrc',
    pure: false
})
export class NgSrcUpgradePipe implements PipeTransform {

    transform(value: string, filter: Object): any {
        if (!value) {
            return value;
        }
        return value.replace('ng-src=', 'src=');
    }

}