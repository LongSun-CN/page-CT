import {Component, OnDestroy, OnInit, ViewChild} from "@angular/core";
import {Observable} from "rxjs";
import {Store} from "@ngrx/store";
import {TopicService} from "../../services/topic.service";
import {initialTopicState, TopicsState, TopicState} from "../../reducers/topic.reducer";
import {OurpalmTable, Page, TableConfig} from "ngx-ourpalm-table";
import {AllSectionState} from "../../reducers/section.reducer";
import {SectionService} from "../../services/section.service";
import {SubSectionService} from "../../services/subsection.service";
import {INIT_ALL_SUBSECTION} from "../../reducers/subsection.reducer";
import {ToastService} from "../../../shared/services/toast.service";
import {Subscription} from "rxjs/Subscription";
import {UserService} from "../../../widgets/user-box/user.service";
import {SelectModal} from "glowworm";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {Router} from "../../../router/router";
import {ModalDirective} from "ngx-bootstrap";
import {TopicMoveComponent} from "./move-topic/topic-move.component";

export interface TopicRouterParam {
    sectionId?: string;
    subSectionId?: string;
    userType?: string;
    nickname?: string;
}

@Component({
    selector: 'bbs-topic',
    templateUrl: 'topic.component.html'
})
export class TopicComponent implements OnInit, OnDestroy, OnSearchBtnWorking {

    allSections$: Observable<any>;
    sectionModel: any;

    allSubSections$: Observable<any>;
    subSectionModel: any;

    topic$: Observable<TopicsState>;
    tableSubscribe: Subscription;

    table: OurpalmTable;

    //查询条件对象
    criteria: any = {
        title: '',
        status: '',
        user: '',
        resultId: ''
    };

    time: any = {};

    nickname: SelectModal = {
        value: '',
        selectValue: '1'
    };

    @ViewChild('disabledModal')
    disabledModal: ModalDirective;

    @ViewChild('enabledModal')
    enabledModal: ModalDirective;

    @ViewChild('move')
    move: TopicMoveComponent;

    constructor(private sectionSevice: SectionService,
                private subSectionService: SubSectionService,
                private topicService: TopicService,
                private toasterService: ToastService,
                private tableConfig: TableConfig,
                private userService: UserService,
                private router: Router,
                private store$: Store<any>) {
    }

    ngOnInit(): void {
        //从redux中注册所有主版块
        this.allSections$ = this.store$.select('allSections').do((state: AllSectionState) => {
            if (state.initState) {
                this.sectionSevice.getAllSections();
            }
        }).pluck('sections').map((sections: any) => {
            return sections.map((section) => {
                return {id: section.id, text: section.name}
            });
        });

        //从redux中注册所有子版块
        this.allSubSections$ = this.store$.select('allSubSections').pluck('subSections').map((subsections: any) => {
            return subsections.map((subsection) => {
                return {id: subsection.id, text: subsection.name}
            });
        });

        //初始化表格
        this.table = this.tableConfig.create({
            cacheKey: 'bbs-topic',
            pagePosition: 'bottom',
            cacheColumns: true,
            cachePageSize: true,
            autoLoadData: false,
            defaultPageSize: 100,
            pageList: [100, 200],
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                this.search(table.currentPage);
            },
            onDbClickRow: (rowIndex, rowData) => {
                if (this.userService.hasPermission('bbs_topicManage_getReplyPage')) {
                    this.router.navigate(['bbs/topic_detail', rowData.id], {
                        queryParamsHandling: 'merge'
                    });
                }
            },
            rowMenus: [{
                text: '前进',
                iconCls: 'fa fa-arrow-right',
                disabled: () => !this.router.canGo(),
                onclick: () => this.router.go()
            }, {
                text: '后退',
                iconCls: 'fa fa-arrow-left',
                disabled: () => !this.router.canBack(),
                onclick: () => this.router.back()
            }, {
                text: '商用',
                iconCls: 'fa fa-play',
                show: () => this.userService.hasPermission('bbs_topicManage_updateStatus'),
                onclick: () => this.enabledModal.show()
            }, {
                text: '暂停',
                iconCls: 'fa fa-stop',
                show: () => this.userService.hasPermission('bbs_topicManage_updateStatus'),
                onclick: () => this.disabledModal.show()
            }, {
                text: '置顶',
                iconCls: 'fa fa-hand-o-up',
                show: () => {
                    return this.userService.hasPermission('bbs_topicManage_updateStickStatus') && this.table.getSelectedRows().length == 1 && this.table.getSelectedRows()[0].isTop != '1';
                },
                onclick: () => {
                    this.changeTopStatus('1', this.table.getSelectedRows()[0].id);
                }
            }, {
                text: '取消置顶',
                iconCls: 'fa fa-hand-o-up',
                show: () => {
                    return this.userService.hasPermission('bbs_topicManage_updateStickStatus') && this.table.getSelectedRows().length == 1 && this.table.getSelectedRows()[0].isTop == '1';
                },
                onclick: () => {
                    this.changeTopStatus('0', this.table.getSelectedRows()[0].id);
                }
            }, {
                text: '移动',
                iconCls: 'fa fa-arrows',
                show: () => this.userService.hasPermission('bbs_topicManage_moveTopic'),
                disabled: () => this.table.getSelectedRows().length != 1,
                onclick: () => this.move.show(this.table.getSelectedRows()[0])
            }, {
                text: '操作记录',
                iconCls: 'fa fa-table',
                show: () => this.userService.hasPermission('bbs_topicManage_operateRecords'),
                disabled: () => this.table.getSelectedRows().length != 1,
                onclick: () => {
                    this.router.navigate(['bbs/topic_operate', this.table.getSelectedRows()[0].id], {
                        queryParamsHandling: 'merge'
                    });
                }
            }, {
                text: '详情',
                iconCls: 'fa fa-info-circle',
                show: () => this.userService.hasPermission('bbs_topicManage_getReplyPage'),
                disabled: () => this.table.getSelectedRows().length != 1,
                onclick: () => {
                    this.router.navigate(['bbs/topic_detail', this.table.getSelectedRows()[0].id], {
                        queryParamsHandling: 'merge'
                    });
                }
            }]
        });

        this.topic$ = this.store$.select('topic');
    }

    /**
     * 初始化查询条件
     */
    initParams() {
        //注册redux表格数据流
        this.tableSubscribe = Observable.combineLatest(this.router.tab.params, this.topic$).debounceTime(100)
            .subscribe(([params, states]) => {
                let state: TopicState = states[`${this.router.tab.tabId}`] || initialTopicState;

                let {userType, nickname, sectionId, subSectionId} = this.paramSnapshot();

                //回显主版块
                this.sectionModel = sectionId;
                this.onSectionChange(sectionId);//级联加载子版块
                //回显子版块
                this.subSectionModel = subSectionId;
                //回显其他表单
                this.criteria = {...this.criteria, userType, nickname};
                this.nickname = {
                    value: state.nickname,
                    selectValue: state.userType
                };
                this.time = {
                    start: state.startTime,
                    end: state.endTime,
                    range: state.range
                };

                //判断当前参数是否和redux中的参数相同
                let isParamSame = sectionId == state.sectionId && subSectionId == state.subSectionId && userType == this.nickname.selectValue && nickname == this.nickname.value;
                if (state.initState || !isParamSame) {
                    this.search(1, true);
                } else {
                    this.criteria = {...this.criteria, ...state};
                    this.table.setPageData(state.page);
                }
            });
    }

    onSelectSearchItem(param: CustomQueryParam) {
        let params = JSON.parse(param.query);
        this.criteria = {...this.criteria, ...params};
        //回显主版块
        let sectionId = params.sectionId;
        let subSectionId = params.subSectionId;
        this.sectionModel = sectionId;
        //级联加载子版块
        this.onSectionChange(sectionId);
        this.subSectionModel = subSectionId;

        this.nickname = {
            value: params.nickname,
            selectValue: params.userType
        };

        this.time = {
            start: params.startTime,
            end: params.endTime,
            range: params.range
        };

        this.search(1, false);
    }

    onSearch() {
        this.search(1, false);
    }

    onSearchAdding(): StringOrResolver {
        let sectionId = this.sectionModel;
        let subSectionId = this.subSectionModel;
        return JSON.stringify({
            sectionId,
            subSectionId,
            title: this.criteria.title,
            userType: this.nickname.selectValue,
            nickname: this.nickname.value,
            startTime: this.time.start,
            endTime: this.time.end,
            range: this.time.range,
            status: this.criteria.status,
            user: this.criteria.user
        });
    }

    onResumeSearchItem(param: CustomQueryParam) {
        // 调用初始化
        this.initParams();
        // 恢复查询条件
        this.onSelectSearchItem(param);
    }

    /**
     * 初始化
     */
    onResumeSearchNothing() {
        this.initParams();
    }

    onSectionChange(sectionId: string) {
        this.subSectionModel = '';
        if (sectionId) {
            this.subSectionService.getAllSubSection(sectionId);
        } else {
            this.store$.dispatch({type: INIT_ALL_SUBSECTION});
        }
    }

    changeStatus(status: string) {
        let ids = this.table.getSelectedRows().map(row => row.id);
        if (ids.length == 0) {
            this.toasterService.translate('error', '请选择至少一条数据');
        } else {
            this.topicService.changeStatus(status, ids).subscribe((result: any) => {
                if (result.status == '0') {
                    this.toasterService.translate('success', '修改成功');
                    this.table.refresh();
                } else {
                    this.toasterService.translate('error', result.desc);
                }
            });
        }
    }

    changeTopStatus(status: string, topicId: any) {
        this.topicService.changeTopStatus(status, topicId).subscribe(result => {
            if (result.status == '0') {
                this.toasterService.translate('success', '修改成功');
                this.table.refresh();
            } else {
                this.toasterService.translate('error', result.desc);
            }
        });
    }

    search(currentPage: number, isInit: boolean = false) {
        let sectionId = this.sectionModel;
        let subSectionId = this.subSectionModel;
        if (isInit) {
            let param = this.paramSnapshot();
            sectionId = param.sectionId;
            subSectionId = param.subSectionId;
        }

        this.topicService.pageTopic(`${this.router.tab.tabId}`, currentPage, this.table.pageSize, sectionId, subSectionId,
            this.criteria.title, this.nickname.selectValue, this.nickname.value,
            this.criteria.user, this.time.start, this.time.end, this.time.range,
            this.criteria.status, this.criteria.resultId,).then(() => {
            this.router.navigate(['bbs/topic', sectionId || '!', subSectionId || '!', this.nickname.selectValue || '!', this.nickname.value || '!'], {
                queryParamsHandling: 'merge'
            });
        });
    }

    private paramSnapshot(): TopicRouterParam {
        let defaultParams = {
            sectionId: '',
            subSectionId: '',
            userType: '1',
            nickname: ''
        };
        let routeParams = {...defaultParams, ...this.router.snapshot};
        let {userType, nickname, sectionId, subSectionId} = routeParams;
        sectionId = sectionId == '!' ? '' : sectionId;
        subSectionId = subSectionId == '!' ? '' : subSectionId;
        userType = !userType || userType == '!' ? '1' : userType;
        nickname = !nickname || nickname == '!' ? '' : nickname;
        return {sectionId, subSectionId, userType, nickname};
    }

    ngOnDestroy(): void {
        this.tableSubscribe && this.tableSubscribe.unsubscribe();
    }
}
