import {Component, EventEmitter, Input, Output, ViewChild} from "@angular/core";
import {ModalDirective} from "ngx-bootstrap";
import {HttpService} from "../../../../shared/services/httpx.service";
import {environment} from "../../../../../environments/environment";
import {OurpalmFormComponent} from "ngx-ourpalm-form";
import {isEmpty} from "ramda";
import {ToastService} from "../../../../shared/services/toast.service";

@Component({
    selector: 'bbs-subsection-add',
    templateUrl: './subsection-add.component.html'
})
export class SubSectionAddComponent {

    @ViewChild('detailModal') detailModal: ModalDirective;

    @ViewChild(OurpalmFormComponent) addForm: OurpalmFormComponent;

    @Output() successFn: EventEmitter<void> = new EventEmitter<void>();

    @Input() sectionId: string;

    add: any;

    constructor(private httpService: HttpService,
                private toastService: ToastService) {
        this.clearForm();
    }

    addSubSection() {
        if (isEmpty(this.add.name)) return this.toastService.translate('error', '名称不能为空');
        if (isEmpty(this.add.title)) return this.toastService.translate('error', '标题不能为空');
        if (!this.add.file || !this.add.file.first) return this.toastService.translate('error', '请选择图片');
        this.addForm.ajaxSubmit({
            url: environment.getUrl('bbs/subsection/addSubSection.htm'),
            xhrFields: {
                withCredentials: true //跨域发送cookie, 异步提交表单时使用XHR2.0
            },
            headers: this.httpService.getHeaders(),
            success: (result) => {
                console.info(result);
                result = (typeof result === 'string') ? JSON.parse(result) : result;
                if (result.status == '0') {
                    this.toastService.translate('error', '添加成功');
                    this.detailModal.hide();
                    this.successFn.emit();
                } else {
                    this.toastService.translate('error', result.desc);
                }
            }
        });
    }

    open() {
        // this.addForm.clearForm();
        this.clearForm();
        this.detailModal.show();
    }

    private clearForm() {
        this.add = {
            name: '',
            title: '',
            sort: 0,
            isCreateTopic: '1',
            isReply: '1',
            file: null
        };
    }
}