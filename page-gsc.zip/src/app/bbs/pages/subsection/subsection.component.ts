import {Component, OnDestroy, ViewChild} from "@angular/core";
import {OurpalmTable, Page, TableConfig} from "ngx-ourpalm-table";
import {Store} from "@ngrx/store";
import {SubSectionsState} from "../../reducers/subsection.reducer";
import {SubSectionService} from "../../services/subsection.service";
import {Observable, Subscription} from "rxjs";
import {ToastService} from "../../../shared/services/toast.service";
import {SubSectionEditComponent} from "./edit/subsection-edit.component";
import {Router} from "../../../router/router";
import {ModalDirective} from "ngx-bootstrap";
import {UserService} from "../../../widgets/user-box/user.service";

@Component({
    selector: 'bbs-subsection',
    templateUrl: 'subsection.component.html'
})
export class SubSectionComponent implements OnDestroy {

    @ViewChild(SubSectionEditComponent) edit: SubSectionEditComponent;

    subsection$: Observable<SubSectionsState>;
    tableSubscribe: Subscription;
    table: OurpalmTable;
    sectionId: string;

    @ViewChild('disabledModal')
    disabledModal: ModalDirective;

    @ViewChild('enabledModal')
    enabledModal: ModalDirective;

    constructor(private toasterService: ToastService,
                private subSectionService: SubSectionService,
                private userService: UserService,
                private tableConfig: TableConfig,
                private router: Router,
                private store$: Store<any>) {
        this.sectionId = this.router.tab.snapshot.params.sectionId;
        this.subsection$ = store$.select('subsection');

        this.table = this.tableConfig.create({
            cacheKey: 'bbs-subsection',
            cacheColumns: true,
            cachePageSize: true,
            autoLoadData: false,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                this.subSectionService.pageSubSection(table.currentPage, table.pageSize, this.sectionId);
            },
            onDbClickRow: (rowIndex, rowData) => {
                this.edit.open(rowData);
            },
            rowMenus: [{
                text: '前进',
                iconCls: 'fa fa-arrow-right',
                disabled: () => !this.router.canGo(),
                onclick: () => this.router.go()
            }, {
                text: '后退',
                iconCls: 'fa fa-arrow-left',
                disabled: () => !this.router.canBack(),
                onclick: () => this.router.back()
            }, {
                text: '商用',
                iconCls: 'fa fa-play',
                show: () => this.userService.hasPermission('bbs_sectionManage_upateSubSectionStatus'),
                onclick: () => this.enabledModal.show()
            }, {
                text: '暂停',
                iconCls: 'fa fa-stop',
                show: () => this.userService.hasPermission('bbs_sectionManage_upateSubSectionStatus'),
                onclick: () => this.disabledModal.show()
            }, {
                text: '详情',
                iconCls: 'fa fa-info-circle',
                show: () => this.userService.hasPermission('bbs_sectionManage_getSubSectionInfo'),
                disabled: () => this.table.getSelectedRows().length != 1,
                onclick: () => {
                    this.edit.open(this.table.getSelectedRows()[0]);
                }
            }]
        });

        //表格数据流
        this.tableSubscribe = this.subsection$
            .map((states: SubSectionsState) => states[this.sectionId])
            .subscribe((state) => {
                if (!state || state.initState) {
                    this.table.refresh();
                } else {
                    this.table.setPageData(state.page);
                }
            });
    }

    changeStatus(status) {
        let ids = this.table.getSelectedRows().map(row => row.id);
        if (ids.length == 0) {
            this.toasterService.translate('error', '请选择至少一条数据');
        } else {
            this.subSectionService.changeStatus(status, ids).subscribe((result: any) => {
                if (result.status == '0') {
                    this.toasterService.translate('success', '修改成功');
                    this.table.refresh();
                } else {
                    this.toasterService.translate('error', result.desc);
                }
            });
        }
    }

    ngOnDestroy(): void {
        this.tableSubscribe.unsubscribe();
    }
}
