import {Component, EventEmitter, Input, Output, ViewChild} from "@angular/core";
import {ModalDirective} from "ngx-bootstrap";
import {HttpService} from "../../../../shared/services/httpx.service";
import {environment} from "../../../../../environments/environment";
import {OurpalmFormComponent} from "ngx-ourpalm-form";
import {isEmpty} from "ramda";
import {ToastService} from "../../../../shared/services/toast.service";

@Component({
    selector: 'bbs-subsection-edit',
    templateUrl: './subsection-edit.component.html'
})
export class SubSectionEditComponent {

    @ViewChild('detailModal') detailModal: ModalDirective;

    @ViewChild(OurpalmFormComponent) addForm: OurpalmFormComponent;

    @Output() successFn: EventEmitter<void> = new EventEmitter<void>();

    @Input() sectionId: string;

    edit: any = {};

    editable: boolean = false;

    constructor(private httpService: HttpService,
                private toastService: ToastService) {
    }

    updateSubSection() {
        if (isEmpty(this.edit.name)) return this.toastService.translate('error', '名称不能为空');
        if (isEmpty(this.edit.title)) return this.toastService.translate('error', '标题不能为空');
        if (!this.edit.file || !this.edit.file.first) return this.toastService.translate('error', '请选择图片');
        this.addForm.ajaxSubmit({
            url: environment.getUrl('bbs/subsection/updateSubSection.htm'),
            xhrFields: {
                withCredentials: true //跨域发送cookie, 异步提交表单时使用XHR2.0
            },
            headers: this.httpService.getHeaders(),
            success: (result) => {
                console.info(result);
                result = (typeof result === 'string') ? JSON.parse(result) : result;
                if (result.status == '0') {
                    this.toastService.translate('error', '修改成功');
                    this.detailModal.hide();
                    this.successFn.emit();
                } else {
                    this.toastService.translate('error', result.desc);
                }
            }
        });
    }

    open(subsection: any) {
        this.editable = false;
        this.edit = {...subsection};
        this.detailModal.show();
    }

    changeEditable() {
        this.editable = !this.editable;
    }
}