import {Component, OnInit} from "@angular/core";
import {Store} from "@ngrx/store";
import {State} from "../../reducers/dashboard.reducer";
import {Observable} from "rxjs";
import {DashboardService} from "../../services/dashboard.service";
import {Router} from "../../../router";

@Component({
    selector: 'bbs-dashboard',
    templateUrl: 'dashboard.component.html'
})
export class DashboardComponent implements OnInit {

    dashboard$: Observable<State>;

    constructor(private dashboardService: DashboardService,
                private router: Router,
                private store$: Store<State>) {
        this.dashboard$ = store$.select('dashboard');
        this.dashboardService.loadDashboard();
    }

    topicDetail(topic: any) {
        this.router.navigate(['bbs/topic_detail', topic.id], {
            // relativeTo: this.route,
            queryParamsHandling: 'merge'
        });
    }

    public ngOnInit(): void {
    }
}