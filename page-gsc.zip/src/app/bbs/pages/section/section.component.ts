import {Component, OnDestroy, ViewChild} from "@angular/core";
import {Observable, Subscription} from "rxjs";
import {SectionsState, SectionState} from "../../reducers/section.reducer";
import {Store} from "@ngrx/store";
import {SectionService} from "../../services/section.service";
import {OurpalmTable, Page, TableConfig} from "ngx-ourpalm-table";
import {ToastService} from "../../../shared/services/toast.service";
import {UserService} from "../../../widgets/user-box/user.service";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {Router} from "../../../router/router";
import {ModalDirective} from "ngx-bootstrap";

@Component({
    selector: 'bbs-section',
    templateUrl: 'section.component.html'
})
export class SectionComponent implements OnDestroy, OnSearchBtnWorking {

    name: string; //版块名称
    status: string; //版块状态

    section$: Observable<SectionsState>;
    subscription: Subscription;

    table: OurpalmTable;
    tabId: string;

    @ViewChild('disabledModal')
    disabledModal: ModalDirective;

    @ViewChild('enabledModal')
    enabledModal: ModalDirective;

    constructor(private sectionService: SectionService,
                private userService: UserService,
                private toasterService: ToastService,
                private tableConfig: TableConfig,
                private router: Router,
                private store$: Store<any>) {
        this.tabId = `${this.router.tab.tabId}`;
        this.section$ = store$.select('section');
        this.table = this.tableConfig.create({
            cacheKey: 'bbs-section',
            pagePosition: 'bottom',
            cacheColumns: true,
            cachePageSize: true,
            autoLoadData: false,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                this.sectionService.pageSection(this.tabId, table.currentPage, table.pageSize, this.name, this.status);
            },
            onDbClickRow: (rowIndex, rowData) => {
                if (this.userService.hasPermission('bbs_sectionManage_getSectionInfo')) {
                    this.router.navigate(['bbs/section/edit', rowData.id], {
                        queryParamsHandling: 'merge'
                    });
                }
            },
            rowMenus: [{
                text: '前进',
                iconCls: 'fa fa-arrow-right',
                disabled: () => !this.router.canGo(),
                onclick: () => this.router.go()
            }, {
                text: '后退',
                iconCls: 'fa fa-arrow-left',
                disabled: () => !this.router.canBack(),
                onclick: () => this.router.back()
            }, {
                text: '商用',
                iconCls: 'fa fa-play',
                show: () => this.userService.hasPermission('bbs_sectionManage_updateStatus'),
                onclick: () => this.enabledModal.show()
            }, {
                text: '暂停',
                iconCls: 'fa fa-stop',
                show: () => this.userService.hasPermission('bbs_sectionManage_updateStatus'),
                onclick: () => this.disabledModal.show()
            }, {
                text: '详情',
                iconCls: 'fa fa-info-circle',
                show: () => this.userService.hasPermission('bbs_sectionManage_getSectionInfo'),
                disabled: () => this.table.getSelectedRows().length != 1,
                onclick: () => {
                    this.router.navigate(['bbs/section/edit', this.table.getSelectedRows()[0].id], {
                        queryParamsHandling: 'merge'
                    });
                }
            }]
        });
    }

    changeStatus(status) {
        let ids = this.table.getSelectedRows().map(row => row.id);
        if (ids.length == 0) {
            this.toasterService.translate('error', '请选择至少一条数据');
        } else {
            this.sectionService.changeStatus(status, ids).subscribe((result: any) => {
                if (result.status == '0') {
                    this.toasterService.translate('success', '修改成功');
                    this.table.refresh();
                } else {
                    this.toasterService.translate('error', result.desc);
                }
            });
        }
    }

    onSelectSearchItem(param: CustomQueryParam) {
        let params: any = JSON.parse(param.query);
        this.name = params.name;
        this.status = params.status;
        this.onSearch();
    }

    onSearch() {
        this.sectionService.pageSection(this.tabId, 1, this.table.pageSize, this.name, this.status);
    }

    onSearchAdding(): StringOrResolver {
        return JSON.stringify({
            name: this.name,
            status: this.status
        });
    }

    onResumeSearchItem(param: CustomQueryParam) {
        this.onResumeSearchNothing();
        this.onSelectSearchItem(param);
    }

    onResumeSearchNothing() {
        //订阅用来回显数据
        this.subscription = this.section$
            .map((states: SectionsState) => states[this.tabId])
            .subscribe((state: SectionState) => {
                if (!state || state.initState) { // loadData
                    this.table.refresh();
                } else {
                    this.name = state.name; //回显版块名称
                    this.status = state.status; //回显版块状态
                    this.table.setPageData(state.page);
                }
            });
    }

    ngOnDestroy(): void {
        this.subscription && this.subscription.unsubscribe();
    }

}
