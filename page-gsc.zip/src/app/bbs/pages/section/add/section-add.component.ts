import {Component, EventEmitter, Output, ViewChild} from "@angular/core";
import {ModalDirective} from "ngx-bootstrap";
import {HttpService} from "../../../../shared/services/httpx.service";
import {environment} from "../../../../../environments/environment";
import {Store} from "@ngrx/store";
import {Observable} from "rxjs/Observable";
import {OurpalmFormComponent} from "ngx-ourpalm-form";
import {isEmpty} from "ramda";
import {ToastService} from "../../../../shared/services/toast.service";

@Component({
    selector: 'bbs-section-add',
    templateUrl: './section-add.component.html'
})
export class SectionAddComponent {

    @ViewChild('detailModal') detailModal: ModalDirective;

    @ViewChild(OurpalmFormComponent) addForm: OurpalmFormComponent;

    @Output() successFn: EventEmitter<void> = new EventEmitter<void>();

    product$: Observable<any>;

    add: any;

    constructor(private httpService: HttpService,
                private store$: Store<any>,
                private toastService: ToastService) {
        this.product$ = this.store$.select('product');
        this.clearForm();
    }

    addSection() {
        if (isEmpty(this.add.name)) return this.toastService.translate('error', '名称不能为空');
        if (isEmpty(this.add.title)) return this.toastService.translate('error', '标题不能为空');
        if (isEmpty(this.add.product)) return this.toastService.translate('error', '请选择产品');
        if (this.add.isAllowDept == '1' && isEmpty(this.add.product)) return this.toastService.translate('error', '请输入官网地址');
        if (this.add.isAllowDept == '1' && isEmpty(this.add.deptUrl)) return this.toastService.translate('error', '请输入官网地址');
        if (this.add.isAllowDownload == '1' && isEmpty(this.add.downloadUrl)) return this.toastService.translate('error', '请输入下载地址');
        if (!this.add.file || !this.add.file.first) return this.toastService.translate('error', '请选择图片');
        this.addForm.ajaxSubmit({
            url: environment.getUrl('bbs/section/addSection.htm'),
            xhrFields: {
                withCredentials: true //跨域发送cookie, 异步提交表单时使用XHR2.0
            },
            headers: this.httpService.getHeaders(),
            success: (result) => {
                console.info(result);
                result = (typeof result === 'string') ? JSON.parse(result) : result;
                if (result.status == '0') {
                    this.toastService.translate('error', '添加成功');
                    this.detailModal.hide();
                    this.successFn.emit();
                } else {
                    this.toastService.translate('error', result.desc);
                }
            }
        });
    }

    open() {
        // this.addForm.clearForm();
        this.clearForm();
        this.detailModal.show();
    }

    private clearForm() {
        this.add = {
            name: '',
            title: '',
            product: '',
            sort: 0,
            isAllowDept: '1',
            deptUrl: '',
            isAllowDownload: '1',
            downloadUrl: '',
            file: null
        };
    }
}
