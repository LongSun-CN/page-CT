import {Component, OnDestroy, ViewChild} from "@angular/core";
import {SectionService} from "../../../services/section.service";
import {Observable} from "rxjs/Observable";
import {ModalDirective} from "ngx-bootstrap";
import {isEmpty, isNil} from "ramda";
import {OurpalmFormComponent} from "ngx-ourpalm-form";
import {environment} from "../../../../../environments/environment";
import {HttpService} from "../../../../shared/services/httpx.service";
import {ToastService} from "../../../../shared/services/toast.service";
import {Router} from "../../../../router/router";

@Component({
    selector: 'bbs-section-edit',
    styleUrls: ['./section-edit.component.css'],
    templateUrl: './section-edit.component.html'
})
export class SectionEditComponent implements OnDestroy {

    @ViewChild('addModal') addModal: ModalDirective;

    @ViewChild(OurpalmFormComponent) updateForm: OurpalmFormComponent;

    section: any = {};
    add: any = {};
    disabled: boolean = true;

    packages: any[] = [];
    packagesInfo$: Observable<any[]>;

    constructor(private sectionService: SectionService,
                private httpService: HttpService,
                private router: Router,
                private toastService: ToastService) {
        this.sectionService.getSection(this.router.snapshot['sectionId']).subscribe((result: any) => {
            if (result.status == '0') {
                this.section = result.data.sectioninfo;
            } else {
                this.toastService.translate('error', result.desc);
            }
        });

        this.getPackages();
    }

    private getPackages() {
        this.sectionService.sectionDetail(this.router.snapshot['sectionId']).subscribe((result: any) => {
            if (result.status == '0') {
                this.packages = result.data;
            } else {
                this.packages = [];
            }
        });
    }

    updateSection() {
        console.info(this.packages.map((item: any) => item.id));

        if (isEmpty(this.section.name)) {
            return this.toastService.translate('error', '名称不能为空');
        }
        if (isEmpty(this.section.title)) {
            return this.toastService.translate('error', '标题不能为空');
        }
        if (isEmpty(this.section.sort)) {
            return this.toastService.translate('error', '排序不能为空');
        }
        if (this.section.isAllowDept == '1' && isEmpty(this.section.deptUrl)) {
            return this.toastService.translate('error', '官网地址不能为空');
        }
        if (this.section.isAllowDownload == '1' && isEmpty(this.section.downloadUrl)) {
            return this.toastService.translate('error', '下载地址不能为空');
        }

        this.updateForm.ajaxSubmit({
            url: environment.getUrl('bbs/section/updateSection.htm'),
            xhrFields: {
                withCredentials: true //跨域发送cookie, 异步提交表单时使用XHR2.0
            },
            headers: this.httpService.getHeaders(),
            data: {
                sectionPackageIds: this.packages.map((item: any) => item.id).join(',')
            },
            success: (result) => {
                console.info(result);
                result = (typeof result === 'string') ? JSON.parse(result) : result;
                if (result.status == '0') {
                    this.toastService.translate('error', '修改成功');
                } else {
                    this.toastService.translate('error', result.desc);
                }
            }
        });
    }

    openAddModal() {
        this.add = {};
        this.packagesInfo$ = this.sectionService.findGamePackagePage(this.section.productId).map(result => {
            if (result.status == '0') {
                return result.data.list.map((item: any) => {
                    return {
                        id: item.id,
                        text: item.name,
                        ...item
                    }
                })
            } else {
                return [];
            }
        }).share();
        this.addModal.show();
    }

    onPackageSelected(item: any) {
        this.packagesInfo$.subscribe((items: any[]) => {
            let _item = items.filter(_item => _item.id == item.id)[0];
            this.add = {..._item};
        });
    }

    deleteSectionPackage(id: string | number) {
        this.sectionService.deleteSectionPackage(id).subscribe(result => {
            if (result.status == '0') {
                this.toastService.translate('error', '删除成功');
                this.router.params.subscribe((params: any) => {
                    this.getPackages();
                });
            } else {
                this.toastService.translate('error', result.desc);
            }
        });
    }

    addPackage() {
        if (isNil(this.add.productName) || isEmpty(this.add.productName)) {
            return this.toastService.translate('error', '请选择礼包');
        }
        if (isNil(this.add.startTime) || isEmpty(this.add.startTime)) {
            return this.toastService.translate('error', '请选择开始时间');
        }
        if (isNil(this.add.endTime) || isEmpty(this.add.endTime)) {
            return this.toastService.translate('error', '请选择结束时间');
        }
        if (isNil(this.add.type) || isEmpty(this.add.type)) {
            return this.toastService.translate('error', '请选择领取方式');
        }
        if (isNil(this.add.score) || isEmpty(this.add.score)) {
            return this.toastService.translate('error', '请设置消耗积分');
        }

        this.sectionService.addSectionPackage(this.section.id, this.add.id, this.add.startTime, this.add.endTime, this.add.type, this.add.score)
            .subscribe(result => {
                if (result.status == '0') {
                    this.toastService.translate('error', '添加成功');
                    this.addModal.hide();
                    this.router.params.subscribe((params: any) => {
                        this.getPackages();
                    });
                } else {
                    this.toastService.translate('error', result.desc);
                }
            });

    }

    ngOnDestroy(): void {
    }

}
