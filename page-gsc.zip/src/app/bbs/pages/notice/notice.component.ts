import {Component, OnDestroy, ViewChild} from "@angular/core";
import {Store} from "@ngrx/store";
import {Observable, Subscription} from "rxjs";
import {NoticesState, NoticeState} from "../../reducers/notice.reducer";
import {NoticeService} from "../../services/notice.service";
import {OurpalmTable, Page, TableConfig} from "ngx-ourpalm-table";
import {isEmpty} from "ramda";
import {ModalDirective} from "ngx-bootstrap";
import {ToastService} from "../../../shared/services/toast.service";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {Router} from "../../../router";
import {UserService} from "../../../widgets/user-box/user.service";

@Component({
    selector: 'bbs-notice',
    templateUrl: './notice.component.html'
})
export class NoticeComponent implements OnDestroy, OnSearchBtnWorking {
    notice$: Observable<NoticesState>;
    tableSubscribe: Subscription;

    table: OurpalmTable;

    //查询条件对象
    criteria: any = {
        title: '',
        time: '',
        createUserId: ''
    };

    @ViewChild('disabledModal')
    disabledModal: ModalDirective;

    @ViewChild('addModal')
    addModal: ModalDirective;
    add: any = {};

    @ViewChild('detailModal')
    detailModal: ModalDirective;
    edit: any = {};
    tabId: string;

    constructor(private store$: Store<any>,
                private toastService: ToastService,
                private userService: UserService,
                private router: Router,
                private tableConfig: TableConfig,
                private noticeService: NoticeService) {
        this.tabId = `${this.router.tab.tabId}`;
        this.notice$ = store$.select('notice');

        //初始化表格
        this.table = this.tableConfig.create({
            cacheKey: 'bbs-notice',
            pagePosition: 'bottom',
            cacheColumns: true,
            cachePageSize: true,
            autoLoadData: false,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                this.onSearch(table.currentPage);
            },
            onDbClickRow: (rowIndex, rowData) => {
                this.showDetail(rowData);
            },
            rowMenus: [
                {
                    text: '前进',
                    iconCls: 'fa fa-arrow-right',
                    disabled: () => !this.router.canGo(),
                    onclick: () => this.router.go()
                }, {
                    text: '后退',
                    iconCls: 'fa fa-arrow-left',
                    disabled: () => !this.router.canBack(),
                    onclick: () => this.router.back()
                }, {
                    text: '暂停',
                    iconCls: 'fa fa-stop',
                    show: () => this.userService.hasPermission('bbs_noticeManage_updateStatus'),
                    onclick: () => this.disabledModal.show()
                }, {
                    text: '详情',
                    iconCls: 'fa fa-info-circle',
                    disabled: () => this.table.getSelectedRows().length != 1,
                    onclick: () => {
                        this.showDetail(this.table.getSelectedRows()[0]);
                    }
                }]
        });
    }

    onSelectSearchItem(param: CustomQueryParam) {
        let params = JSON.parse(param.query);
        this.criteria = {...this.criteria, ...params};
        this.onSearch(1);
    }

    onSearch(currentPage: number = 1) {
        this.noticeService.pageNotice(this.tabId, currentPage, this.table.pageSize, this.criteria.title,
            this.criteria.time.split(' - ')[0], this.criteria.time.split(' - ')[1], this.criteria.createUserId);
    }

    onSearchAdding(): StringOrResolver {
        return JSON.stringify(this.criteria);
    }

    onResumeSearchItem(param: CustomQueryParam) {
        // 调用初始化
        this.onResumeSearchNothing();
        // 恢复查询条件
        this.onSelectSearchItem(param);
    }

    /**
     * 初始化
     */
    onResumeSearchNothing() {
        this.tableSubscribe = this.notice$
            .map((states: NoticesState) => states[this.tabId])
            .subscribe((state: NoticeState) => {
                if (!state || state.initState) {
                    this.table.refresh();
                } else {
                    this.criteria = {...this.criteria, ...state.criteria};
                    this.table.setPageData(state.page);
                }
            });
    }

    disabledNotice() {
        let ids = this.table.getSelectedRows().map(row => row.id);
        if (ids.length == 0) {
            this.toastService.translate('error', '请选择至少一条数据');
        } else {
            this.noticeService.disabledNotice(ids).subscribe((result: any) => {
                if (result.status == '0') {
                    this.toastService.translate('success', '修改成功');
                    this.table.refresh();
                } else {
                    this.toastService.translate('error', result.desc);
                }
            });
        }
    }

    clearAddModal() {
        this.add = {
            isAll: '1',
            timeType: '1',
            users: [],
            title: '',
            content: ''
        };
    }

    onAddingUser(username): Observable<any> {
        return this.noticeService.isUserValid(username).filter(result => {
            !result.data.success && this.toastService.translate('error', '用户不存在');
            return result.data.success;
        }).mapTo(username);
    }

    addNotice() {
        if (this.add.isAll == '0' && this.add.users.length == 0) {
            return this.toastService.translate('error', '请输入推送用户');
        }
        if (isEmpty(this.add.title)) {
            return this.toastService.translate('error', '标题不能为空');
        }
        if (isEmpty(this.add.content)) {
            return this.toastService.translate('error', '内容不能为空');
        }

        let users = this.add.users.map(user => user.value);
        this.noticeService.addNotice(this.add.title, this.add.content, this.add.isAll, users, this.add.timeType)
            .subscribe((result: any) => {
                if (result.status == '0') {
                    this.addModal.hide();
                    this.table.refresh();
                    this.toastService.translate('success', '添加成功');
                } else {
                    this.toastService.translate('error', result.desc);
                }
            })
    }

    showDetail(row) {
        this.edit = {...row};
        this.detailModal.show();
    }

    ngOnDestroy(): void {
        this.tableSubscribe && this.tableSubscribe.unsubscribe();
    }
}
