import {NoticeComponent} from "./notice/notice.component";
import {UserDetailComponent} from "./user/detail/user-detail.component";
import {UserComponent} from "./user/user.component";
import {SpeedNavComponent} from "../widgets/speed-nav/speed-nav.component";
import {NgSrcUpgradePipe} from "./topic/detail/ng-src.pipe";
import {TopicReplyTopicComponent} from "./topic/detail/reply-topic/reply-topic.component";
import {TopicReplyFloorComponent} from "./topic/detail/reply-floor/reply-floor.component";
import {TopicAddComponent} from "./topic/add/topic-add.component";
import {TopicMoveComponent} from "./topic/move-topic/topic-move.component";
import {TopicOperateRecordComponent} from "./topic/operate-record/operate-record.component";
import {TopicDetailComponent} from "./topic/detail/topic-detail.component";
import {TopicComponent} from "./topic/topic.component";
import {SubSectionEditComponent} from "./subsection/edit/subsection-edit.component";
import {SectionEditComponent} from "./section/edit/section-edit.component";
import {SectionAddComponent} from "./section/add/section-add.component";
import {SectionComponent} from "./section/section.component";
import {DashboardComponent} from "./dashboard/dashboard.component";
import {SubSectionComponent} from "./subsection/subsection.component";
import {SubSectionAddComponent} from "./subsection/add/subsection-add.component";

export const declare_components = [
    DashboardComponent,
    SectionComponent,
    SectionAddComponent,
    SectionEditComponent,
    SubSectionComponent,
    SubSectionAddComponent,
    SubSectionEditComponent,
    TopicComponent,
    TopicDetailComponent,
    TopicOperateRecordComponent,
    TopicMoveComponent,
    TopicAddComponent,
    TopicReplyFloorComponent,
    TopicReplyTopicComponent,
    SpeedNavComponent,
    UserComponent,
    UserDetailComponent,
    NoticeComponent,
    NgSrcUpgradePipe
];