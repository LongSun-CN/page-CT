import {BaseElement} from "./baseElement";
/**
 * Created by choui on 2017/7/3.
 */
export class InputElement extends  BaseElement<string>{
  controlType = 'input';
  placeholder:string = "";
  type: string;
  iscompute:Boolean = false;
  iscomputed:Boolean = false;
  myinnerHtml:string = "";
  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] || '';
    this.placeholder = options['placeholder'] || '';
    this.iscompute = !!options['iscompute'];
    this.iscomputed = !!options['iscomputed'];
    this.myinnerHtml = options['myinnerHtml']|| '';
  }
}
