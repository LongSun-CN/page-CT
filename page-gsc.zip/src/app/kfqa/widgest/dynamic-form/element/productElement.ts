/**
 * Created by admin on 2017/7/4.
 */
import {BaseElement} from "./baseElement";
/**
 * Created by choui on 2017/7/3.
 */
export class ProductElement extends  BaseElement<string>{
  controlType = 'product';
  identifier: string;

  constructor(options: {} = {}) {
    super(options);
    this.identifier = options['identifier'] || '';
  }
}
