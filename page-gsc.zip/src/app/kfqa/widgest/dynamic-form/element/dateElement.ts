import {BaseElement} from "./baseElement";
import {datepicker} from "../../../../widgets/ourpalm-datepicker/datepicker";
/**
 * Created by choui on 2017/7/4.
 */

export class DateElemet extends  BaseElement<string>{
  controlType = 'date';
  options: datepicker;
  inputClass?:string;

  constructor(options: {} = {}) {
    super(options);
    this.options = options['options'] || new datepicker();
    this.inputClass =  options['inputClass']||'';
  }
}
