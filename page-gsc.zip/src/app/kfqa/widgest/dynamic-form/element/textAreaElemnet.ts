import {BaseElement} from "./baseElement";
/**
 * Created by choui on 2017/7/3.
 */
export class TextAreaElement extends  BaseElement<string>{
  controlType = 'area';
  placeholder:string = "";
  row:number;

  constructor(options: {} = {}) {
    super(options);
    this.placeholder = options['placeholder'] || '';
    this.row = options['row'] || 5;
  }
}
