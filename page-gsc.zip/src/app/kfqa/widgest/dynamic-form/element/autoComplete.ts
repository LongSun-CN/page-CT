import {BaseElement} from "./baseElement";
import {OurpalmAutoComplete} from "../../../../widgets/ourpalm-autocomplete/OurpalmAutoComplete";
/**
 * Created by choui on 2017/7/3.
 */
export class AutoComplete extends  BaseElement<string>{
  controlType = 'autocomplete';
  options: OurpalmAutoComplete;
  inputClass?:string;

  constructor(options: {} = {}) {
    super(options);
    this.options = options['options'] || new OurpalmAutoComplete({});
    this.inputClass =  options['inputClass']||'';
  }
}
