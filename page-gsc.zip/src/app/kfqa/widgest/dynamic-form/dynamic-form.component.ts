import {Component, OnInit, Input, OnChanges} from '@angular/core';
import {FormControl, FormGroup} from "@angular/forms";
import {BaseElement} from "./element/baseElement";

@Component({
  selector: 'ourpalm-dynamic-form',
  template: ` 
    <form [ngClass]="dyClass" role="form" [formGroup]="form">
        <fieldset>
      <ng-container *ngFor="let row of datas">
          
          <ng-container [ngSwitch]="row.controlType">

            <div class="form-group gap"  *ngSwitchCase="'gap'">
            </div>

            <ng-container *ngSwitchCase="'hidden'">
                 <input type="hidden" [formControlName]="row.key" [value]="row.value"/> 
            </ng-container>
            
            <div class="form-group"  *ngSwitchCase="'input'">
              <label class="control-label"  [title]="row.label|translate">
                {{row.label|translate}} 
              </label>
              <div class="dynamicContent" *ngIf="!row['iscomputed']">
                  <input  class="form-control input-sm" [formControlName]="row.key"    [value]="row.value" (input)="sum(row['iscompute'])"/>
              </div>
            </div>
            
            <div class="form-group"  *ngSwitchCase="'area'" style="width: 100%!important;">
              <label class="control-label"  [title]="row.label|translate" style="width: 15%!important;">
                {{row.label|translate}}
              </label>
              <div class="dynamicContent" style="width: 76%!important;">
                <textarea  class="form-control input-sm" [rows]="row['row']" [formControlName]="row.key"     [value]="row.value"></textarea>
              </div>
            </div>
           
            <div class="form-group"  *ngSwitchCase="'select'" >
              <label class="control-label"  [title]="row.label|translate">
                {{row.label|translate}}
              </label>
              <div class="dynamicContent" >
                <select class="form-control input-sm" [id]="row.key"     [formControlName]="row.key" (change)="selectChange($event,row['changeEvent'],row['iscompute'])">
                  <option *ngFor="let opt of row['options']" [value]="opt.value">{{opt.key}}</option>
                </select>
              </div>
            </div>

            <div class="form-group"  *ngSwitchCase="'autocomplete'" >
              <label class="control-label"  [title]="row.label|translate">
                {{row.label|translate}}
              </label>
              <div class="dynamicContent" >
                <ourpalm-autocomplete   [autocomplete]="row['options']"   (valueChange)="getAutoValue($event,row.key)" [textValue]="row.value"
                                        [inputClass]="row['inputClass']" [placeholder]="row.label|translate"
                                         [isDisabled]="isModify" >
                </ourpalm-autocomplete>
              </div>
            </div>

            <div class="form-group"  *ngSwitchCase="'date'" >
              <label class="control-label"  [title]="row.label|translate">
                  {{row.label|translate}}
              </label>
              <div class="dynamicContent" >
              <input type="text"    (ngModelChange)="getAutoValue($event,row.key)"    [formControlName]="row.key"   [options]="row['options']"  class="form-control input-sm" ourpalm-daterangepicker placeholder="">
              </div>
            </div>

            <ourpalm-products-auto  *ngSwitchCase="'product'"  [disable]="isModify"  [key]="row['identifier']" [select]="row.value" (ngModelChange)="setProduct($event,row.key)" ></ourpalm-products-auto>
           
          </ng-container>
        
         
        
      </ng-container>
        </fieldset>
    <ng-content></ng-content>
  </form> `
})
export class DynamicFormComponent implements OnInit,OnChanges {

  @Input()
  form:FormGroup;

  @Input()
  dyClass:string;

  @Input()
  datas:BaseElement<any>[];

  @Input()
  isModify:boolean = false;

  computeList:any[] = [];


  constructor() { }

  ngOnInit() {

  }

  ngOnChanges(changes){
    this.computeList = [];
    this.datas.forEach(item=>{
      if(!!item['iscompute']){
        this.computeList.push(this.form.controls[item.key]);
      }
    });
    this.sum(this.computeList.length>0?true:false);

    if(this.isModify){
        for(let prop in this.form.controls){
          this.form.controls[prop].disable({onlySelf: true })
        }
    }else{
      for(let prop in this.form.controls){
        if(prop!=='score'&&prop!=='appraise') this.form.controls[prop].enable({onlySelf: true })
      }
    }
    this.form.controls['qaUserId'].disable({onlySelf: true });
    this.form.controls['score'].disable({onlySelf: true });
    this.form.controls['appraise'].disable({onlySelf: true })
  }

  getAutoValue(ev,key:string){
    if( this.form.controls[key].value!=ev){
      this.form.patchValue({
        [key]:ev
      } );
    }
  }

  setProduct(ev,key){
     this.form.patchValue({
       [key]:ev
     })
  }

  selectChange(ev:any,callback:Function,iscompute:Boolean){
    callback&&callback(ev.currentTarget.value,this.form.value);
    this.sum(iscompute)
  }



  sum(iscompute:Boolean){

    if(!iscompute||!this.form.controls['channelId'])return false;
    let sum:number[] =[];
    this.computeList.forEach(item=>{
      sum.push(Number.isInteger(item.value*1)?item.value*1:0)
    });
    const point = sum.reduce((item1,item2)=>{return item1+item2},0);
    if(this.form.controls['channelId'].value ==='07'){
      this.form.patchValue({
        "score":100-point,
        "appraise":this.judge(100-point)
      })
    }else{
      this.form.patchValue({
        "score":point,
        "appraise":this.judge(point)
      })
    }

  }

  judge(point:number):string{
      if (point >= 89) {
        return '优'
      }   else if (point >= 83) {
        return '良'

      } else if (point >= 74) {
        return '中'

      } else if (point >= 54) {
        return '及格'

      } else if (point > 0) {
        return '差'

      } else if (point <= 0) {
        return '极差'
      }
  }

}
