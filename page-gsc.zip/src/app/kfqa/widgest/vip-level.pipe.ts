import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'vipPrerogativeLevel'
})
export class VipPrerogativeLevel implements PipeTransform {
  translations:any;
  constructor(private translate:TranslateService){
     this.translate.get(['黄金','钻石','银钻','金钻'])
       .subscribe(res=>{
          this.translations = res;
       })
  }

  transform(type: string, args?: any): any {
    if (type === '1') {
      return   '黄金';
    } else  if (type === '2') {
      return    '钻石';
    }else  if (type === '3') {
      return    '银钻';
    }else  if (type === '4') {
      return   '金钻';
    } else{
      return '';
    }
  }

}
