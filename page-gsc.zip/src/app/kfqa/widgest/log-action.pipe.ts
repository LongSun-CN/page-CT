import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'logAction'
})
export class LogActionPipe implements PipeTransform {
  translations:any;
  constructor(private translate:TranslateService){
     this.translate.get(['新增大客户信息','修改大客户信息','删除大客户信息','添加大客户小号','修改大客户小号信息','删除大客户小号信息'])
       .subscribe(res=>{
          this.translations = res;
       })
  }

  transform(type: string, args?: any): any {

      if (type == '1') {
        return this.translations['新增大客户信息'];
      } else  if (type == '2') {
        return this.translations['修改大客户信息'];
      }else  if (type == '3') {
        return this.translations['删除大客户信息'];
      }else  if (type == '4') {
        return this.translations['添加大客户小号'];
      }else  if (type == '5') {
        return this.translations['修改大客户小号信息'];
      }else  if (type == '6') {
        return this.translations['删除大客户小号信息'];
      }
    return '';
  }

}
