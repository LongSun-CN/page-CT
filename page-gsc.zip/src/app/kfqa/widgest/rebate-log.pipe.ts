/**
 * Created by admin on 2017/7/21.
 */

import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'rebateLog'
})
export class rebateLogPipe implements PipeTransform {
  translations:any;
  constructor(private translate:TranslateService){
    this.translate.get(['待返利','待审核','审核不过','处理完成','已撤回'])
      .subscribe(res=>{
        this.translations = res;
      })
  }

  transform(type: string, args?: any): any {

    if (type == '0101') {
      return   '添加';
    } else  if (type == '0102') {
      return    '修改';
    }else  if (type == '0103') {
      return    '审核通过';
    }else  if (type == '0104') {
      return   '审核不过';
    }else  if (type == '0105') {
      return '发放返利';
    }else{
      return '';
    }


  }

}

