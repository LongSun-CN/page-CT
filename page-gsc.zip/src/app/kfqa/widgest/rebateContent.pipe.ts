import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'rebateContent'
})
export class rebateContentPipe implements PipeTransform {
  translations:any;
  constructor(private translate:TranslateService){
     this.translate.get(['元宝','道具','元宝+道具'])
       .subscribe(res=>{
          this.translations = res;
       })
  }

  transform(type: string, args?: any): any {

    if (type == '0') {
      return  this.translations['元宝'];
    } else  if (type == '1') {
      return  this.translations['道具'];
    }else  if (type == '2') {
      return this.translations['元宝+道具'];
    }else{
      return '';
    }
  }

}
