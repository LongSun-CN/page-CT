/**
 * Created by admin on 2017/7/21.
 */

import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'rebateStatus'
})
export class rebateStatusPipe implements PipeTransform {
  translations:any;
  constructor(private translate:TranslateService){
    this.translate.get(['待返利','待审核','审核不过','处理完成','已撤回'])
      .subscribe(res=>{
        this.translations = res;
      })
  }

  transform(type: string, args?: any): any {

    if (type == '01') {
      return   this.translations['待返利'];
    } else  if (type == '02') {
      return   this.translations['待审核'];
    }else  if (type == '03') {
      return  this.translations['审核不过'];
    }else  if (type == '99') {
      return  this.translations['处理完成'];
    }else  if (type == '04') {
      return  this.translations['已撤回'];
    }else{
      return '';
    }
  }

}

