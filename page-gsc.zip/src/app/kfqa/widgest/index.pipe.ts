/**
 * Created by admin on 2017/8/18.
 */
import {LogActionPipe} from './log-action.pipe';
import {rebateLogPipe} from './rebate-log.pipe';
import {rebateContentPipe} from './rebateContent.pipe';
import {rebateStatusPipe} from './rebate-status.pipe';
import {VipPrerogativeLevel} from './vip-level.pipe';

export const pipe = [
  LogActionPipe,
  rebateLogPipe,
  rebateContentPipe,
  rebateStatusPipe,
  VipPrerogativeLevel
];
