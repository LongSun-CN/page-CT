/**
 * Created by admin on 2017/6/23.
 */
import {Action} from "@ngrx/store";
import {VipManagerSearch} from  "../entity/vipmanager.search";
import {Page} from "ngx-ourpalm-table"


export const SEARCH_VIPMANAGER  = 'search vipManager';


export  class VipManagerState {
    isInit?:boolean = true;
    search:string;
    data:Page
}
export function VipManagerReducer(state:VipManagerState,action:Action){
    switch (action.type){
      case SEARCH_VIPMANAGER:
        return action.payload;
      default :
        return state;
    }
}



