/**
 * Created by admin on 2017/6/23.
 */
import {Action} from "@ngrx/store";
import {BigcustomerRebate} from  "../entity/Bigcustomer.search";
import {Page} from "ngx-ourpalm-table"


export const SEARCH_BIGCUSTOMER_REBATE  = 'search bigcustomer rebate';


export  class BigcustomerRebateState {
  isInit?:boolean = true;
  search:string;
  data:Page
}
export function BigcustomerRebateReducer(state:BigcustomerRebateState,action:Action){
  switch (action.type){
    case SEARCH_BIGCUSTOMER_REBATE:
      return action.payload;
    default :
      return state;
  }
}



