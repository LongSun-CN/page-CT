/**
 * Created by admin on 2017/6/23.
 */
import {VipManagerReducer} from  "./vip-manager.reducer";
import {QualityReducer} from "./quality.reducer";
import { QualityReporterReducer } from  "./quality-reporter.reducer";
import {BigcustomerSearchReducer} from "./bigcustomer.search.reducer";
import { BigcustomerIdentyReducer } from  "./bigcustomer.identy.reducer";
import {BigcustomerRebateReducer} from  "./bigcustomer.rebate.reducer";
export const kfqaReducer = {
  vipManager:VipManagerReducer,
  quality:QualityReducer,
  qualityReporter:QualityReporterReducer,
  bigSearch:BigcustomerSearchReducer,
  bigIdenty:BigcustomerIdentyReducer,
  bigRebate:BigcustomerRebateReducer
};
