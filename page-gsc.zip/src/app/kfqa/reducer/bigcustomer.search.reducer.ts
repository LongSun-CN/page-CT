/**
 * Created by admin on 2017/6/23.
 */
import {Action} from "@ngrx/store";
import {BigcustomerSearch} from  "../entity/Bigcustomer.search";
import {Page} from "ngx-ourpalm-table"


export const SEARCH_BIGCUSTOMER_SEARCH  = 'search bigcustomer serach';


export  class BigcustomerSearchState {
  isInit?:boolean = true;
  search:string;
  data:Page
}
export function BigcustomerSearchReducer(state:BigcustomerSearchState,action:Action){
  switch (action.type){
    case SEARCH_BIGCUSTOMER_SEARCH:
      return action.payload;
    default :
      return state;
  }
}



