/**
 * Created by admin on 2017/6/23.
 */
import {Action} from "@ngrx/store";
import {BigcustomerIdenty} from  "../entity/Bigcustomer.search";
import {Page} from "ngx-ourpalm-table"


export const SEARCH_BIGCUSTOMER_IDENTY  = 'search bigcustomer identy';


export  class BigcustomerIdentyState {
  isInit?:boolean = true;
  search:string;
  data:Page
}
export function BigcustomerIdentyReducer(state:BigcustomerIdentyState,action:Action){
  switch (action.type){
    case SEARCH_BIGCUSTOMER_IDENTY:
      return action.payload;
    default :
      return state;
  }
}



