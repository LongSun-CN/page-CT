/**
 * Created by admin on 2017/6/23.
 */
import {Action} from "@ngrx/store";
import { QualityreporterSearch } from  "../entity/Quality-reporter.search";
import {Page} from "ngx-ourpalm-table"


export const SEARCH_QUALITY_REPORTER  = 'search quality reporter';


export  class QualityReporterState {
  isInit?:boolean;
  search:string;
  data:Page
}
export function QualityReporterReducer(state:QualityReporterState,action:Action){
  switch (action.type){
    case SEARCH_QUALITY_REPORTER:
      return action.payload;
    default :
      return state;
  }
}



