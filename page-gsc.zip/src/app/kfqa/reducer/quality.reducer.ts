/**
 * Created by admin on 2017/6/23.
 */
import {Action} from "@ngrx/store";
import {QualitySearch} from  "../entity/Quality.search";
import {Page} from "ngx-ourpalm-table"


export const SEARCH_QUALITY  = 'search quality';


export  class QualityState {
  isInit?:boolean = true;
  search:string;
  data:Page
}
export function QualityReducer(state:QualityState,action:Action){
  switch (action.type){
    case SEARCH_QUALITY:
      return action.payload;
    default :
      return state;
  }
}



