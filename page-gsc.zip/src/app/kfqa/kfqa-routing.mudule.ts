import {kfqaPages_Obj} from "./pages";
import {Routes} from "../router";


export const kfqaRouting: Routes = [
    {
        path: 'kfqa',
        component: kfqaPages_Obj.QualityIndexComponent
    }, {
        path: 'kfqa/index',
        component: kfqaPages_Obj.QualityIndexComponent
    }, {
        path: 'kfqa/vipManager',
        component: kfqaPages_Obj.VipManagerComponent
    }, {
        path: 'kfqa/qualityRepoter',
        component: kfqaPages_Obj.QualityReporterComponent
    }, {
        path: 'kfqa/bigCustomerSearch',
        component: kfqaPages_Obj.BigcustomerSearchComponent
    }, {
        path: 'kfqa/bigCustomerIdengty',
        component: kfqaPages_Obj.BigcustumerIdentyComponent
    }, {
        path: 'kfqa/bigCustomerRebate',
        component: kfqaPages_Obj.BigcustomerRebateComponent
    }
];
