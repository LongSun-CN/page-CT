/**
 * Created by admin on 2017/6/30.
 */
export { qualityService } from "./quality.service";
export { VipManagerService }  from "./vip-manager.service";
export {BigcustomerService } from "./bigCustomer.service";
