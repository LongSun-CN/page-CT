import {Injectable} from "@angular/core";
import {HttpService} from "../../shared/services/httpx.service";
import {Store} from "@ngrx/store";
import {TranslateService} from "@ngx-translate/core";
import {environment} from "../../../environments/environment";
import {BigcustomerSearchState, SEARCH_BIGCUSTOMER_SEARCH} from "app/kfqa/reducer/bigcustomer.search.reducer";
import {BigcustomerIdentyState, SEARCH_BIGCUSTOMER_IDENTY} from  "app/kfqa/reducer/bigcustomer.identy.reducer"
import {BigcustomerSearch, BigcustomerIdenty, BigcustomerRebate} from "../entity/Bigcustomer.search";
import {LanProTypeService} from "../../widgets/language-producttype/language-producttype.service";
import {ToastService} from "../../shared/services/toast.service";
import {DateFormatterPipe} from '../../widgets/ourpalm-pipes/date-formatter.pipe';
import {BigcustomerRebateState, SEARCH_BIGCUSTOMER_REBATE} from "../reducer/bigcustomer.rebate.reducer";
import {mask_key} from "../../shared/services/httpx.interceptor";
/**
 * Created by admin on 2017/7/11.
 */
@Injectable()
export class BigcustomerService {
  constructor(private http: HttpService, private $store: Store<BigcustomerSearchState>, private  toast: ToastService,
              private translate: TranslateService, private lanservice: LanProTypeService, private dateformatter: DateFormatterPipe) {

  }


  //大客户查询
  queryAllBigCustomerPage(search:any,param: any): void {
    param = {...search,...param};
    let _param: any = {
      localeId: this.lanservice.getCurrentLanguage().value,
      productId: (param.product && param.product.id) ? param.product.id : '',
      server: (param.server && param.server.id) ? param.server.id : '',
      operationLineId: (param.channel && param.channel.id) ? param.channel.id : '',
      vipLevelValue: (param.vipLevel && param.vipLevel.id) ? param.vipLevel.id : '',
    };
    _param = {...param, ..._param};

    if (!_param.productId || _param.productId === '-1' || ((!_param.server || _param.server === '-1') && (!_param.operationLineId || '-1' === _param.operationLineId)
      && (!_param.vipLevelValue || '-1' === _param.vipLevelValue) && !_param.roleId && !_param.roleName)) {
      return this.toast.translate('warning', '请选择产品和补充条件');
    }

    this.http
      .get(environment.getUrl('customService/bigCustomer/queryAllBigCustomerPage.htm'), _param)
      .map((res: any) => {
        res = res.json();
        res.data&&res.data.list&&res.data.list.map(item => {
          const fmt = 'YYYY-MM-DD HH:mm:ss';
          item.lastLoginTime = this.dateformatter.transform(item.lastLoginTime, fmt);
          item.birthday = this.dateformatter.transform(item.birthday, fmt);
          item.modifyTime = this.dateformatter.transform(item.modifyTime, fmt);
          item.createTime = this.dateformatter.transform(item.createTime, fmt);
          item.certifiedTime = this.dateformatter.transform(item.certifiedTime, fmt);
          return item;
        });
        return res;
      })
      .subscribe(res => {
        const state: BigcustomerSearchState = {
          search:JSON.stringify(search),
          data: {
            currentPage: param.currentPage,
            pageSize: param.pageSize,
            total: (res.data.list&&res.data.totalCount)||0,
            rows: (res.data&&res.data.list)||[]
          }
        };
        this.$store.dispatch({
          type: SEARCH_BIGCUSTOMER_SEARCH,
          payload: state
        })
      });
  };

  //已认证客户小号
  getIdentityBigCustomerInfo(param: { customerId: string }): Promise<any> {
    return this.http
      .get(environment.getUrl('customService/bigCustomer/getIdentityBigCustomerInfo.htm'), param)
      .map((res: any) => {
        res = res.json();
        const fmt = 'YYYY-MM-DD HH:mm:ss';
        res.data.log.map(item => {
          item.createTime = this.dateformatter.transform(item.createTime, fmt);
          return item;
        });
        return res;
      })
      .toPromise();
  }

  //添加认证
  addIdentityBigCustomer(param: any): Promise<any> {
    return this.http
      .post(environment.getUrl('customService/bigCustomer/addIdentityBigCustomer.htm'), param)
      .map(res => res.json())
      .toPromise();
  }

  //修改认证
  updateIdentityBigCustomer(param: any): Promise<any> {
    return this.http
      .post(environment.getUrl('customService/bigCustomer/updateIdentityBigCustomer.htm'), param)
      .map(res => res.json())
      .toPromise();
  }

  //修改vip
  modifyVipInfo(param: any): Promise<any> {
    return this.http
      .post(environment.getUrl('customService/bigCustomer/modifyVipInfo.htm'), param)
      .map(res => res.json())
      .toPromise();
  }

  //导出
  exportAllBigCustomer(param: any): void {
    return this.http.download(environment.getUrl('customService/bigCustomer/exportAllBigCustomer.htm'), param);
  }


  queryIdentityBigCustomerPage(search:any,param: any): void {
    param = {...param,...search};
    const _param = {
      createUser: param.submitter && param.submitter.accountId,
      localeId: this.lanservice.getCurrentLanguage().value,
      productId: (param.product && param.product && param.product.id) ? param.product.id : '',
      logicServerId: (param.server && param.server && param.server.id) ? param.server.id : '',
      operationLine: (param.channel && param.channel && param.channel.id) ? param.channel.id : '',
      certifiedTime:`${(param.certifiedTime&&param.certifiedTime.start)||''}${(param.certifiedTime&&param.certifiedTime.end&&(' - ' +param.certifiedTime.end)||'')}`,
      birthday:`${(param.birthday&&param.birthday.start)||''}${(param.birthday&&param.birthday.end&&(' - ' +param.birthday.end)||'')}`
    };
    if (!_param.productId) {
      return this.toast.translate('warning', '请选择产品');
    }
    param = Object.assign({}, param, _param);

    this.http.get(environment.getUrl('customService/bigCustomer/queryIdentityBigCustomerPage.htm'), param)
      .map((res: any) => {
        res = res.json();
        res.data&&res.data.list&&res.data.list.map(item => {
          const fmt = 'YYYY-MM-DD HH:mm:ss';
          item.lastLoginTime = this.dateformatter.transform(item.lastLoginTime, fmt);
          item.birthday = this.dateformatter.transform(item.birthday, fmt);
          item.modifyTime = this.dateformatter.transform(item.modifyTime, fmt);
          item.createTime = this.dateformatter.transform(item.createTime, fmt);
          item.certifiedTime = this.dateformatter.transform(item.certifiedTime, fmt);
          return item;
        });
        return res;
      })
      .subscribe(res => {
        const state: BigcustomerIdentyState = {
          search:JSON.stringify(search),
          isInit: false,
          data: {
            currentPage: param.currentPage,
            pageSize: param.pageSize,
            total: (res.data&&res.data.totalCount)||0,
            rows: (res.data&&res.data.list)||[]
          }
        };
        this.$store.dispatch({
          type: SEARCH_BIGCUSTOMER_IDENTY,
          payload: state
        })
      });
  };

  batchModifyCurrentLogicServer(param: any): Promise<any> {
    return this.http.post(environment.getUrl('customService/bigCustomer/batchModifyCurrentLogicServer.htm'), param).map(res => res.json()).toPromise();
  }

  //导出认证大客  `
  exportIdentityBigCustomer(param: any): void {
    this.http.download(environment.getUrl('customService/bigCustomer/exportIdentityBigCustomer.htm'), param);
  };

  //查询已认证大客户
  queryRebatePage(search:any,param: any): void {
    param = {...param,...search};
    let _param: any = {
      localeId: this.lanservice.getCurrentLanguage().value,
      productId: (param.product && param.product.id) ? param.product.id : '',
      serverId: (param.server && param.server.id) ? param.server.id : '',
      operaId: (param.channel && param.channel.id) ? param.channel.id : '',
      createUser: param.createUser && param.createUser.accountId,
      createTime:`${(param.createTime&&param.createTime.start)||''}${(param.createTime&&param.createTime.end&&(' - ' +param.createTime.end)||'')}`
    };
    _param = {...param, ..._param};

    this.http
      .get(environment.getUrl('customService/bigCustomerRebate/queryRebatePage.htm'), _param)
      .map((res: any) => {
        res = res.json();
        res.data.list.map(item => {
          const fmt = 'YYYY-MM-DD HH:mm:ss';
          item.completeTime = this.dateformatter.transform(item.completeTime, fmt);
          item.createTime = this.dateformatter.transform(item.createTime, fmt);
          item.modifyTime = this.dateformatter.transform(item.modifyTime, fmt);
          return item;
        });
        return res;
      })
      .subscribe(res => {
        const state: BigcustomerRebateState = {
          search:JSON.stringify(search),
          data: {
            currentPage: param.currentPage,
            pageSize: param.pageSize,
            total: res.data.totalCount,
            rows: res.data.list
          }
        };
        this.$store.dispatch({
          type: SEARCH_BIGCUSTOMER_REBATE,
          payload: state
        })
      });
  };

  //查询道具
  queryGamePropList(param: any): Promise<any> {
    return this
      .http
      .get(environment.getUrl('customService/bigCustomerRebate/queryGamePropList.htm'), param)
      .map(res => res.json())
      .toPromise();
  }

  //修改道具
  modifyGamePropList(param: any): Promise<any> {
    return this
      .http
      .post(environment.getUrl('customService/bigCustomerRebate/modifyGamePropList.htm'), param)
      .map(res => res.json())
      .toPromise();
  }

  //
  getRebateRuleList(param: any): Promise<any> {
    return this
      .http
      .get(environment.getUrl('customService/bigCustomerRebate/getRebateRuleList.htm'), param)
      .map(res => res.json())
      .toPromise();
  }


  isNoGap(list: any[], prop1: string, prop2: string): boolean {
    list.sort(function (a, b) {
      return a[prop1] - b[prop1];
    });
    for (var i = 1; i < list.length; i++) {
      if (list[i][prop1] - list[i - 1][prop2] != 1) {
        return false;
      }
    }
    return true;
  }

  //修改返利规则
  modifyRebateRule(param: any): Promise<any> {
    return this
      .http
      .post(environment.getUrl('customService/bigCustomerRebate/modifyRebateRule.htm'), param)
      .map(res => res.json())
      .toPromise();
  }

  changeRebateStatus(param: any): Promise<any> {
    return this
      .http
      .post(((param.status == '99' || !!param.cancel) ? environment.getUrl('customService/bigCustomerRebate/changeRebateDeliverStatus.htm') : environment.getUrl('customService/bigCustomerRebate/changeRebateStatus.htm'))
        , param)
      .map(res => res.json())
      .toPromise();
  }

  queryRebatePage_update(param: any): Promise<any> {
    return this
      .http
      .post(environment.getUrl('customService/bigCustomerRebate/queryRebatePage.htm'), param)
      .map(res => res.json())
      .toPromise();
  }

  //获取订单数据
  getOrderList(param: any): Promise<any> {
    return this
      .http
      .get(environment.getUrl('customService/bigCustomerRebate/getOrderList.htm'), param)
      .map(res => res.json())
      .toPromise();
  };


  //修改返利订单数据
  updateRebateRecord(param: any): Promise<any> {
    return this
      .http.post(environment.getUrl('customService/bigCustomerRebate/updateRebateRecord.htm'), param)
      .map(res => res.json())
      .toPromise();
  };

  //添加返利订单数据
  addRebateInfo(param: any): Promise<any> {
    return this
      .http.post(environment.getUrl('customService/bigCustomerRebate/addRebateRecord.htm'), param)
      .map(res => res.json())
      .toPromise();
  };

  //修改时 获取返利订单记录
  getRebateRecord(param: any): Promise<any> {
    return this
      .http
      .get(environment.getUrl('customService/bigCustomerRebate/getRebateRecord.htm'), param)
      .map(res => res.json())
      .toPromise();
  };

  //获取产品vip信息
  getVipLevel(param: any): Promise<any> {
    return this
      .http
      .get(environment.getUrl('customService/bigCustomer/getVipLevel.htm'), param)
      .map(res => res.json())
      .toPromise();
  };

  //导出返利大客户
  exportRebate(param: any): void {
    this.http.download(environment.getUrl('customService/bigCustomerRebate/exportRebate.htm'), param);
  };
}
