/**
 * Created by admin on 2017/6/23.
 */
import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {environment} from "../../../environments/environment";
import {HttpService} from "../../shared/services/httpx.service";
import {VipManagerSearch} from  "../entity/vipmanager.search";
import {VipManagerState, SEARCH_VIPMANAGER} from  "../reducer/vip-manager.reducer";
import {Observable} from "rxjs/Observable";
// import * as moment from "moment";

@Injectable()
export class VipManagerService {

  constructor(private http: HttpService, private $store: Store<VipManagerState>) {

  }


  queryAllSignatureUserPage(search: any, options: any): void {

    var param = {
      qq: '',
      mobile: '',
      productName: search.product.text,
      productId: search.product.id,
      server: search.server.id,
      certifiedTime: `${(search.certifiedTime && search.certifiedTime.start) || ''}${(search.certifiedTime && search.certifiedTime.end && (' - ' + search.certifiedTime.end) || '')}`,
      submitTime: `${(search.submitTime && search.submitTime.start) || ''}${(search.submitTime && search.submitTime.end && (' - ' + search.submitTime.end) || '')}`,
    };

    if (search.contactWay && search.contactWay.selectValue == '0') {
        param.mobile = search.contactWay.value;
    } else if (search.contactWay && search.contactWay.selectValue == '1') {
        param.qq = search.contactWay.value;
    }


    this.http.get(
      environment.getUrl('customService/signatureUser/queryAllSignatureUserPage.htm'),
      {...search, ...options, ...param}
    )
      .map(res => res.json())
      .subscribe(result => {
          result.data && result.data.list && result.data.list.map(function (item) {
            (!!item.submitTime) && (item.submitTime = moment(new Date(item.submitTime)).format('YYYY-MM-DD HH:mm:ss'));
            (!!item.certifiedTime) && (item.certifiedTime = moment(new Date(item.certifiedTime)).format('YYYY-MM-DD HH:mm:ss'));
            (!!item.newFirstLoginTime) && (item.newFirstLoginTime = moment(new Date(item.newFirstLoginTime)).format('YYYY-MM-DD HH:mm:ss'));
            (!!item.newLastLoginTime) && (item.newLastLoginTime = moment(new Date(item.newLastLoginTime)).format('YYYY-MM-DD HH:mm:ss'));
            (!!item.oldLastLoginTime) && (item.oldLastLoginTime = moment(new Date(item.oldLastLoginTime)).format('YYYY-MM-DD HH:mm:ss'));
            (!!item.oldFirstLoginTime) && (item.oldFirstLoginTime = moment(new Date(item.oldFirstLoginTime)).format('YYYY-MM-DD HH:mm:ss'));
            return item;
          });

          let state = {
            search: JSON.stringify(search),
            data: {
              currentPage: options.currentPage,
              pageSize: options.pageSize,
              total: result.data.totalCount,
              rows: (result.data && result.data.list) || []
            }
          };

          this.$store.dispatch({
            type: SEARCH_VIPMANAGER,
            payload: state
          })
        }
      )
  }

  updateIdentityStatus(param: any): Promise<any> {
    return this.http
      .get(
        environment.getUrl('customService/signatureUser/updateIdentityStatus.htm'),
        param
      ).map(res => res.json())
      .toPromise();
  }

  exportSignatureUserInfo(param: any): void {
    this.http.download(
      environment.getUrl('customService/signatureUser/exportSignatureUserInfo.htm'),
      param
    );
  }

  downLoadTemplate() {
    this.http.download(environment.getUrl('customService/signatureUser/downLoadTemplate.htm'))
  }

}
