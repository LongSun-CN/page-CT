/**
 * Created by choui on 2017/6/23.
 */
import {Injectable} from "@angular/core";
import {Store} from "@ngrx/store";
import {environment} from "../../../environments/environment";
import {HttpService} from "../../shared/services/httpx.service";
import {QualityState, SEARCH_QUALITY} from "../reducer/quality.reducer";
import {BaseElement} from "../widgest/dynamic-form/element/baseElement";
import {SelectElement} from "../widgest/dynamic-form/element/selectElement";
import {AutoComplete} from "../widgest/dynamic-form/element/autoComplete";
import {ProductElement} from "../widgest/dynamic-form/element/productElement";
import {DateElemet} from "../widgest/dynamic-form/element/dateElement";
import {OurpalmAutoComplete} from "../../widgets/ourpalm-autocomplete/OurpalmAutoComplete";
import {InputElement} from "../widgest/dynamic-form/element/inputElement";
import {FormControl, FormGroup} from "@angular/forms";
import {User} from "../../widgets/user-box/user";
import {ReplaySubject} from "rxjs/ReplaySubject";
import {TextAreaElement} from "../widgest/dynamic-form/element/textAreaElemnet";
import {TranslateService} from "@ngx-translate/core";
import {QualityReporterState, SEARCH_QUALITY_REPORTER} from "../reducer/quality-reporter.reducer";
import {UserInfoState} from "../../shared/reducers/userinfo-reducer";


@Injectable()
export class qualityService {

    user: User;
    originAddFormsData: BaseElement<any>[];
    addDynamicFormsData: ReplaySubject<BaseElement<any>[]> = new ReplaySubject<BaseElement<any>[]>();
    emptyParam: any;

    constructor(private http: HttpService, private $store: Store<QualityState>, private translate: TranslateService) {
        // this.user = <User>JSON.parse(window.localStorage.getItem('gsc-ourpalm-userInfo'));
        this.$store.select('userInfo').take(1).subscribe((state: UserInfoState) => {
            this.user = state.user;
        });

        this.getAddData();
        this.addDynamicFormsData.next(this.originAddFormsData);
        this.translate.get(['渠道', '客服', '产品', '质检人', '沟通日期', '组别', '评分', '质检日期', '评价', '描述'
            , '质检渠道', '请选择', '微信', '后台', '热线', '拳皇', '纵乐', '邮件', 'LOG'
        ]).subscribe();
        this.emptyParam = {
            "sure": {
                "channelId": "渠道",
                "kfUserId": "客服",
                "productId": "产品",
                "qaUserId": "质检人",
                "communicateDate": "沟通日期",
                "workShift": "班次",
                "groupId": "组别",
                "score": "评分",
                "inspectionDate": "质检日期",
                "appraise": "评价",
                "desc": "描述",
            },
            "unsure": {}
        }
    }

    //查询客服接口
    getKfInfoList(accountOrName: string, count: number): Promise<any> {
        const param = {
            accountOrName: accountOrName,
            count: count,
            mask_key: false
        };
        return this.http
            .get(environment.getUrl('customService/kfqa/queryKfInfoList.htm'), param)
            .map(res => res.json())
            .toPromise()
    }

    //初始化查询表单数据
    getInitData(): BaseElement<any>[] {
        const that = this;

        const autocompleteService = new OurpalmAutoComplete({
            loader: function (val, callback) {
                that.getKfInfoList(val, 10).then(result => {
                    callback(result.data || [])
                })
            },
            formatterRow: function (row: any): any {
                return `${row.name}(${row.user})(${row.jobnum})`;
            },
            formatterValue: function (row): any {
                return row.name;
            }
        });


        return [
            new SelectElement({
                key: 'qualityChannel',
                label: '质检渠道',
                options: [
                    {key: '请选择', value: ''},
                    {key: '微信', value: '01'},
                    {key: '后台', value: '02'},
                    {key: '热线', value: '03'},
                    {key: '拳皇', value: '04'},
                    {key: '纵乐', value: '05'},
                    {key: '邮件', value: 'o6'},
                    {key: 'LOG', value: '07'},
                    {key: 'QQ', value: '08'},
                ],
                order: 1
            }),
            new AutoComplete({
                key: 'qualiter',
                label: '质检人',
                options: autocompleteService
            }),
            new AutoComplete({
                key: 'customerService',
                label: '客服',
                options: autocompleteService
            }),
            new DateElemet({
                key: 'inspectionDate',
                label: '质检日期',
                options: {locale: {format: "YYYY-MM-DD"}, opens: 'left'}
            }),
            new SelectElement({
                key: 'groupId',
                label: '组别',
                options: [
                    {key: '请选择', value: ''},
                    {key: 'A', value: '01'},
                    {key: 'B', value: '02'},
                    {key: 'C', value: '03'},
                    {key: 'D', value: '04'},
                    {key: 'E', value: '05'},
                ]
            }),
            new ProductElement({
                key: 'product',
                label: '产品',
                identifier: 'quality'
            })
        ];
    }

    //初始化添加表单数据
    getAddData(): void {
        const that = this;
        const autocompleteService = new OurpalmAutoComplete({
            loader: function (val, callback) {
                that.getKfInfoList(val, 10).then(result => {
                    callback(result.data || [])
                })
            },
            formatterRow: function (row: any): any {
                return `${row.name}(${row.user})(${row.jobnum})`;
            },
            formatterValue: function (row): any {
                return row.name;
            }
        });

        const DynamicColumnHandler = function (channelId: string, item?: any) {
            that.resetAddData();
            that.originAddFormsData[1] = new SelectElement({
                key: 'channelId',
                label: '质检渠道',
                changeEvent: DynamicColumnHandler,
                value: channelId,
                options: [
                    {key: '请选择', value: ''},
                    {key: '微信', value: '01'},
                    {key: '后台', value: '02'},
                    {key: '热线', value: '03'},
                    {key: '拳皇', value: '04'},
                    {key: '纵乐', value: '05'},
                    {key: '邮件', value: 'o6'},
                    {key: 'LOG', value: '07'},
                    {key: 'QQ', value: '08'},
                ],
                order: 1
            });
            if (!!channelId) {
                that.queryDynamicColumn(channelId).then(res => {
                    if (res.status === '0') {
                        that.DynamicColumnHandler(res, item);
                    }
                })
            }
        };


        this.originAddFormsData = [
            new InputElement({
                "key": "qaUserId",
                "label": "质检人",
                "disabled": true,
                "value": this.user.name
            }),
            new SelectElement({
                key: 'channelId',
                label: '质检渠道',
                changeEvent: DynamicColumnHandler,
                options: [
                    {key: '请选择', value: ''},
                    {key: '微信', value: '01'},
                    {key: '后台', value: '02'},
                    {key: '热线', value: '03'},
                    {key: '拳皇', value: '04'},
                    {key: '纵乐', value: '05'},
                    {key: '邮件', value: 'o6'},
                    {key: 'LOG', value: '07'},
                    {key: 'QQ', value: '08'},
                ],
                order: 1
            }),
            new DateElemet({
                key: 'communicateDate',
                label: '沟通日期',
                options: {singleDatePicker: true, showCustomRangeLabel: false, opens: 'left'}
            }),
            new DateElemet({
                key: 'inspectionDate',
                label: '质检日期',
                options: {
                    singleDatePicker: true,
                    timePicker: false,
                    showCustomRangeLabel: false,
                    locale: {format: "YYYY-MM-DD"},
                    opens: 'left'
                }
            }),
            new SelectElement({
                key: 'groupId',
                label: '组别',
                options: [
                    {key: '请选择', value: ''},
                    {key: 'A', value: '01'},
                    {key: 'B', value: '02'},
                    {key: 'C', value: '03'},
                    {key: 'D', value: '04'},
                    {key: 'E', value: '05'},
                ]
            }),
            new SelectElement({
                key: 'workShift',
                label: '班次',
                options: [
                    {key: '夜', value: '00'},
                    {key: '正', value: '01'},
                    {key: '白', value: '02'}]
            }),
            new AutoComplete({
                key: 'kfUser',
                label: '客服',
                options: autocompleteService
            }),
            new BaseElement({
                controlType: 'hidden',
                key: 'kfUserId',
                label: '客服',
                value: ""
            }),
            new BaseElement({
                controlType: 'hidden',
                key: 'kfUserName',
                label: '客服',
                value: ""
            }),
            new ProductElement({
                key: 'product',
                label: '产品',
                identifier: 'quality'
            }),
            new BaseElement({
                controlType: 'hidden',
                key: 'productId',
                label: '产品',
                value: ""
            }),
            new BaseElement({
                controlType: 'hidden',
                key: 'productName',
                label: '产品',
                value: ""
            }),
            new BaseElement({
                controlType: 'gap'
            }),
            new InputElement({
                "key": "score",
                "label": "得分",
                "disabled": true,
                "value": 100
            }),
            new InputElement({
                "key": "appraise",
                "label": "质检评定",
                "disabled": true,
                "value": ""
            }),
            new TextAreaElement({
                key: 'desc',
                label: "内容",
                row: 5,
                value: ""
            })
        ];
    }

    setEmtpyParam(unsure: any): void {
        this.emptyParam.unsure = unsure;
    }

    resetAddData() {
        this.getAddData();
        this.addDynamicFormsData.next(this.originAddFormsData);
    }


    //数据转化表单接口
    dataIntoForm(elemens: BaseElement<any>[]): FormGroup {
        let ctl = {};
        elemens.forEach(item => {
            ctl[item.key] = new FormControl(item.value)
        });

        return new FormGroup(ctl);

    }


    //获取动态列
    queryDynamicColumn = function (channelId: string, columnName: string = ''): Promise<any> {
        return this.http
            .get(environment.getUrl('customService/kfqa/queryDynamicColumn.htm'), {
                channelId: channelId,
                columnName: columnName
            })
            .map(res => res.json())
            .toPromise();
    };

    DynamicColumnHandler(res: any, item?: any) {
        let list: any[] = res.data.list;
        list = list.sort((item1, item2) => {
            return item1.sort * 1 - item2.sort * 1
        });

        let resultList: BaseElement<any>[] = [];
        let computeAction: string[] = [];
        let emptyparam: any = {};
        list.forEach(li => {
            emptyparam[li.id] = li.columnName;
            switch (li.type) {
                case "00":
                    resultList.push(new InputElement({
                        key: li.id,
                        label: li.columnName,
                        value: li.value || '',
                        iscompute: li.isCompute === '1'
                    }));
                    break;
                case "01":
                    resultList.push(new SelectElement({
                        key: li.id,
                        label: li.columnName,
                        options: JSON.parse(li.value),
                        value: JSON.parse(li.value)[0].value || '',
                        iscompute: li.isCompute === '1'
                    }))

            }
        });
        this.setEmtpyParam(emptyparam);

        let resultForms: BaseElement<any>[] = [...this.originAddFormsData.slice(0, 12), new BaseElement({
            controlType: 'gap'
        }), ...resultList, ...this.originAddFormsData.slice(12)];

        item && (resultForms = resultForms.map((el: BaseElement<any>) => {

            if (!el.value || item[el.key]) {
                if (el.key === 'kfUser' && item['kfUserName']) {
                    el.value = item['kfUserName'];
                } else if (el.key === 'product' && item['productId'] && item['productName']) {
                    el.value = {'id': item.productId, 'text': item.productName}
                }
                if (el.key === 'kfUser' && item['kfUser'] && item['kfUser'].name) {
                    el.value = item['kfUser'].name;
                } else if (el.key === 'product' && item['product']) {
                    el.value = item['product']
                } else if (item[el.key] && el.key !== 'qaUserId') {
                    el.value = item[el.key];
                }
            }
            return el;
        }));

        this.addDynamicFormsData.next(resultForms)
    }

    //查询质检接口
    queryKfRecordPage = function (search: any, param: any): void {
        param = {...search, ...param};
        var _params = {
            'channelId': param.qualityChannel,
            'inspectionDate': `${(param.inspectionDate && param.inspectionDate.start) || ''}${(param.inspectionDate && param.inspectionDate.end && (' - ' + param.inspectionDate.end) || '')}`,
            'productId': param.product.id,
            'groupId': param.groupId,
            'kfUserId': param.customerService ? param.customerService.userId : param.customerService,
            'qaUserId': param.qualiter ? param.qualiter.userId : param.qualiter,
            'currentPage': param.currentPage,
            'rows': param.pageSize
        };

        return this
            .http.get(environment.getUrl('customService/kfqa/queryKfRecordPage.htm'), _params)
            .map(res => res.json())
            .subscribe(res => {
                let state = {
                    isInit: false,
                    search: JSON.stringify(search),
                    data: {
                        currentPage: param.currentPage,
                        pageSize: param.pageSize,
                        total: (res.data && res.data.totalCount) || 0,
                        rows: (res.data && res.data.list) || []
                    }
                };

                this.$store.dispatch({
                    type: SEARCH_QUALITY,
                    payload: state
                })
            });
    };

    addKfqaRecord(param: any): Promise<any> {
        return this
            .http.post(environment.getUrl('customService/kfqa/addKfqaRecord.htm'), param)
            .map(res => res.json())
            .toPromise()
    };

    updateKfqaRecord(param: any): Promise<any> {
        return this
            .http.post(environment.getUrl('customService/kfqa/updateKfqaRecord.htm'), param)
            .map(res => res.json())
            .toPromise()
    };

    downloadRecorsExcel = function (param: any): void {
        var _param = {
            'channelId': param.qualityChannel,
            'inspectionDate': `${(param.inspectionDate && param.inspectionDate.start) || ''}${(param.inspectionDate && param.inspectionDate.end && (' - ' + param.inspectionDate.end) || '')}`,
            'productId': param.product,
            'groupId': param.groupId,
            'kfUserId': param.customerService ? param.customerService.userId : param.customerService,
            'qaUserId': param.qualiter ? param.qualiter.userId : param.qualiter
        };
        this.http.download(environment.getUrl('customService/kfqa/downloadRecorsExcel.htm'), _param);
    };


    //质检报表页面查询功能
    queryScoreReport = function (search: any, param: any): void {
        param = {...search, ...param};
        var _params = {
            'reportType': param.reportType && param.reportType.value,
            'dimension': param.reportType && param.reportType.selectValue,
            'channelId': param.channelId,
            'groupId': param.groupId,
            'kfUserId': param.kfUser && param.kfUser.userId,
            'qaUserId': param.qualiter && param.qualiter.userId,
            'inspectionDate': `${(param.inspectionDate && param.inspectionDate.start) || ''}${(param.inspectionDate && param.inspectionDate.end && (' - ' + param.inspectionDate.end) || '')}`,
            'currentPage': param.currentPage,
            'rows': param.pageSize
        };
        return this.http
            .get(environment.getUrl('customService/kfqa/queryScoreReport.htm'), _params)
            .map(res => res.json())
            .subscribe(res => {
                const _list = [];
                if (res && res.data && res.data.list && res.data.list.length > 0) {
                    res.data.list.forEach(li => {
                        _list.push({...li, ...{dimension: li[param.dimension]}});
                    })
                }

                const state: QualityReporterState = {
                    search: JSON.stringify(search),
                    data: {
                        currentPage: param.currentPage,
                        pageSize: param.pageSize,
                        total: (res.data && res.data.totalCount) || 0,
                        rows: _list
                    }
                };
                this.$store.dispatch({
                    type: SEARCH_QUALITY_REPORTER,
                    payload: state
                })
            })
    };

    //客服-质检报表导出
    exportKfqaReport = function (param: any): void {
        var _param = {
            'reportType': param.reportType,
            'dimension': param.dimension,
            'channelId': param.channelId,
            'groupId': param.groupId,
            'kfUserId': param.kfUser ? param.kfUser.userId : param.kfUser,
            'qaUserId': param.qualiter ? param.qualiter.userId : param.qualiter,
            'inspectionDate': `${(param.inspectionDate && param.inspectionDate.start) || ''}${(param.inspectionDate && param.inspectionDate.end && (' - ' + param.inspectionDate.end) || '')}`,
        };
        this.http.download(environment.getUrl('customService/kfqa/exportKfqaReport.htm'), _param);
    }

}
