/**
 * Created by admin on 2017/6/23.
 */
import { simpleObject } from "../../entity/simple.map";

export  class QualityreporterSearch{

  reportType:string = '01';
  dimension?:number ;
  inspectionDate?:string;
  channelId?:string ="";
  kfUser?:Object = {};
  qualiter?:Object = {};
  groupId?:number;
  currentPage?:number =1;
  rows?:number = 10;



 constructor(){
 }

 setValues(param:any){
   for(let key  in this){
     if(param.hasOwnProperty(key)){
       this[key] = param[key]
     }
   }
 }

}
