/**
 * Created by admin on 2017/6/23.
 */
import { simpleObject } from "../../entity/simple.map";

export  class BigcustomerSearch{
  product?:Object;
  channel?:Object;
  server?:Object;
  vipLevel?:Object;
  roleName?:string;
  roleId?:string;
  currentPage?:number =1;
  rows?:number = 10;

 constructor(){
 }

 setValues(param:any){
   for(let key  in this){
     if(param.hasOwnProperty(key)){
       this[key] = param[key]
     }
   }
 }

}


export  class BigcustomerIdenty{
  product?:Object;
  channel?:Object;
  server?:Object;
  vipLevel?:Object;
  roleName?:string;
  roleId?:string;
  currentPage?:number =1;
  rows?:number = 10;

  constructor(){
  }

  setValues(param:any){
    for(let key  in this){
      if(param.hasOwnProperty(key)){
        this[key] = param[key]
      }
    }
  }

}


export  class BigcustomerRebate{
  product?:Object;
  channel?:Object;
  server?:Object;
  createTime?:string;
  createUser?:Object;
  id?:string;
  rebateType?:string;
  roleId?:string;
  roleName?:string;
  status?:string;

  constructor(){
  }

  setValues(param:any){
    for(let key  in this){
      if(param.hasOwnProperty(key)){
        this[key] = param[key]
      }
    }
  }

}
