/**
 * Created by admin on 2017/6/23.
 */
import { simpleObject } from "../../entity/simple.map";

export  class VipManagerSearch{
  product:simpleObject;
  _product?:simpleObject;
  server:simpleObject;
  certificationStatus:string;
  prerogativeLevel:string;
  roleName:string;
  roleId:string;
  certifiedTime:string;
  submitTime: string;
  contactWay:string;
  mobile:string;
  qq:  string;
}
