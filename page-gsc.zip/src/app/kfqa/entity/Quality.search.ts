/**
 * Created by admin on 2017/6/23.
 */
import { simpleObject } from "../../entity/simple.map";

export  class QualitySearch{

  qualityChannel?:string = "";
  qualiter?:Object ={};
  customerService?:Object = {};
  inspectionDate?:string ="";
  groupId?:string="";
  product?:Object = {};
  _product?:Object = {};
  currentPage:number =1;

 constructor(){
 }

 setValues(param:any){
   for(let key  in this){
     if(param.hasOwnProperty(key)){
       this[key] = param[key]
     }
   }
 }

}
