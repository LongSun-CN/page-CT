import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from "@angular/core";
import {WidgetModule} from "../widgets/widget.module";
import {qualityService, VipManagerService, BigcustomerService} from "./services";
import {kfqaPages_Arr} from "./pages";
import {DynamicFormComponent} from "./widgest/dynamic-form/dynamic-form.component";

import {pipe} from  './widgest/index.pipe';
import {SharedModule} from "../shared/shared.module";

@NgModule({
    imports: [
        WidgetModule,
        SharedModule
    ],
    declarations: [
        ...pipe,
        ...kfqaPages_Arr,
        DynamicFormComponent,
    ],
    providers: [
        VipManagerService, qualityService, BigcustomerService
    ],
})
export class kfqaModule {
}
