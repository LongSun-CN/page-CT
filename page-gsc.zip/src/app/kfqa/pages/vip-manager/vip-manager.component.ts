import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {VipManagerService} from  "../../services/vip-manager.service";
import  {VipManagerSearch} from "../../entity/vipmanager.search";
import {Subscription} from "rxjs/Subscription";
import {Store} from "@ngrx/store";
import {VipManagerState} from "../../reducer/vip-manager.reducer";
import {ModalDirective} from "ngx-bootstrap";
import {UiselectAutoService} from "../../../widgets/ui-select-auto/ui-select-auto.service";
import {ToastService} from "../../../shared/services/toast.service";
import {OurpalmFormComponent} from "ngx-ourpalm-form";
import {environment} from "../../../../environments/environment";
import {HttpService} from "../../../shared/services/httpx.service";
import {OurpalmLoadingService} from "../../../widgets/ourpalm-loading/ourpalm-loading.service";
import {UserService} from "../../../widgets/user-box/user.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {Observable} from "rxjs/Observable";
import {Router} from "../../../router/router";


declare const $: any;
@Component({
  selector: 'app-vip-manager',
  templateUrl: './vip-manager.component.html',
  styleUrls: ['./vip-manager.component.css']
})
export class VipManagerComponent implements OnInit, OnDestroy,OnSearchBtnWorking {


  search: VipManagerSearch = initSearch;
  add: any = {
    submitTime: '',
    certifiedTime: '',
    log: []
  };
  isModify: Boolean = true;
  table: OurpalmTable;
  tableLog: OurpalmTable;
  $tableSubscription: Subscription;
  $VipManagerState:Observable<VipManagerState>;
  @ViewChild('addModal')
  public vipdetailModal: ModalDirective;

  @ViewChild('importModal')
  public importModal: ModalDirective;

  @ViewChild(OurpalmFormComponent)
  public importForm: OurpalmFormComponent;



  constructor(private service: VipManagerService, private  $store: Store<any>,private userService:UserService,
              private uiselectServicce: UiselectAutoService, private  toastService: ToastService,
              private route: Router,
              private httpService: HttpService,private loadingService: OurpalmLoadingService) {
    this.table = new OurpalmTable({
      cacheKey: 'kfqa-vipmanager-main',
      cacheColumns: true,
      cachePageSize: true,
      autoLoadData: false,
      pagePosition: 'bottom',
      defaultPageSize: 100,
      pageList: [100, 200],
      showRefreshBtn: false,
      showSettingBtn: false,
      fixTop: true,
      distanceTop: 50,
      onDbClickRow: (rowIndex, rowData) => {
          this.open(rowData);
      },
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        this.searchCommition();
      }
    });

    this.tableLog = new OurpalmTable({
      cacheKey: 'kfqa-vipmanager-log',
      cacheColumns: true,
      cachePageSize: true,
      autoLoadData: false,
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {

      }
    });

    this.$VipManagerState = this.$store.select('vipManager');


  }

  ngOnInit() {

  }




  searchCommition() {
    if (!this.search.product.id) {
      return this.toastService.translate('warning', '请选择产品！');
    }
    this.service.queryAllSignatureUserPage(this.search, this.table.getOptions());
  }



  onSelectSearchItem(param: CustomQueryParam) {
    let params = JSON.parse(param.query);
    this.search = {...params, _product: params.product};
    this.searchCommition();
  }

  onSearch() {
    this.searchCommition();
  }

  onSearchAdding(): StringOrResolver {
    return JSON.stringify(this.search);
  }

  onResumeSearchItem(param: CustomQueryParam) {
      this.onResumeSearchNothing();
      this.onSelectSearchItem(param);

  }

  onResumeSearchNothing() {
    this.$tableSubscription = Observable.combineLatest(this.route.params,this.$VipManagerState, (params: any, state: VipManagerState)=>[params,state])
               .subscribe(([param,result])=>{
                     if (result && !result.isInit) {
                       this.table.setPageData(result.data);//表格数据
                       let params = JSON.parse(result.search);
                       this.search = {...params, _product: params.product};
                     }
               })



  }


  open($row) {
    this.add = $row;
    this.add = $.extend({}, $row, true);
    this.add.newServer = {selected: {name: this.add.newServer, value: this.add.newServerId}};
    this.add.oldServer = {selected: {name: this.add.oldServer, value: this.add.oldServerId}};

    this.add.newOperationName = {selected: {name: this.add.newOperationName, value: this.add.newOperationId}};
    this.add.oldOperationName = {selected: {name: this.add.oldOperationName, value: this.add.oldOperationId}};

    this.uiselectServicce.doqueryAcordsProduct(this.add.productId, 'vipmanageradd','1,2');

    !this.add.log && (this.add.log = []);
    this.tableLog.setPageData({
      currentPage: 1,
      pageSize: this.add.log.length,
      total: this.add.log.length,
      rows: this.add.log,
    });
    this.isModify = true;
    this.vipdetailModal.show();
  }


  exportSignatureUserInfo() {
    var param = $.extend({}, this.search);
    param.productName = param.product && param.product.text;
    param.productId = param.product && param.product.id;
    param.server = param.server && param.server.id;
    param.columns = JSON.stringify(this.getExportColumns());
    if (param.contactWay && param.contactWay.selectValue == '0') {
      param.mobile = param.contactWay.value;
    } else if (param.contactWay && param.contactWay.selectValue == '1') {
      param.qq = param.contactWay.value;
    }
    if (!param.productId) {
      return this.toastService.translate('warning', '请选择产品！');
    }
    this.service.exportSignatureUserInfo(param);
  }

  getExportColumns(): any {
    let columns = this.table.getDisplayedColumns().map((column) => {
      return {
        columnView: column.header,
        columnName: column.field
      }
    });
    return columns;
  }

  downLoadTemplate() {
    this.service.downLoadTemplate();
  }

  importGameCode() {
    this.loadingService.show();
    this.importModal.hide();
    this.importForm.ajaxSubmit({
      url: environment.getUrl('customService/signatureUser/importExcelData.htm'),
      xhrFields: {
        withCredentials: true //跨域发送cookie, 异步提交表单时使用XHR2.0
      },
      headers: this.httpService.getHeaders(),
      success: (result) => {
        console.info(result);
        this.loadingService.hide();
        result = (typeof result === 'string') ? JSON.parse(result) : result;
        if (result.status == '0') {
          this.toastService.translate('error', '添加成功');
          //this.searchCommition();
        } else {
          this.toastService.translate('error', result.desc);
        }
      },
      error: (result) => {
        this.loadingService.hide();
        console.info(result);
      }
    })
  }

  addCommition() {
    const param = $.extend({}, this.add, true);
    param.newServerId = param.newServer && param.newServer.selected && param.newServer.selected.value;
    param.newServer = param.newServer && param.newServer.selected && param.newServer.selected.name;
    param.oldServerId = param.oldServer && param.oldServer.selected && param.oldServer.selected.value;
    param.oldServer = param.oldServer && param.oldServer.selected && param.oldServer.selected.name;


    param.newOperationId = param.newOperationName && param.newOperationName.selected && param.newOperationName.selected.value;
    param.newOperationName = param.newOperationName && param.newOperationName.selected && param.newOperationName.selected.name;
    param.oldOperationId = param.oldOperationName && param.oldOperationName.selected && param.oldOperationName.selected.value;
    param.oldOperationName = param.oldOperationName && param.oldOperationName.selected && param.oldOperationName.selected.name;


    this.service.updateIdentityStatus(param).then((result) => {
      if (result.status == '0') {
        this.vipdetailModal.hide();
        this.add = {};
        this.searchCommition();
      }
    });
  }


  ngOnDestroy() {
    this.$tableSubscription.unsubscribe();
  }
}


const initSearch = {
  product: {id: '', text: ''},
  server: {id: '', text: ''},
  certificationStatus: '',
  prerogativeLevel: '',
  roleName: '',
  roleId: '',
  certifiedTime: '',
  submitTime: '',
  contactWay: '1',
  mobile: '',
  qq: '',
};
