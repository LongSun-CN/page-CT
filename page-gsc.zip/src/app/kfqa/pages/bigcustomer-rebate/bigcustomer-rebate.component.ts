import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {KefuService} from "../../../widgets/ourpalm-autocomplete/ourpalm-kefucomplete.server";
import {Store} from "@ngrx/store";
import {BigcustomerIdentyState} from "../../reducer/bigcustomer.identy.reducer";
import {LanProTypeService} from "../../../widgets/language-producttype/language-producttype.service";
import {TranslateService} from "@ngx-translate/core";
import {BigcustomerService} from "../../services/bigCustomer.service";
import {ToastService} from "../../../shared/services/toast.service";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {Subscription} from "rxjs/Subscription";
import {BigcustomerRebateState} from "../../reducer/bigcustomer.rebate.reducer";
import {ModalDirective} from "ngx-bootstrap";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {Observable} from "rxjs/Observable";
import {Router} from "../../../router/router";

@Component({
  selector: 'app-bigcustomer-rebate',
  templateUrl: './bigcustomer-rebate.component.html',
  styleUrls: ['./bigcustomer-rebate.component.css']
})
export class BigcustomerRebateComponent implements OnInit, OnDestroy ,OnSearchBtnWorking{

  search: any;
  tool: any;
  standard: any;
  reason: string;

  table: OurpalmTable;
  $tableSubscription: Subscription;
  translations: any;
  standardErroMap: any;

  @ViewChild('toolModal')
  toolModal: ModalDirective;
  @ViewChild('standardModal')
  standardModal: ModalDirective;
  @ViewChild('notPassModal')
  notPassModal: ModalDirective;
  @ViewChild('surePassModal')
  surePassModal: ModalDirective;
  @ViewChild('rebateAddTooModal')
  rebateAddTooModal: ModalDirective;
  $BigcustomerRebateState:Observable<BigcustomerRebateState>;

  rebateUpdate: any;


  constructor(private  kefu: KefuService,
              private route:Router,
              private store: Store<BigcustomerIdentyState>,
              private lanType: LanProTypeService, private  translate: TranslateService,
              private service: BigcustomerService, private toast: ToastService) {
    this.translate.get(['道具输入不能为空', '请选择', '产品不能为空', '商城货币不能为空', '商城货币价值不能为空', '单日返利存在为空的字段', '多日返利存在为空的字段']).subscribe(res => {
      this.translations = res;
      this.standardErroMap = {
        product: res['产品不能为空'],
        currency: res['商城货币不能为空'],
        currencyValue: res['商城货币价值不能为空'],
      }

    });

  }

  ngOnInit() {
    this.search = {
      autocompleteService: this.kefu.getAdminautocomplete(),
    };
    this.tool = {};
    this.standard = {};
    this.table = new OurpalmTable({
      cacheKey: "bigcustomerRebate-main",
      autoLoadData: false,
      pagePosition: 'bottom',
      defaultPageSize: 100,
      pageList: [100, 200],
      showRefreshBtn: false,
      showSettingBtn: false,
      fixTop: true,
      distanceTop: 50,
      onDbClickRow:(index,row)=>{
         this.gotoRebate(row);
      },
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        this.searchCommition();
      }
    });
    this.$BigcustomerRebateState = this.store.select('bigRebate');

  }

  searchCommition() {
    this.service.queryRebatePage(this.search, this.table.getOptions());
  }




  onSelectSearchItem(param: CustomQueryParam) {
    let params = JSON.parse(param.query);
    this.search = {...params,_product:params.product};
    this.searchCommition();
  }

  onSearch() {
    this.searchCommition();
  }

  onSearchAdding(): StringOrResolver {
    return JSON.stringify(this.search);
  }

  onResumeSearchItem(param: CustomQueryParam) {
    this.onResumeSearchNothing();
    this.onSelectSearchItem(param);

  }

  onResumeSearchNothing() {
    this.$tableSubscription = Observable.combineLatest(this.route.params,this.$BigcustomerRebateState, (params: any, state: BigcustomerRebateState)=>[params,state])
      .subscribe(([param,result])=>{
        if (result && !result.isInit) {
          this.table.setPageData(result.data);//表格数据
          let params = JSON.parse(result.search);
          this.search = {...params, _product: params.product};
        }
      })

  }




  openAddToolDialog() {
    this.tool = {
      product: {...(this.search.product || {id: '-1', text: this.translations['请选择']})},
      _product: {...(this.search.product || {id: '-1', text: this.translations['请选择']})},
      list: [{id: '', itemId: '', vipLevelName: '', VIPLevel: ''}],
      isModify: true,
      currency: '?'
    };
    this.toolModal.show();
    if (this.tool.product && this.tool.product.id) {
      this.queryGamePropList();
    }
  }


  queryGamePropList(product = this.tool.product) {
    if (!product.id || product.id === '-1')return false;
    var param = {
      productId: product.id,
      localId: this.lanType.getCurrentLanguage().value,
    };
    this.service.queryGamePropList(param).then((result) => {
      if (result.status == '0') {
        this.tool.list = [];
        result.data.currency && (this.tool.currency = result.data.currency);

        result.data && result.data.itemInfo && (result.data.itemInfo.forEach((item) => {
          this.tool.list.push({
            id: item.id,
            itemId: item.itemId,
            itemName: item.itemName,
            itemValue: item.itemValue
          });
        }));
        if (this.tool.list.length == 0) {
          this.tool.list = [{id: '', itemId: '', itemName: '', itemValue: ''}];
        }
      } else {
        this.toast.pop('warning', result.desc);
      }
    });
  }


  minusExtraTool = function (index) {
    if (this.tool.list.length == 1) {
      this.tool.list = [{id: '', itemId: '', itemName: '', itemValue: ''}];
    } else {
      this.tool.list.splice(index, 1);
    }
  };
  addExtraTool = function () {
    this.tool.list.push({id: '', itemId: '', itemName: '', itemValue: ''});
  };


  addExtraToolCommition() {
    this.tool.productId = this.tool.product.id;
    this.tool.localId = this.lanType.getCurrentLanguage().value;
    let hasEmpty = false;
    this.tool.list.forEach((item) => {
      for (let prop in item) {
        if (prop != 'id' && !item[prop]) {
          hasEmpty = true;
          return this.toast.translate('warning', this.translations['道具输入不能为空']);
        }
      }
    });
    if (hasEmpty) {
      return false;
    }
    this.tool.itemInfo = JSON.stringify(this.tool.list);
    this.service.modifyGamePropList(this.tool).then((result) => {
      if (result.status == '0') {

        this.toolModal.hide();
      } else {
        this.toast.pop('warning', result.desc);
      }
    });
  }


  openAddStantdardDialog() {
    this.standard = {
      product: {...this.search.product || {id: '-1', text: this.translations['请选择']}},
      _product: {...this.search.product || {id: '-1', text: this.translations['请选择']}},
      isModify: true,
      rechargeWay: '1',
      mult: false,
      sigle: false,
      multiRebate: [{
        id: '',
        lowerBounds: '',
        upperBounds: '',
        rebateRatio: ''
      }],
      singleRebate: [{
        id: '',
        lowerBounds: '',
        upperBounds: '',
        rebateRatio: ''
      }]
    };
    this.standardModal.show();
    if (this.search.product && this.search.product.id && this.search.product.id !== '-1') {
      this.getRebateRuleList(this.search.product);
    }
  }

  getRebateRuleList(product: { id: string, text: string }) {
    if (!product || !product.id || !this.standard.rechargeWay)return;
    const param = {
      productId: product.id,
      localId: this.lanType.getCurrentLanguage().value,
      rechargeWay: this.standard.rechargeWay
    };
    this.service.getRebateRuleList(param).then((result) => {
      if (result.status == '0') {
        this.standard.currency = result.data.currency;
        this.standard.currencyValue = result.data.currencyValue;
        this.standard.currencyId = result.data.currencyId;
        this.standard.localId = this.lanType.getCurrentLanguage().value;
        this.standard.singleRebate = [], this.standard.multiRebate = [];
        result.data.singleRebate.forEach((item) => {
          this.standard.singleRebate.push({
            id: item.id,
            lowerBounds: item.lowerBounds,
            upperBounds: item.upperBounds,
            rebateRatio: item.rebateRatio
          })
        });
        result.data.multiRebate.forEach((item) => {
          this.standard.multiRebate.push({
            id: item.id,
            lowerBounds: item.lowerBounds,
            upperBounds: item.upperBounds,
            rebateRatio: item.rebateRatio
          })
        });
        if (result.data.singleRebate.length == 0) {
          this.standard.multiRebate = [{
            id: '',
            lowerBounds: '',
            upperBounds: '',
            rebateRatio: ''
          }];
          this.standard.mult = false;
        } else {
          this.standard.mult = true;
        }
        if (result.data.singleRebate.length == 0) {
          this.standard.singleRebate = [{
            id: '',
            lowerBounds: '',
            upperBounds: '',
            rebateRatio: ''
          }];
          this.standard.sigle = false;
        } else {
          this.standard.sigle = true;
        }
      } else {
        this.toast.pop('warning', result.desc);
      }
    });
  }


  selectStandardSwitch(type: number) {
    if (type) {
      !this.standard.mult && (this.standard.multiRebate = [{
        id: '',
        lowerBounds: '',
        upperBounds: '',
        rebateRatio: ''
      }]);
    } else {
      !this.standard.sigle && (this.standard.singleRebate = [{
        id: '',
        lowerBounds: '',
        upperBounds: '',
        rebateRatio: ''
      }])
    }
  }

  minusStandard(index: number, type?: number) {
    if (!type && this.standard.singleRebate.length == 1) {
      this.standard.singleRebate = [{
        id: '',
        lowerBounds: '',
        upperBounds: '',
        rebateRatio: ''
      }];
    } else if (!type) {
      this.standard.singleRebate.splice(index, 1);
    }
    if (type && this.standard.multiRebate.length == 1) {
      this.standard.multiRebate = [{
        id: '',
        lowerBounds: '',
        upperBounds: '',
        rebateRatio: ''
      }];
    } else if (type) {
      this.standard.multiRebate.splice(index, 1);
    }
  }

  addStandard(type?: number) {
    !type && this.standard.singleRebate.push({
      id: '',
      lowerBounds: '',
      upperBounds: '',
      rebateRatio: ''
    });
    type && this.standard.multiRebate.push({
      id: '',
      lowerBounds: '',
      upperBounds: '',
      rebateRatio: ''
    });
  }

  AddStantdardCommit() {
    //字段不为空判断开始
    for (const prop in this.standardErroMap) {
      if (!this.standard[prop]) {
        return this.toast.pop('warning', this.standardErroMap[prop]);
      }
    }
    let isEmpty = false;
    if (this.standard.sigle) {
      this.standard.singleRebate.forEach((itemsig) => {
        for (var prop in itemsig) {
          if (prop != 'id' && !itemsig[prop] && itemsig[prop] != "0") {
            isEmpty = true;
          }
        }
      });
      if (isEmpty) {
        return this.toast.pop('warning', this.translations['单日返利存在为空的字段']);
      }
    } else {
      this.standard.singleRebate = [];
    }
    if (this.standard.mult) {
      this.standard.multiRebate.forEach((itemsig) => {
        for (var prop in itemsig) {
          if (prop != 'id' && !itemsig[prop] && itemsig[prop] != "0") {
            isEmpty = true;
          }
        }
      });
      if (isEmpty) {
        return this.toast.pop('warning', this.translations['多日返利存在为空的字段']);
      }
    } else {
      this.standard.multiRebate = [];
    }
    //字段不为空判断结束

    //判断是否连续
    if (!this.service.isNoGap(this.standard.singleRebate, 'lowerBounds', 'upperBounds') || !this.service.isNoGap(this.standard.multiRebate, 'lowerBounds', 'upperBounds')) {
      return this.toast.translate('warning', '返利区间存在不连续');
    }
    let _param = {
      singleRebate: JSON.stringify(this.standard.singleRebate),
      multiRebate: JSON.stringify(this.standard.multiRebate),
      productId: this.standard.product.id
    };
    this.service.modifyRebateRule({...this.standard, ..._param}).then((result) => {
      console.log(result);
      if (result.status == '0') {
        this.standardModal.hide();
      } else {
        this.toast.pop('warning', result.desc);
      }
    });
  }


  notPass() {
    let flag = true;
    this.table.getSelectedRows().forEach((row) => {
      if (row.status != '02') {
        flag = false;
        return this.toast.translate('warning', '选择数据中包含不是待审核数据');//opToast.info('')
      }
    });
    if (flag) this.notPassModal.show();
  }

  precheckRebate() {
    let flag = true;
    this.table.getSelectedRows().forEach((row) => {
      if (row.status != '01') {
        flag = false;
        return this.toast.pop('warning', '选择数据中包含不是待审核数据');//opToast.info('')
      }
    });
    if (flag) this.surePassModal.show();
  }

  checkRebate(type: number) {
    if (this.table.getSelectedRows().length < 1) {
      return this.toast.translate('warning', type < 2 ? '请选择待审核数据' : '请选择待返利数据');
    }
    let flag = true, ids = [];

    this.table.getSelectedRows().forEach((row) => {
      ids.push(row.id);
      if (type < 2 && row.status != '02') {
        flag = false;
        return this.toast.translate('warning', '选择数据中包含不是待审核数据')
      }
      if (type >= 2 && row.status != '01') {
        flag = false;
        return this.toast.translate('warning', '选择数据中包含不是待返利数据');
      }
    });
    let param = {
      status: type == 0 ? '03' : (type == 1 ? '01' : (type == 2 ? '99' : '04')),
      ids: ids.join(','),
      content: type == 0 ? this.reason : '',
      cancel: false
    };
    if (type == 3) {
      param.cancel = true;
    }


    if (flag) {//数据选择符合条件
      this.service.changeRebateStatus(param).then((result) => {
        if (result.status == '0') {
          this.toast.pop('success', result.desc);
          if (type == 0) {
            this.notPassModal.hide();
          }
          if (type == 3) {
            this.surePassModal.hide();
          }
          this.searchCommition();
        } else {
          this.toast.pop('warning', result.desc);
        }
      });
    }
  }


  gotoRebate(row: any) {
    this.rebateUpdate = {...row, ...{isModify: true}};
    this.rebateAddTooModal.show();
  }

  addRebateDone() {
    this.rebateAddTooModal.hide();
    this.searchCommition();
  }


  getExportColumns(): any[] {
    var columns = [];
    this.table.getDisplayedColumns().forEach(function (column) {
      if (column.header && column.field) {
        columns.push({
          columnView: column.header,
          columnName: column.field
        });
      }
    });
    return columns;
  }

  exportRebate() {
    let param = {
      localeId: this.lanType.getCurrentLanguage().value,
      productId: (this.search.product && this.search.product.id) ? this.search.product.id : '',
      serverId: (this.search.server && this.search.server.id) ? this.search.server.id : '',
      operaId: (this.search.channel && this.search.channel.id) ? this.search.channel.id : '',
      createUser: this.search.createUser && this.search.createUser.accountId,
      createTime: `${(this.search.createTime && this.search.createTime.start) || ''}${(this.search.createTime && this.search.createTime.end && (' - ' + this.search.createTime.end) || '')}`,
      columns: JSON.stringify(this.getExportColumns())
    };
    param = Object.assign({...this.search, ...param});
    this.service.exportRebate(param);
  }

  ngOnDestroy() {
    this.$tableSubscription.unsubscribe();
  }


}
