import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {BigcustomerService} from "../../services/bigCustomer.service";
import {Subscription} from "rxjs/Subscription";
import {Store} from "@ngrx/store";
import {BigcustomerSearchState} from "../../reducer/bigcustomer.search.reducer";
import {ModalDirective} from "ngx-bootstrap";
import {ToastService} from "../../../shared/services/toast.service";
import {vipState} from "../../../widgets/ui-select-auto/ui-select-auto.reducer";
import {TranslateService} from "@ngx-translate/core";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {Observable} from "rxjs/Observable";
import {LanProTypeService} from "../../../widgets/language-producttype/language-producttype.service";
import {Router} from "../../../router/router";

@Component({
  selector: 'app-bigcustomer-search',
  templateUrl: './bigcustomer-search.component.html',
  styleUrls: ['./bigcustomer-search.component.css']
})
export class BigcustomerSearchComponent implements OnInit, OnDestroy,OnSearchBtnWorking {

  search: any;
  add: any;
  vip: any;
  table: OurpalmTable;
  tableLog: OurpalmTable;
  $tableSubscription: Subscription;
  $vipListSubscription: Subscription;
  $BigcustomerSearchState:Observable<BigcustomerSearchState>;
  translations: any;

  @ViewChild('addModal')
  addModal: ModalDirective;
  @ViewChild('addVipModal')
  addVipModal: ModalDirective;
  @ViewChild('rebateAdd')
  rebateAdd: ModalDirective;
  rebateUpdate: any;


  constructor(private  service: BigcustomerService,
              private lanType: LanProTypeService,
              private  translate: TranslateService,
              private route: Router,
              private $store: Store<BigcustomerSearchState>,
              private toast: ToastService) {

    this.table = new OurpalmTable({
      cacheKey: "bigcustomerSearch-main",
      autoLoadData: false,
      pagePosition: 'bottom',
      defaultPageSize: 100,
      pageList: [100, 200],
      showRefreshBtn: false,
      showSettingBtn: false,
      fixTop: true,
      distanceTop: 50,
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        this.searchCommition();
      }
    });

    this.tableLog = new OurpalmTable({
      cacheKey: "bigcustomerSearch-log",
      autoLoadData: true,
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        callback({
          total: this.add.logs.length || 0,
          rows: this.add.logs || []
        });
      }
    });

    this.translate.get(['请选择']).subscribe(res => {
      this.translations = res;
    });

  }

  ngOnInit() {


    this.search = {
      product: '',
      channel: '',
      server: '',
      vipLevel: '',
      roleName: '',
      roleId: ''
    };

    this.add = {
      isModify: false,
      product: '',
      channel: '',
      server: '',
      vipLevel: '',
      userId: '',
      roleId: '',
      roleName: '',
      lastLoginTime: '',
      last30Income: '',
      qq: '',
      currentLogicServerId: '',
      currentLogicServerName: '',
      email: '',
      name: '',
      birthday: '',
      phoneNumber: '',
      phoneNumber2: '',
      address: '',
      desc: '',
      certifyStatus: '',
      extras: [{channel: '', server: '', roleId: ''}],
      logs: []
    };

    this.vip = {
      product: '',
      list: [],
      isModify: true
    };

    this.$BigcustomerSearchState = this.$store.select('bigSearch');


    this.$vipListSubscription = this.$store.select('vipAuto')
      .map((res: vipState[]) => {
        res = res&&res.filter(item => {
          return item.key === 'vipEdit';
        });
        return res;
      })
      .subscribe((result: vipState[]) => {
        this.vip.list = (result&&result[0] && result[0].data) || [];
        let vip_list = [];
        this.vip.list.forEach(item => {
          if (item.id !== '-1') {
            vip_list.push({vipLevelValue: item.id, vipLevelName: item.text});
          }
        });
        this.vip.list = vip_list;
        if (!this.vip.list[0]) {
          this.vip.list = [{id: '', vipLevelName: '', vipLevelValue: ''}];
        }
      })
  }

  searchCommition() {
    this.service.queryAllBigCustomerPage( this.search, this.table.getOptions())
  }


  onSelectSearchItem(param: CustomQueryParam) {
    let params = JSON.parse(param.query);
    this.search = {...params,_product:params.product};
    this.searchCommition();
  }

  onSearch() {
    this.searchCommition();
  }

  onSearchAdding(): StringOrResolver {
    return JSON.stringify(this.search);
  }

  onResumeSearchItem(param: CustomQueryParam) {
    this.onResumeSearchNothing();
    this.onSelectSearchItem(param);

  }

  onResumeSearchNothing() {
    this.$tableSubscription = Observable.combineLatest(this.route.params,this.$BigcustomerSearchState, (params: any, state: BigcustomerSearchState)=>[params,state])
      .subscribe(([param,result])=>{
        if (result && !result.isInit) {
          this.table.setPageData(result.data);//表格数据
          let params = JSON.parse(result.search);
          this.search = {...params, _product: params.product};
        }
      })

  }



  modifyOpen(item) {
    this.addModal.show();
    this.add = Object.assign(this.add, item);
    this.add.product = {id: this.add.productId, text: this.add.productName};
    this.add._product = {id: this.add.productId, text: this.add.productName};
    this.add.channel = {id: this.add.operationLine, text: this.add.operationLineName};
    this.add.server = {id: this.add.logicServerId, text: this.add.logicServerName};
    this.add.vipLevel = {id: this.add.VIPLevel, text: this.add.vipLevelName};

    console.log(this.add);
    if (item.certifyStatus === '1') {
      this.service.getIdentityBigCustomerInfo({customerId: this.add.id}).then(res => {
        if (res.status === '0') {
          this.add.extras = [];
          res.data.relateUser.forEach(item => {
            this.add.extras.push({
              "channel": {text: item.operationLineName, id: item.operationLine},
              "server": {text: item.logicServerName, id: item.logicServerId},
              "roleId": item.roleId,
              id: item.id
            });
          });
          this.add.logs = res.data.log;
          this.tableLog.firstPage();
        }
      })
    }
  }


  addExtra() {
    this.add.extras.push({channel: '', server: '', roleId: ''});
  }

  minusExtra(index) {
    if (this.add.extras.length == 1) {
      this.add.extras = [{channel: {selected: undefined}, server: {selected: undefined}, roleId: ''}];
    } else {
      this.add.extras.splice(index, 1);
    }
  }

  addCommition() {
    console.log(this.add);
    let relateUser = [], extrasEmpty: boolean = false;
    this.add.extras.forEach(item => {
      if (!item.roleId || !item.channel || !item.channel.id || !item.server || !item.server.id) {
        extrasEmpty = true;
      }
      if (!item.roleId && (!item.channel || !item.channel.id) && (!item.server || !item.server.id)) {
        extrasEmpty = false;
      } else {
        relateUser.push({
          "operationLine": item.channel && item.channel.id,
          "logicServerId": item.server && item.server.id,
          "roleId": item.roleId,
          "roleName": "",
          "userId": this.add.userId,
          "flag": "add"
        });
      }
      if (extrasEmpty) {
        return false;
      }
    });
    if (extrasEmpty) this.toast.translate('warning', '关联小号不能有空字段');
    this.add.relateUser = JSON.stringify(relateUser);
    this.add.id += "";

    //对小号参数做处理 end
    this.service.addIdentityBigCustomer(this.add).then(result => {
      if (result.status == '0') {
        this.addModal.hide();
        this.searchCommition();
        this.add.extras = [];
      } else {
        this.toast.pop('warnig', result.desc);
      }
    })
  }

  updateCommition() {
    console.log(this.add);
    let relateUser = [], extrasEmpty: boolean = false;
    this.add.extras.forEach(item => {
      if (!item.roleId || !item.channel || !item.channel.id || !item.server || !item.server.id) {
        extrasEmpty = true;
      }
      if (!item.roleId && (!item.channel || !item.channel.id) && (!item.server || !item.server.id)) {
        extrasEmpty = false;
      } else {
        relateUser.push({
          "operationLine": item.channel && item.channel.id,
          "logicServerId": item.server && item.server.id,
          "roleId": item.roleId,
          "roleName": "",
          "userId": this.add.userId,
          "flag": "add"
        });
      }
      if (extrasEmpty) {
        return false;
      }
    });
    if (extrasEmpty) this.toast.translate('warnig', '关联小号不能有空字段');
    this.add.relateUser = JSON.stringify(relateUser);
    this.add.id += "";

    //对小号参数做处理 end
    this.service.updateIdentityBigCustomer(this.add).then(result => {
      if (result.status == '0') {
        this.addModal.hide();
        this.searchCommition();
        this.add.extras = [];
      } else {
        this.toast.pop('warnig', result.desc);
      }
    })
  }

  openVipDialog() {
    this.vip.product = Object.assign({}, this.search.product || {id: '-1', text: this.translations['请选择']});
    this.vip._product = Object.assign({}, this.search.product || {id: '-1', text: this.translations['请选择']});
    this.vip.isModify = true;

    this.addVipModal.show();
  };

  getVipLevel(product: any = this.vip.product) {
    this.service.getVipLevel({
      productId: product.id,
      localId: this.lanType.getCurrentLanguage().value
    }).then((result) => {
      if (result.status == '0') {
        this.vip.list = [];
        let _arr = ( result.data && result.data.vipInfoBean) || [];
        _arr.forEach((item) => {
          this.vip.list.push({
            id: item.id,
            vipLevelName: item.vipLevelName,
            vipLevelValue: item.vipLevelValue
          });
        });

      } else {
        this.toast.pop('warning', result.desc);
      }
    });
  }


  minusExtraVip(index) {
    if (this.vip.list.length == 1) {
      this.vip.list = [{id: '', vipLevelName: '', vipLevelValue: ''}];
    } else {
      this.vip.list.splice(index, 1);
    }
  };

  addExtraVip() {
    this.vip.list.push({id: '', vipLevelName: '', vipLevelValue: ''});
  };

  addVipCommition() {
    const param = {
      localId: this.lanType.getCurrentLanguage().value,
      productId: (this.vip.product && this.vip.product.id) ? this.vip.product.id : '',
      itemInfo: JSON.stringify(this.vip.list)
    };
    this.service.modifyVipInfo(param).then(result => {
      if (result.status === '0') {
        this.vip.list = [{id: '', vipLevelName: '', vipLevelValue: ''}];
        this.addVipModal.hide();
      } else {
        this.toast.pop('warning', result.desc);
      }
    });
  }


  exportAllBigCustomer() {
    let param = {
      localeId: this.lanType.getCurrentLanguage().value,
      productId: (this.search.product && this.search.product.id) ? this.search.product.id : '',
      server: (this.search.server && this.search.server.value) ? this.search.server.value : '',
      operationLineId: (this.search.channel && this.search.channel.id) ? this.search.channel.id : '',
      vipLevelValue: (this.search.vipLevel && this.search.vipLevel.id) ? this.search.vipLevel.id : '',
      columns: JSON.stringify(this.getExportColumns())
    };
    if (!param.productId || '-1' === param.productId) {
      return this.toast.translate('warning', '请选择产品');
    }
    param = Object.assign({}, this.search, param);
    this.service.exportAllBigCustomer(param);

  }

  getExportColumns = function () {
    let columns = [];
    this.table.getDisplayedColumns().forEach((column) => {
      if (column.header && column.field) {
        columns.push({
          columnView: column.header,
          columnName: column.field
        });
      }
    });
    return columns;
  };

  gotoRebate(row: any) {
    this.rebateUpdate = {...row, ...{isModify: false}};
    this.rebateAdd.show();
  }

  addRebateDone() {
    this.rebateAdd.hide();
  }

  ngOnDestroy() {
    this.$tableSubscription.unsubscribe();
    this.$vipListSubscription.unsubscribe();
  }
}
