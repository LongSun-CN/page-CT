import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {KefuService} from  '../../../widgets/ourpalm-autocomplete/ourpalm-kefucomplete.server';
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {Subscription} from "rxjs/Subscription";
import {Store} from "@ngrx/store";
import {BigcustomerIdentyState} from "../../reducer/bigcustomer.identy.reducer";
import {BigcustomerService} from "../../services/bigCustomer.service";
import {ModalDirective} from "ngx-bootstrap";
import {ToastService} from "../../../shared/services/toast.service";
import {LanProTypeService} from "../../../widgets/language-producttype/language-producttype.service";
import {TranslateService} from "@ngx-translate/core";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {Observable} from "rxjs/Observable";
import {Router} from "../../../router/router";

@Component({
  selector: 'app-bigcustumer-identy',
  templateUrl: './bigcustumer-identy.component.html',
  styleUrls: ['./bigcustumer-identy.component.css']
})
export class BigcustumerIdentyComponent implements OnInit,OnDestroy,OnSearchBtnWorking {

  search: any;
  edit: any;
  add: any;
  server: any;
  table: OurpalmTable;
  tableLog: OurpalmTable;
  tableSubscription: Subscription;
  @ViewChild('editModal')
  editModal: ModalDirective;
  @ViewChild('addModal')
  addModal: ModalDirective;
  @ViewChild('updateServerModal')
  updateServerModal: ModalDirective;
  @ViewChild('rebateAdd')
  rebateAdd: ModalDirective;
  translations: any;

  rebateUpdate:any;
  $BigcustomerIdentyState:Observable<BigcustomerIdentyState>;


  constructor(private  kefu: KefuService, private store: Store<BigcustomerIdentyState>,
              private route: Router,
              private lanType: LanProTypeService, private  translate: TranslateService,
              private service: BigcustomerService, private toast: ToastService) {
    this.translate.get(['大掌门']).subscribe(res => {
      this.translations = res;
    });

  }

  ngOnInit() {
    this.search = {
      product: '',
      channel: '',
      server: '',
      roleName: '',
      roleId: '',
      certifiedTime: '',
      autocompleteService: this.kefu.getAdminautocomplete(),
      submitter: '',
      qq: '',
      birthday: '',
      email: '',
      phoneNumber: '',

    };
    this.edit = {
      logs: [],
      // product:'',
      // channel:'',
      // server:'',
      // vipLevel:'',
      // userId:'',
      // roleId:'',
      // roleName:'',
      // lastLoginTime:'',
      // last30Income:'',
      // qq:'',
      // currentLogicServerId:'',
      // currentLogicServerName:'',
      // email:'',
      // channel:'',
      // channel:'',
      // channel:'',
      // channel:'',
      // channel:'',
      //

    };
    this.add = {
      logs: [],
    };
    this.server = {};
    this.table = new OurpalmTable({
      cacheKey: "bigcustomerIdenty-main",
      autoLoadData: false,
      pagePosition: 'bottom',
      defaultPageSize: 100,
      pageList: [100, 200],
      showRefreshBtn: false,
      showSettingBtn: false,
      fixTop: true,
      distanceTop: 50,
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        this.searchCommition();
      }
    });

    this.tableLog = new OurpalmTable({
      cacheKey: "bigcustomerIdenty-log",
      autoLoadData: true,
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        callback({
          total: this.edit.logs.length || 0,
          rows: this.edit.logs || []
        });
      }
    });
    this.$BigcustomerIdentyState =  this.store.select('bigIdenty');

  }

  searchCommition() {
    this.service.queryIdentityBigCustomerPage(this.search, this.table.getOptions());
  }




  onSelectSearchItem(param: CustomQueryParam) {
    let params = JSON.parse(param.query);
    this.search = {...params,_product:params.product};
    this.searchCommition();
  }

  onSearch() {
    this.searchCommition();
  }

  onSearchAdding(): StringOrResolver {
    return JSON.stringify(this.search);
  }

  onResumeSearchItem(param: CustomQueryParam) {
    this.onResumeSearchNothing();
    this.onSelectSearchItem(param);

  }

  onResumeSearchNothing() {
    this.tableSubscription = Observable.combineLatest(this.route.params,this.$BigcustomerIdentyState, (params: any, state: BigcustomerIdentyState)=>[params,state])
      .subscribe(([param,result])=>{
        if (result && !result.isInit) {
          this.table.setPageData(result.data);//表格数据
          let params = JSON.parse(result.search);
          this.search = {...params,_product:params.product};
        }
      })
  }


  modifyOpen(row: any) {
    this.editModal.show();
    this.edit = Object.assign({}, row);
    this.edit.product = {id: this.edit.productId, text: this.edit.productName};
    this.edit._product = {id: this.edit.productId, text: this.edit.productName};
    this.edit.channel = {id: this.edit.operationLine, text: this.edit.operationLineName};
    this.edit.server = {id: this.edit.logicServerId, text: this.edit.logicServerName};
    this.edit.vipLevel = {id: this.edit.VIPLevel, text: this.edit.vipLevelName};
    this.edit.isModify = false;
    if (row.certifyStatus === '1') {
      this.service.getIdentityBigCustomerInfo({customerId: this.edit.id}).then(res => {
        if (res.status === '0') {
          this.edit.extras = [{  id: this.edit.id,channel: '', server: '', roleId: ''}];
          res.data.relateUser.forEach(item => {
            this.edit.extras.push({
              "channel": {text: item.operationLineName, id: item.operationLine},
              "server": {text: item.logicServerName, id: item.logicServerId},
              "roleId": item.roleId,
              id: item.id
            });
          });

          this.edit.logs = res.data.log;
          this.tableLog.firstPage();
        }
      })
    }

  }

  editminusExtra(index: number) {
    if (this.edit.extras.length == 1) {
      this.edit.extras = [{channel: {selected: undefined}, server: {selected: undefined}, roleId: ''}];
    } else {
      this.edit.extras.splice(index, 1);
    }
  }

  editaddExtra() {
    this.edit.extras.push({channel: '', server: '', roleId: ''});
  }


  editcommition() {
    console.log(this.edit);
    let relateUser = [], extrasEmpty: boolean = false;
    this.edit.extras.forEach(item => {
      if (!item.roleId || !item.channel || !item.channel.id || !item.server || !item.server.id) {
        extrasEmpty = true;
      }
      if (!item.roleId && (!item.channel || !item.channel.id) && (!item.server || !item.server.id)) {
        extrasEmpty = false;
      } else {
        relateUser.push({
          "operationLine": item.channel && item.channel.id,
          "logicServerId": item.server && item.server.id,
          "roleId": item.roleId,
          "roleName": "",
          "userId": this.edit.userId,
          "flag": "add"
        });
      }
      if (extrasEmpty) {
        return false;
      }
    });
    if (extrasEmpty) this.toast.translate('warnig', '关联小号不能有空字段');
    this.edit.relateUser = JSON.stringify(relateUser);
    this.edit.id += "";

    //对小号参数做处理 end
    this.service.updateIdentityBigCustomer(this.edit).then(result => {
      if (result.status == '0') {
        this.editModal.hide();
        this.searchCommition();
        this.edit.extras = [];
      } else {
        this.toast.pop('warnig', result.desc);
      }
    })
  }


  openAddDialog() {
    this.addModal.show();
    for (const prop in this.add) {
      this.add[prop] = '';
    }
    this.add.isModify = false;
    this.add = {};
    this.add.title = '';
    this.add.isModify = false;
    this.add.productName = this.translations['大掌门'];
    this.add.productId = '10001057';//{selected:{name:'大掌门',value:'10001057'}};
    this.add.channel = '';
    this.add.server = '';
    this.add.vipLevel = '';
    this.add.extras = [{channel: '', server: '', roleId: ''}];
  }

  minusExtra(index) {
    if (this.add.extras.length == 1) {
      this.add.extras = [{channel: '', server: '', roleId: ''}];
    } else {
      this.add.extras.splice(index, 1);
    }
  }

  addExtra() {
    this.add.extras.push({channel: '', server: '', roleId: ''});
  }

  addCommition() {
    const relateUser = [];
    //对小号参数做处理
    if (this.add.extras.length > 0 && this.add.extras[0].channel != '') {
      this.add.extras.forEach(function (item) {
        relateUser.push({
          "operationLine": item.channel,
          "logicServerId": item.server,
          "roleId": item.roleId,
          "roleName": "",
          "userId": this.add.userId,
          "flag": "add"
        });
      });
      this.add.relateUser = JSON.stringify(relateUser);
    }
    //对小号参数做处理 end

    this.add = Object.assign(this.add, {
      localeId: this.lanType.getCurrentLanguage().value,
    });

    if (!this.add.productName || !this.add.productName.trim()) {
      return this.toast.translate('warning', '产品不能为空');
    } else if (!this.add.roleId || !this.add.roleId.trim()) {
      return this.toast.translate('warning', '角色ID不能为空');
    } else if (!this.add.roleName || !this.add.roleName.trim()) {
      return this.toast.translate('warning', '角色名称不能为空');
    } else if (!this.add.qq || !this.add.qq.trim()) {
      return this.toast.translate('warning', 'qq不能为空');
    }

    this.service.addIdentityBigCustomer(this.add).then((result) => {
      console.log(result);
      if (result.status == '0') {
        this.add = {};
        this.addModal.hide();
        this.search.product = {text: '大掌门', id: '10001057'};
        this.search._product = {text: '大掌门', id: '10001057'};
        this.searchCommition();

      } else {
        this.toast.translate('warning', result.desc);
      }
    })

  }


  exportIdentityBigCustomer() {
    var param = {
      createUser: this.search.submitter && this.search.submitter.accountId,
      localeId: this.lanType.getCurrentLanguage().value,
      productId: (this.search.product && this.search.product.id) ? this.search.product.id : '',
      logicServerId: (this.search.server && this.search.server.id) ? this.search.server.id : '',
      operationLine: (this.search.channel && this.search.channel.id) ? this.search.channel.id : '',
      createTime:`${(this.search.createTime&&this.search.createTime.start)||''}${(this.search.createTime&&this.search.createTime.end&&(' - ' +this.search.createTime.end)||'')}`,
      columns: JSON.stringify(this.getExportColumns()),
    };
    param['request-locale'] = '01';
    param['request-productType'] = '01';
    param['i18n-locale'] = 'zh_CN';

    param = Object.assign(this.search, param);
    this.service.exportIdentityBigCustomer(param);
  }

  getExportColumns(): any[] {
    var columns = [];
    this.table.getDisplayedColumns().forEach(function (column) {
      if (column.header && column.field) {
        columns.push({
          columnView: column.header,
          columnName: column.field
        });
      }
    });
    return columns;
  }


  //修改合服
  modifyBigCustomerService (){
    let list = this.table.getSelectedRows(), isSame = true, ids = [];
    if (!list || list.length == 0) {
      return this.toast.translate('warning', '请选择数据');
    }
    list.forEach((item) => {
      if (item.productId != list[0].productId || item.logicServerId != list[0].logicServerId) {
        return isSame = false;
      }
      ids.push(item.id);
    });
    if (isSame) {
      this.server = {
        product: {
          text: list[0].productName,
          id: list[0].productId
        },
        _product: {
          text: list[0].productName,
          id: list[0].productId
        },
        server: {
          text: list[0].logicServerName,
          id: list[0].logicServerId
        },
        ids: ids.join(','),
        currentLogicServerId: "",
        currentLogicServerName: "",
        productId: list[0].productId,
        localeId: this.lanType.getCurrentLanguage().value,
      };
      this.updateServerModal.show();

    } else {
      this.toast.translate('warning', '数据区服不一致');
    }
  }

  addServerCommition (){
  if(!this.server.currentLogicServerId||!this.server.currentLogicServerName){
    return  this.toast.translate('warning','合服ID和名称不能为空');
  }
  this.server.logicServerId =this.server.server.id;
  this.service.batchModifyCurrentLogicServer(this.server).then( (result) =>{
    if(result.status=='0'){
    this.updateServerModal.hide();
      this.searchCommition();
    }else{
      this.toast.pop('warning',result.desc);
    }
  })
}

  gotoRebate(row:any){
    this.rebateUpdate = {...row,...{isModify:false}};
    this.rebateAdd.show();
  }

  addRebateDone(){
    this.rebateAdd.hide();
  }

  ngOnDestroy(){
    this.tableSubscription.unsubscribe();
  }

}
