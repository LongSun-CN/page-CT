import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {qualityService} from "../../services/quality.service";
import { FormGroup} from "@angular/forms";
import {BaseElement} from "../../widgest/dynamic-form/element/baseElement";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {Subscription} from "rxjs/Subscription";
import {Store} from "@ngrx/store";
import {QualityState}  from "../../reducer/quality.reducer"
import {QualitySearch} from "../../entity/Quality.search";
import {ModalDirective} from "ngx-bootstrap";
import {LanProTypeService} from "../../../widgets/language-producttype/language-producttype.service";
import {ToastService} from "../../../shared/services/toast.service";
import {TranslateService} from "@ngx-translate/core";
import {KefuState} from "../../../widgets/ourpalm-autocomplete/kefu.reducer";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {Observable} from "rxjs/Observable";
import {SelectElement} from "../../widgest/dynamic-form/element/selectElement";
import {Router} from "../../../router/router";

@Component({
  selector: 'app-quality-index',
  templateUrl: `./quality-index.component.html`,
  styleUrls: ['./quality-index.component.css']
})
export class QualityIndexComponent implements OnInit,OnDestroy,OnSearchBtnWorking {
  search:QualitySearch = new QualitySearch();
  add_datas:BaseElement<any>[];
  addform:FormGroup = new FormGroup({});
  table:OurpalmTable;
  $tableSubscription:Subscription;
  @ViewChild('addModal')
  addModal:ModalDirective;

  //add varable start
  isModify:Boolean = false;
  isAdd:Boolean = false;

  currentId:string;

  translations:any;

  $QualityState:Observable<QualityState|KefuState>;


  //add end

  constructor(private  servcie : qualityService,private  $store:Store<QualityState|KefuState>,
              private  toastService:ToastService, private route:Router,
              private  lanprotype: LanProTypeService,private translate:TranslateService) {

    this.table = new OurpalmTable({
      cacheKey: 'kfqa-quality-main',
      cacheColumns: true,
      cachePageSize: true,
      autoLoadData: false,
      pagePosition: 'bottom',
      defaultPageSize: 100,
      pageList: [100, 200],
      showRefreshBtn: false,
      showSettingBtn: false,
      fixTop: true,
      distanceTop: 50,
      onDbClickRow:(idnex,row) =>{
        this.openEditModule(row);
      },
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        this.searchCommition();
      }
    });

   this.$QualityState  = this.$store.select('quality');

    this.translate.get(['不能为空']).subscribe(res=>{
       this.translations = res;
    })


  }

  searchCommition():void{
    this.servcie.queryKfRecordPage(this.search,this.table.getOptions())
  }






  onSelectSearchItem(param: CustomQueryParam) {
    let params = JSON.parse(param.query);
    this.search = {...params,_product:params.product};
    this.searchCommition();
  }

  onSearch() {
    this.searchCommition();
  }

  onSearchAdding(): StringOrResolver {
    return JSON.stringify(this.search);
  }

  onResumeSearchItem(param: CustomQueryParam) {
    this.onResumeSearchNothing();
    this.onSelectSearchItem(param);

  }

  onResumeSearchNothing() {
    this.$tableSubscription = Observable.combineLatest(this.route.params,this.$QualityState, (params: any, state: QualityState|KefuState)=>[params,state])
      .subscribe(([param,result])=>{
        if(result&&!result.isInit){
          this.table.setPageData(result.data);//表格数据
          let params = JSON.parse(result.search);
          this.search = {...params,_product:params.product};
        }
      })

  }



  ngOnInit() {

    //add or edit
    this.servcie.addDynamicFormsData.subscribe((res:BaseElement<any>[])=>{
        this.add_datas = res;
        this.addform = this.servcie.dataIntoForm(this.add_datas);
    });

  }

  openAddModule():void{
    this.servcie.resetAddData();
    this.isAdd = true;
    this.isModify = false;
    this.addModal.show();
  }


  addCommition(){
      let param:any = this.addform.getRawValue(),
        param2:any =  {
        'productType':this.lanprotype.getCurrentProductType().value,
        'locale':this.lanprotype.getCurrentLanguage().value,
        'productId': this.lanprotype.getCurrentProduct().id,
        'qaUserId':this.servcie.user.accountId,
        'kfUserId':(this.addform.value.kfUser&&this.addform.value.kfUser.userId)||this.addform.value.kfUserId,
      };
      param = {...param,...param2};
      const empty = {...this.servcie.emptyParam.sure,...this.servcie.emptyParam.unsure};
      for(let key in empty){
          if(!param[key]){
            return this.toastService.pop('warning',empty[key]+this.translations['不能为空'])
          }
      }

      //去掉key为空的
       delete  param[''];
      delete  param['product'];
      delete  param['kfUser'];
      delete  param['kfUserName'];
      delete  param['productName'];
      this.servcie.addKfqaRecord(param).then((result)=>{
        if (result.status == '0') {
          this.addModal.hide();
          this.searchCommition();
        } else {
          this.toastService.pop('warning',result.desc);
        }
      })
  }


  openEditModule(item:any):void{
    this.servcie.resetAddData();
    this.isAdd = false;
    this.addModal.show();
    this.currentId = item.id;
    this.isModify = true;
    (this.add_datas[1] as SelectElement).changeEvent(item.channelId,item);

  }

  editCommition(){
    let param:any = this.addform.getRawValue(),
      param2:any =  {
        'id':this.currentId,
        'productType':this.lanprotype.getCurrentProductType().value,
        'locale':this.lanprotype.getCurrentLanguage().value,
        'productId': this.addform.value.product&&this.addform.value.product.id,
        'qaUserId':this.servcie.user.accountId,
        'kfUserId':(this.addform.value.kfUser&&this.addform.value.kfUser.userId)||this.addform.value.kfUserId,
      };
    param = {...param,...param2};
    const empty = {...this.servcie.emptyParam.sure,...this.servcie.emptyParam.unsure};
    for(let key in empty){
      if(!param[key]){
        return this.toastService.pop('warning',empty[key]+this.translations['不能为空'])
      }
    }

    //去掉key为空的
    delete  param[''];
    delete  param['product'];
    delete  param['kfUser'];
    delete  param['kfUserName'];
    delete  param['productName'];
    console.log(param);
    this.servcie.updateKfqaRecord(param).then((result)=>{
      if (result.status == '0') {
        this.addModal.hide();
        this.searchCommition();
      } else {
        this.toastService.pop('warning',result.desc);
      }
    })
  }

  //下载
  downloadRecorsExcel = function () {
    if(!this.search.qualityChannel){
       return this.toastService.translate('warning','请选择渠道再下载！');
    }

    this.servcie.downloadRecorsExcel(this.search);
};

 ngOnDestroy(){
   this.$tableSubscription.unsubscribe();
 }

}
