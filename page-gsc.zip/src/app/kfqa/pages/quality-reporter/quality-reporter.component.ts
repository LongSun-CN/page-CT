import {Component, OnDestroy, OnInit} from '@angular/core';
import {OurpalmAutoComplete} from "../../../widgets/ourpalm-autocomplete/OurpalmAutoComplete";
import {qualityService} from "../../services/quality.service";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {Subscription} from "rxjs/Subscription";
import {Store} from "@ngrx/store";
import {QualityReporterState} from "../../reducer/quality-reporter.reducer";
import {TranslateService} from "@ngx-translate/core";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {Observable} from "rxjs/Observable";
import {ToastService} from "../../../shared/services/toast.service";
import {Router} from "../../../router/router";

@Component({
    selector: 'app-quality-reporter',
    templateUrl: './quality-reporter.component.html',
    styleUrls: ['./quality-reporter.component.css']
})
export class QualityReporterComponent implements OnInit, OnDestroy, OnSearchBtnWorking {

    searchform: any = {};
    autocompleteService: OurpalmAutoComplete;
    table: OurpalmTable;
    $tableSubscription: Subscription;
    columns_table: any[][];
    beforeReporterType: string;
    translations: any;
    $QualityReporterState: Observable<QualityReporterState>;

    constructor(private  service: qualityService, private traslate: TranslateService,
                private $store: Store<QualityReporterState>, private route: Router,
                private toast: ToastService) {
        this.traslate.get(['质检日期', '维度', '平均成绩', '总质检量', '平均分', '不合格量', '合格量', '合格率']).subscribe(res => {
            this.translations = res;
            this.myinit();
        })
    }

    ngOnInit() {
    }

    searchCommition() {
        const param = this.searchform;
        if (param.reportType.value === this.beforeReporterType) {
            const options = this.table.getOptions();
            if (!param.reportType || !param.reportType.value) {
                return this.toast.translate('warning', '请选择报表');
            } else if (!param.inspectionDate) {
                return this.toast.translate('warning', '请选择日期');
            }

            this.service.queryScoreReport(param, options)
        } else if (param.reportType && param.reportType.value) {
            this.beforeReporterType = param.reportType.value;
            this.table.changeColumns(this.columns_table[param.reportType.value * 1 - 1]);
            this.table.setOptions({cacheKey: 'qualityReporter-main' + param.reportType.value});
            //this.table.refresh();
        } else {
            return this.toast.translate('warning', '请选择报表');
        }
    }


    onSelectSearchItem(param: CustomQueryParam) {
        let params = JSON.parse(param.query);
        this.searchform = {...params, _product: params.product};
        this.searchCommition();
    }

    onSearch() {
        this.searchCommition();
    }

    onSearchAdding(): StringOrResolver {
        return JSON.stringify(this.searchform);
    }

    onResumeSearchItem(param: CustomQueryParam) {
        this.onResumeSearchNothing();
        this.onSelectSearchItem(param);

    }

    onResumeSearchNothing() {
        this.$tableSubscription = Observable.combineLatest(this.route.params, this.$QualityReporterState, (params: any, state: QualityReporterState) => [params, state])
            .subscribe(([param, result]) => {
                if (result && !result.isInit) {
                    this.table.setPageData(result.data);//表格数据
                    let params = JSON.parse(result.search);
                    this.searchform = {...params, _product: params.product};
                }
            });
    }


    exportKfqaReport() {
        this.service.exportKfqaReport(this.searchform);
    }


    myinit() {
        const service = this.service;
        this.searchform = {
            reportType: {value: '01', selectValue: 'channel'},
            inspectionDate: {
                start: `${moment().format('YYYY-MM-DD')}`,
                end: `${moment().format('YYYY-MM-DD')}`,
                range: null
            },
            channelId: '',
            kfUser: '',
            qualiter: '',
            groupId: ''
        };
        this.beforeReporterType = this.searchform.reportType.value;

        this.autocompleteService = new OurpalmAutoComplete(
            {
                loader: function (val, callback) {
                    service.getKfInfoList(val, 10).then(result => {
                        callback(result.data || [])
                    })
                },
                formatterRow: function (row: any): any {
                    return `${row.name}(${row.user})(${row.jobnum})`;
                },
                formatterValue: function (row): any {
                    return row.name;
                }
            }
        );

        this.columns_table = [[], [], []];
        this.columns_table[0] = [{
            header: this.translations['质检日期'],
            field: 'inspectionDate'
        }, {header: this.translations['维度'], field: 'dimension'}, {
            header: this.translations['平均成绩'],
            field: 'avgScore'
        }];
        this.columns_table[1] = [{
            header: this.translations['质检日期'],
            field: 'inspectionDate'
        }, {header: this.translations['维度'], field: 'dimension'}, {
            header: this.translations['总质检量'],
            field: 'totalCount'
        }, {header: this.translations['不合格量'], field: 'underMarkCount'}, {
            header: this.translations['合格量'],
            field: 'overMarkCount'
        }, {header: this.translations['合格率'], field: 'markRate'}];
        this.columns_table[2] = [{
            header: this.translations['质检日期'],
            field: 'inspectionDate'
        }, {header: this.translations['维度'], field: 'dimension'}, {
            header: this.translations['总质检量'],
            field: 'totalCount'
        }];
        this.columns_table[3] = [{
            header: this.translations['质检日期'],
            field: 'inspectionDate'
        }, {header: this.translations['维度'], field: 'dimension'}, {
            header: this.translations['平均分'],
            field: 'avgServiceFeel'
        }];


        this.table = new OurpalmTable(
            {
                cacheKey: "qualityReporter-main01",
                pagePosition: 'bottom',
                autoLoadData: true,
                defaultPageSize: 100,
                pageList: [100, 200],
                showRefreshBtn: false,
                showSettingBtn: false,
                fixTop: true,
                distanceTop: 50,
                columns: [{
                    header: this.translations['质检日期'],
                    field: 'inspectionDate'
                }, {header: this.translations['维度'], field: 'dimension'}, {
                    header: this.translations['平均分'],
                    field: 'avgScore'
                }],
                loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
                    this.searchCommition();
                }

            }
        );
        this.$QualityReporterState = this.$store.select('qualityReporter');

    }

    ngOnDestroy() {
        this.$tableSubscription.unsubscribe();
    }
}
