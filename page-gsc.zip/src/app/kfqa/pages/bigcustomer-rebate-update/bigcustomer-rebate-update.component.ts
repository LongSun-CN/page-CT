import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild} from '@angular/core';
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {BigcustomerService} from "../../services/bigCustomer.service";
import {ToastService} from "../../../shared/services/toast.service";
import {ModalDirective} from "ngx-bootstrap";

@Component({
  selector: 'bigcustomer-rebate-update',
  templateUrl: './bigcustomer-rebate-update.component.html',
  styleUrls: ['./bigcustomer-rebate-update.component.css']
})
export class BigcustomerRebateUpdateComponent implements OnChanges {

  item: any;
  standard: any;
  tableOrder: any[];
  recoder:any;
  beforeOrders_ids: any[];
  tool: any[];
  tableHistory: OurpalmTable;
  tableLog:OurpalmTable;
  storeOfOrder: any;
  @ViewChild('rebatetoolModal')
  rebatetoolModal: ModalDirective;
  rebateAddToolDialogInner: any;

  @Input('input')
  input:any;
  @Output('finish')
  finish:EventEmitter<void> = new EventEmitter<void>();

  constructor(private service: BigcustomerService, private toast: ToastService) {
    this.item = {}, this.standard = {};
    this.tableHistory = new OurpalmTable({
      cacheKey: "bigcustomerRebate-update-history",
      autoLoadData: false,
      pagination: false,
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        let options = table.getOptions();
        options.pageSize = 3;
        let param = {
          ...options, ...{
            productId: this.item.productId,
            localId: this.item.localId,
            roleId: this.item.roleId,
          }
        };
        this.service.queryRebatePage_update(param).then((result) => {
          if (result.status == '0') {
            callback({
              total: result.data.totalCount,
              rows: result.data.list || []
            });
          } else {
            this.toast.pop('warning', result.desc);
          }
        })
      }
    });
    const that = this;
    this.tableLog =  new OurpalmTable({
      cacheKey: 'bigCustomerRebate-querytableLog', //指定cache时的key
      cachePageSize: true,
      cacheColumns: true,
      pagination:false,
      loadData:(table: OurpalmTable, callback: (page: Page) => {}) => {
        let options = table.getOptions();
        let param = {...options,...{ id:this.item.id}};
        that.service.getRebateRecord(param).then( (result)=> {
          if (result.status == '0') {
            callback({
              total: result.data.logs.length,
              rows: result.data.logs||[]
            });
            //记录上次勾选的订单
            that.beforeOrders_ids = [];
            that.item.orderIds = [];
            result.data.orders.forEach((od)=>{
              that.beforeOrders_ids.push(od.orderId);
              that.item.orderIds.push(od.orderId);
            });
            //修改查询订单时间范围
            if(result.data.orderBeginTime && result.data.orderEndTime){
              that.item.orderTime = result.data.orderBeginTime + ' - '+ result.data.orderEndTime;
            }




            //返利比例总额等
            that.recoder = {
              totalOrderAmount:result.data.totalOrderAmount,
              subType:result.data.subType,
              rebateRatio:result.data.rebateRatio*100+'%',
              totalRebate:result.data.totalRebate,
              currency:result.data.currency,
              rebateAmount:result.data.rebateAmount
            };
            //道具选中列表
            that.item.itemInfos_show = result.data.items ;
            that.item.isFirst_forModify = true;
            that.getOrderList();
          } else {
            this.toast.pop('warning',result.desc);
          }
        });

      }
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes&&changes['input']&&changes['input'].currentValue) {
      this.item = changes['input'].currentValue;
      if (this.item.isModify) {//修改
        this.item = {
          ...this.item, ...{
            channel: this.item.operaName,
            server: this.item.serverName,
            type: this.item.type || '2',
            orderTime: moment().subtract(6, 'days').format('YYYY-MM-DD') + ' - ' + moment().format('YYYY-MM-DD'),
            hasExtraBenefits: this.item.hasExtraBenefits == '1' ? true : false,
            certifyStatus: this.item.certifiedStatus
          }
        }
      } else {
        this.item = {
          ...this.item, ...{
            channel: this.item.operationLineName,
            server: this.item.logicServerName,
            type: this.item.type || '2',
            orderTime: moment().subtract(6, 'days').format('YYYY-MM-DD') + ' - ' + moment().format('YYYY-MM-DD'),
          }
        }
      }
      this.init();
    }
  }

  init() {
    this.standard = {};
    this.tableHistory.firstPage();
    this.item.itemInfos_show = [];
    this.tableHistory.firstPage();
     // 若是修改。。。。。。
    if (this.item.isModify) {//修改
      this.tableLog.firstPage();
    } else {
      this.getOrderList();
    }
  }


  getOrderList(type?: number) {
    const param = {
      productId: this.item.productId,
      localId: this.item.localId,
      roleId: this.item.roleId,
      chargeType: this.item.type,
      orderTime: this.item.orderTime,
      isFilter: this.item.isModify ? '0' : '1',
    };

    const start: number = new Date(param.orderTime.split(' - ')[0]).getTime(),
      end: number = new Date(param.orderTime.split(' - ')[1]).getTime();

    if (!param.orderTime || (end - start) / 86400000 > 30) {
      this.toast.translate('warning', '时间间隔不能大于30天');
      return false;
    }

    this.service.getOrderList(param).then((result) => {
      if (result.status == '0') {
        !this.standard.currencyId && this.getRebateRuleList(param);
        this.item.orderList = [], this.tableOrder = [];
        if (type == 1) {
          this.item.itemInfos_show = [];
          this.beforeOrders_ids = [];
          this.item.isFirst_forModify = false;
          this.item.totalOrderAmount = '';
          this.item.subType = '';
          this.item.rebateRatio = '';
          this.item.totalRebate = '';
          this.item.rebateAmount = '';
          this.getRebateRuleList(param);
        }
        const that = this;
        result.data.forEach((_item, mydex) => {
          _item.isShow = false;
          this.item.orderList.push(_item);
          _item.orderInfoList.isShow = false;
          this.item.orderList.push(_item.orderInfoList);
          this.tableOrder.push({});
          this.tableOrder.push(new OurpalmTable({
            cacheKey: 'bigCustomerRebate-ordertable' + mydex, //指定cache时的key
            cacheColumns: true,
            pagination: false,
            loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
              _item.orderInfoList.forEach((order, $index) => {
                order._index = $index;
                order.__checked__ = false;
                if (that.item.isModify && that.item.isFirst_forModify) {//修改时回显之前的数据
                  if (that.beforeOrders_ids.slice().indexOf(order.orderId) > -1) {
                    order.__checked__ = true;
                  }
                }
              });
              callback({
                total: _item.orderInfoList.length,
                rows: _item.orderInfoList || []
              });
            },
            onHeaderCheckBoxChange: function () {
              console.log(mydex);
              that.orderSelected(2 * mydex);
            },
            onRowCheckBoxChange: function (row, index) {
              console.log(mydex);
              that.orderSelected(2 * mydex, index);
            }
          }));

        })
      } else {
        this.toast.pop('warning', result.desc);
      }
    })
  }

  getRebateRuleList(param: any) {
    param.rechargeWay = param.chargeType;
    this.service.getRebateRuleList(param).then((result) => {
      if (result.status == '0') {
        this.queryGamePropList(param);
        this.standard = result.data;
        this.item.fictitiousCurrencyId = this.standard.currencyId;
        this.item.currency = this.standard.currency;

      } else {
        this.toast.pop('warning', result.desc);
      }
    });
  }

//获取道具列表
  queryGamePropList = function (param) {
    this.service.queryGamePropList(param).then((result) => {
      if (result.status == '0') {
        this.tool = result.data.itemInfo;
        if (this.item.isModify && this.item.isFirst_forModify) {//修改时回显之前的数据
          if (this.item.status == '99') {//按照以前规则显示 返利和道具列表
            this.item = {...this.item, ...this.recoder};
          } else {//按照我当前规则显示 返利和道具列表
            this.item.isFirst_forModify = false;
            this.item.itemInfos_show.forEach((mytool) => {
              this.tool.forEach((stool) => {
                if (mytool.itemInfoId == stool.id) {
                  mytool.itemTotalValue = stool.itemValue * mytool.itemNum;
                }
              })
            });
            this.orderSelected();
          }

        }
      } else {
        this.toast.pop('warning', result.desc);
      }
    });
  };

  showOrHideOrder(index: number) {
    this.item.orderList[index + 1].isShow = !this.item.orderList[index + 1].isShow;
    this.item.orderList[index].isShow = this.item.orderList[index + 1].isShow;
  }


  orderSelected(tableIdex?: number, index?: number) {
    if (this.item.isFirst_forModify) {
      this.item.itemInfos_show = [];
      this.item.isFirst_forModify = false;
    }

    let checkedArr = [];
    let temp = {
      totalOrderAmount: 0,
      subType: 0,
      rebateRatio: 0,
      rebateAmount: 0,
      totalRebate: 0,
      isSameCurency: true,
      temptotalRebate: 0
    };
    this.item.orderIds = [];
    //获取选中的所有数据
    for (let i = 1; i < this.tableOrder.length; i += 2) {
      checkedArr = [...checkedArr, ...this.tableOrder[i].getSelectedRows()];
      (this.tableOrder[i].getSelectedRows().length > 0 && temp.subType < 2) ? temp.subType++ : '';
    }
    //计算总金额
    for (let m = 0; m < checkedArr.length; m++) {
      this.item.orderIds.push(checkedArr[m].orderId);
      temp.totalOrderAmount += checkedArr[m].actualCost * 1;
      if (m > 0 && checkedArr[m].currencyType != checkedArr[m - 1].currencyType) {
        temp.isSameCurency = false;
      }
    }
    //this.item.itemInfos_show = [];
    //计算返利比例
    if (temp.subType == 1) {
      this.standard.singleRebate.forEach((data) => {
        if (temp.totalOrderAmount >= data.lowerBounds && temp.totalOrderAmount <= data.upperBounds) {
          temp.rebateRatio = data.rebateRatio;
          return;
        }
      });
    } else if (temp.subType == 2) {
      this.standard.multiRebate.forEach((data) => {
        if (temp.totalOrderAmount >= data.lowerBounds && temp.totalOrderAmount <= data.upperBounds) {
          temp.rebateRatio = data.rebateRatio;
          return;
        }
      });
    }

    temp.totalRebate = Math.floor(temp.rebateRatio * temp.totalOrderAmount);//返利总额
    temp.rebateAmount = Math.round(temp.totalRebate / this.standard.currencyValue);//返利元宝数

    //计算工具消费额
    this.item.itemInfos_show && this.item.itemInfos_show.forEach((info) => {
      temp.rebateAmount -= info.itemTotalValue * 1
    });
    if (temp.rebateAmount < 0 || !temp.isSameCurency) {
      for (let i = 1; i < this.tableOrder.length; i += 2) {//取消所有选中
        this.tableOrder[i].uncheckAll();
      }

      for (let prop in this.storeOfOrder) {//还原上次所有选中
        this.storeOfOrder[prop].forEach((value) => {
          this.tableOrder[prop].checkRow(value * 1);
        });
      }
      return this.orderSelected();

    }
    //能到这一步说明取消选中成功  记录本次选中的所有订单
    this.storeOfOrder = {};
    for (let i = 1; i < this.tableOrder.length; i += 2) {
      if (this.tableOrder[i].getSelectedRows().length > 0) {
        this.tableOrder[i].getSelectedRows().forEach((_rows) => {
          this.storeOfOrder[i] || (this.storeOfOrder[i] = []);
          this.storeOfOrder[i] && this.storeOfOrder[i].push(_rows._index);
        })
      }
    }

    // temp.rebateRatio = temp.rebateRatio * 100 + '%';
    //
    // temp.subType += '';
    this.item = {...this.item, ...temp, ...{rebateRatio: temp.rebateRatio * 100 + '%', subType: temp.subType + ''}};
  }

  addtool() {
    if (!this.item.rebateAmount || this.item.rebateAmount - this.item.tool.itemValue * this.item.itemNum < 0) {
      return this.toast.translate('warning','不能再添加更多了');
    }

    this.item.rebateAmount -= (this.item.tool.itemValue * this.item.itemNum);//返利元宝数
    this.item.itemInfos_show.push({
      itemInfoId: this.item.tool.id,
      itemNum: this.item.itemNum,
      itemName: this.item.tool.itemName,
      itemTotalValue: this.item.tool.itemValue * this.item.itemNum,
    });
    this.rebatetoolModal.hide();
  }

  minusTool($index: number) {
    if (this.item.isFirst_forModify) {
      this.item.itemInfos_show = [];
      this.item.isFirst_forModify = false;
      this.item.totalOrderAmount = '';
      this.item.subType = '';
      this.item.rebateRatio = '';
      this.item.totalRebate = '';
      this.item.currency = '';
      this.item.rebateAmount = '';
      return false;
    }
    this.item.rebateAmount += (this.item.itemInfos_show[$index].itemTotalValue * 1);
    this.item.itemInfos_show.splice($index, 1);
  }

  openaddtool() {
    if (this.item.isFirst_forModify) {
      this.item.itemInfos_show = [];
      this.item.isFirst_forModify = false;
      this.item.totalOrderAmount = '';
      this.item.subType = '';
      this.item.rebateRatio = '';
      this.item.totalRebate = '';
      this.item.currency = '';
      this.item.rebateAmount = '';
    }
    this.rebatetoolModal.show();
    this.rebateAddToolDialogInner = {'margin-top': document.querySelector('#rebateAddToolDialog .modal-content').scrollHeight*0.7 + 'px'};

  }

  AddRebateCommit(){
    if(!this.item.rebateRatio){
      return this.toast.translate('warning','返利不能为空');
    }
    //兼容该接口字段变化
    var param = {...this.item,...{
      severId:this.item.isModify?this.item.serverId:this.item.logicServerId,
      operaId:this.item.isModify?this.item.operaId:this.item.operationLine,
      rebateRatio:this.item.rebateRatio.replace('%','')/100+'',
      certifiedStatus:this.item.certifyStatus,
      hasExtraBenefits:!!this.item.hasExtraBenefits ? '1' : '0',
      orderIds:this.item.orderIds&&this.item.orderIds.join(','),
      itemInfos:JSON.stringify(this.item.itemInfos_show)
    }};
    if(!param.totalRebate){
      return this.toast.translate('warning','返利不能为空');
    }
    if(this.item.isModify){//修改
      this.service.updateRebateRecord(param).then( (result)=> {
        if(result.status=='0'){
          this.finish.emit();
        }else{
          this.toast.pop('warning',result.desc);
        }
      });
    }else{
      this.service.addRebateInfo(param).then(  (result)=> {
        if(result.status=='0'){
          this.finish.emit();
        }else{
          this.toast.pop('warning',result.desc);
        }
      });
    }
  }
}
