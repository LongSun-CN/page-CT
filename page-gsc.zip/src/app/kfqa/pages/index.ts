/**
 * Created by admin on 2017/6/30.
 */
import  { VipManagerComponent }  from './vip-manager/vip-manager.component';
import   { QualityIndexComponent } from  "./quality-index/quality-index.component";
import { QualityReporterComponent } from "./quality-reporter/quality-reporter.component";
import {BigcustomerSearchComponent} from  "./bigcustomer-search/bigcustomer-search.component";
import {BigcustumerIdentyComponent} from "./bigcustumer-identy/bigcustumer-identy.component";
import {BigcustomerRebateComponent} from "./bigcustomer-rebate/bigcustomer-rebate.component";
import {BigcustomerRebateUpdateComponent} from "./bigcustomer-rebate-update/bigcustomer-rebate-update.component";



export const kfqaPages_Arr = [
    QualityIndexComponent,
    QualityReporterComponent,
    BigcustomerSearchComponent,
    BigcustumerIdentyComponent,
    BigcustomerRebateComponent,
    BigcustomerRebateUpdateComponent,
    VipManagerComponent,
]

export const kfqaPages_Obj = {

    QualityIndexComponent,
    QualityReporterComponent,
    BigcustomerSearchComponent,
    BigcustumerIdentyComponent,
    BigcustomerRebateComponent,
    BigcustomerRebateUpdateComponent,
    VipManagerComponent,

}