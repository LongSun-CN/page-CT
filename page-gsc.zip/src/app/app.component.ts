import {Component, OnInit} from "@angular/core";
import {BaseService} from "./shared/services/base.service";
import {UserService} from "./widgets/user-box/user.service";
import {User} from "./widgets/user-box/user";
import {BodyOutputType, ToasterConfig} from "angular2-toaster";
import {TranslateService} from "@ngx-translate/core";
import {HttpService} from "./shared/services/httpx.service";
import {Observable} from "rxjs/Observable";
import {Store} from "@ngrx/store";
import {ToastService} from "./shared/services/toast.service";
import {urlParam} from "./shared/url-param.const";
import {DatepickerConfig} from "glowworm/lib/datepicker";
import {TableConfig} from "ngx-ourpalm-table";
import {INIT_USER_INFO, UserInfoState} from "./shared/reducers/userinfo-reducer";
import {Router} from "./router/router";
import {ContextMenu} from "glowworm/lib/context-menu";
import {Event, UrlParser, UrlState} from "./router";
import {mask_key, store_key} from "./shared/services/httpx.interceptor";

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {

    toastConfig: ToasterConfig;

    mylinks: Array<any> = [];
    mymodules: Array<any> = [];

    language$: Observable<any>;
    product$: Observable<any>;
    productType$: Observable<any>;

    rightMenus: ContextMenu[];

    /** 标示初始化工作是否完成 */
    initialized: boolean;

    constructor(private store: Store<any>,
                private httpService: HttpService,
                private userService: UserService,
                private baseService: BaseService,
                private router: Router,
                private urlParser: UrlParser,
                private config: DatepickerConfig,
                private tableConfig: TableConfig,
                private toastService: ToastService,
                private translate: TranslateService) {
    }

    ngOnInit(): void {
        this.language$ = this.store.select('languages');
        this.productType$ = this.store.select('productTypes');
        this.product$ = this.store.select('products');

        this.listenRouteChangeEvent();
        this.setToastConfig();//配置toast
        this.setHttpHeader(); //设置http header
        this.setI18nConfig();//配置国际化文件
        this.setDatepickerConfig();
        this.setTableConfig();
        this.initRightMenus();

        Promise.all([
            /** 异步接口完成后 再 初始化 */
            this.getUserInfo(),
            this.getI18nKeys()
        ]).then(() => {
            this.initialized = true;

            this.redirectModule();//根据权限跳转默认模块
            this.refreshMenus(window.location.href);//刷新左侧菜单
            this.saveRecentProduct();

            this.baseService.getProductInfo(urlParam.product);
            this.baseService.loadHeaderProductLanguageList(urlParam.product);
            this.baseService.loadAllAuthProduct();
            this.baseService.loadLanguageList();
        });
    }

    getI18nKeys(): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            let lang = this.translate.currentLang;
            this.httpService.get(`/assets/i18n/${lang}.json`, {[store_key]: `i18n_${lang}`, [mask_key]: true})
                .map(res => res.json())
                .subscribe((result) => {
                    this.translate.setTranslation(lang, result);
                    resolve();
                });
        });
    }

    initRightMenus() {
        this.rightMenus = [{
            text: '前进',
            iconCls: 'fa fa-arrow-right',
            disabled: () => !this.router.canGo(),
            onclick: () => this.router.go()
        }, {
            text: '后退',
            iconCls: 'fa fa-arrow-left',
            disabled: () => !this.router.canBack(),
            onclick: () => this.router.back()
        }];
    }

    setTableConfig() {
        this.tableConfig.config = {
            ctrlSelect: true,
            pageSize: 100,
            pageList: [100, 200],
            enabledFloatThead: false,
            floatTheadConfig: {
                zIndex: 10,
                // position: 'absolute',
                responsiveContainer: function ($table) {
                    return $table.closest('.table-responsive');
                },
                top: () => ((<any>window).screenfull.isFullscreen) ? 3 : 50
            }
        }
    }

    /**
     * 将当前产品保存到最近访问产品列表中
     */
    saveRecentProduct() {
        //先保存当前产品
        this.baseService.saveRecentProduct(urlParam.language, urlParam.product).subscribe(() => {
            //再获取最近的产品列表
            this.baseService.getRecentProductList();
        });
    }

    setDatepickerConfig() {
        const format = this.config.locale.format, timePickerIncrement = this.config.timePickerIncrement;
        const today_s = moment(moment().format('YYYY-MM-DD')).format(format),
            today_e = moment(today_s).add(1, 'days').subtract(timePickerIncrement, 'minute').format(format),
            yesterday_s = moment(moment().format('YYYY-MM-DD')).subtract(1, 'days').format(format),
            yesterday_e = moment(yesterday_s).add(1, 'days').subtract(timePickerIncrement, 'minute').format(format),
            week_s = moment(today_s).subtract(moment().isoWeekday() - 1, 'days').format(format),
            week_e = moment(week_s).add(7, 'days').subtract(timePickerIncrement, 'minute').format(format),
            lastWeek_s = moment(week_s).subtract(7, 'days').format(format),
            lastWeek_e = moment(week_e).subtract(7, 'days').format(format),
            month_s = moment(moment().format('YYYY-MM-DD')).subtract(moment().date() - 1, 'days').format(format),
            month_e = moment(month_s).add(1, 'month').subtract(timePickerIncrement, 'minute').format(format),
            lastMonth_s = moment(month_s).subtract(1, 'month').format(format),
            lastMonth_e = moment(month_e).subtract(1, 'month').format(format);
        Object.assign(this.config, {
                opens: 'center',
                singleDatePicker: false,
                startDate: today_s,
                endDate: today_e,
                ranges: { //今天、昨天  本周、上周 本月、上月
                    '今天': [
                        today_s, today_e
                    ],
                    '昨天': [
                        yesterday_s, yesterday_e
                    ],
                    '本周': [
                        week_s, week_e
                    ],
                    '上周': [
                        lastWeek_s, lastWeek_e
                    ],
                    '本月': [
                        month_s, month_e
                    ],
                    '上月': [
                        lastMonth_s, lastMonth_e
                    ]
                }
            }
        );
    }

    private _moduleId: string;

    /**
     * 监听路由改变事件
     */
    listenRouteChangeEvent() {
        this.router.events.subscribe((e: Event) => {
            this.userService.user && this.refreshMenus(window.location.href);
            this.setHttpHeader();
        });
    }

    setHttpHeader() {
        this.httpService.withCredentials = true;
        this.httpService.setHeaders({
            'X-Requested-With': 'XMLHttpRequest',
            'request-locale': urlParam.language,
            'i18n-locale': urlParam.i18n,
            'request-productid': urlParam.product
        });
    }

    setToastConfig() {
        this.toastConfig = new ToasterConfig({
            newestOnTop: true,
            showCloseButton: true,
            tapToDismiss: false,
            bodyOutputType: BodyOutputType.TrustedHtml
        });
    }

    setI18nConfig() {
        const localMap = {
            "zh_CN": "zh_CN",
            "en_US": "en_US",
            "zh_HK": "zh_HK",
            "th_TH": "th_TH",
            "ko_KR": "ko_KR",
            "ja_JP": "ja_JP"
        };

        this.translate.setDefaultLang(localMap.zh_CN);
        this.translate.use(urlParam.i18n);
    }

    redirectModule() {
        let user = this.userService.user;

        let urlState: UrlState = this.urlParser.parseUrlState(window.location.href);
        let route_exites = urlState && urlState.route;
        let hasPermission = user.modules.filter((module) => urlState.segments.includes(module.code)).length > 0 ? true : false;

        if (!route_exites || !hasPermission) { //如果当前路由不存在
            let default_route: string = this.userService.getDefaultRouterPath();
            this.router.navigate(default_route, {
                queryParamsHandling: 'merge'
            });
        }
    }

    getUserInfo(): Promise<User> {
        return new Promise((resolve, reject) => {
            this.baseService.getUserInfo().subscribe((result) => {
                if (result.status == '0') {
                    let user = new User(result.data);
                    user.moduleId = user.modules[0].code;

                    user.modules.push({name: 'mis', code: 'mis'});
                    user.menu.map(function (item) {
                        return item.url = item.url.replace(/\./g, '/').replace('base/', '').replace('quality', 'kfqa');
                    });

                    let userInfo: UserInfoState = {
                        user: user
                    };

                    this.store.dispatch({
                        type: INIT_USER_INFO,
                        payload: userInfo
                    });

                    this.userService.setCurrentUser(user);
                    resolve(user);
                } else {
                    this.toastService.pop('error', result.desc);
                    reject();
                }
            });
        });
    }

    refreshMenus(fullPath: string) {
        this.mymodules = this.userService.user.modules || [];
        let urlState: UrlState = this.urlParser.parseUrlState(fullPath);
        if (urlState) {
            let moduleId = urlState.segments[0];
            if (moduleId != this._moduleId && moduleId != 'logcenter') {
                this._moduleId = moduleId;
                if (moduleId == 'mis') {
                    this.mylinks = [
                        {title: '基本信息', link: 'mis/basic', icon: 'fa fa-link'},
                        // {title: '商品管理', link: 'mis/goods-manager', icon: 'fa fa-link'},
                        {title: '安卓接入', link: 'mis/sdk/0000', icon: 'fa fa-link'},
                        {title: 'IOS接入', link: 'mis/sdk/0002', icon: 'fa fa-link'},
                        // {title: '网站充值', link: 'mis/web-charge', icon: 'fa fa-link'}
                    ];
                } else {
                    this.mylinks = this.baseService.getMenus(this.userService.user.menu, moduleId);
                }
            }
        }
    }

    filters(event: MouseEvent): boolean {
        let nodeName = (<any>event.target).nodeName;
        let tags = ['INPUT', 'SELECT', 'OPTION', 'A'];
        if (tags.includes(nodeName)) {
            event.stopPropagation();
            return false;
        } else {
            event.preventDefault();
            event.stopPropagation();
            return true;
        }
    }
}
