/**
 * Created by choui on 2017/7/31.
 */
export  class BaseElement{
   type:string;
   options?:{name:string,value:string}[]|any;
   label:string;
   name:string;
   eventCall?:()=>{};
   placeHolder?:string;
   value?:any;
   simple?:boolean;
   selectType?:string;
   showSelect?:boolean = false;
   selectData?:{id:string,text:string}[];


   constructor(param:{
                  type:string,
                  simple?:boolean,
                  options?:{name:string,value:string}[],
                  label:string,
                  name:string,
                  eventCall?:()=>{},
                  placeHolder?:string,
                  value?:any,
                  selectType?:string
   }){
     this.type = param.type;
     this.options = param.options;
     this.label = param.label;
     this.name = param.name;
     this.eventCall = param.eventCall;
     this.placeHolder = param.placeHolder;
     this.value = param.value;
     this.simple = param.simple;
     this.selectType=param.selectType
   }
}
