import {SharedModule} from "../shared/shared.module";
import {WidgetModule} from  "../widgets/widget.module";
import {NgModule} from "@angular/core";
import {SearchFormComponent} from './widgets/search-form/search-form.component';
import {SearchGwFormComponent} from './widgets/search-form/search-gwform.component';
import {PackageService} from  "./server/packageService";
import {RankingService} from "./server/RankingService";
import {packagePipes} from './widgets/pipe';
import {packagePages_list} from './pages/index';

@NgModule({
    imports: [
        SharedModule,
        WidgetModule
    ],
    declarations: [
        ...packagePages_list,
        ...packagePipes,
        SearchFormComponent,
        SearchGwFormComponent,
    ],
    providers: [
        PackageService,
        RankingService
    ]
})
export class PackageModule {
}
