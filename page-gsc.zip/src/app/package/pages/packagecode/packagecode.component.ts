import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {BaseElement} from "../../entitys/baseElement";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {Subscription} from "rxjs/Subscription";
import {PackageService} from "../../server/packageService";
import {ToastService} from "../../../shared/services/toast.service";
import {Store} from "@ngrx/store";
import {PackageListState} from "../../reducer/packageReducer";
import {PackageCodeListState} from "../../reducer/packageCodeReducer";
import {ModalDirective} from "ngx-bootstrap";
import {OurpalmFormComponent} from "ngx-ourpalm-form";
import {environment} from "../../../../environments/environment";
import {HttpService} from "../../../shared/services/httpx.service";
import {OurpalmLoadingService} from "../../../widgets/ourpalm-loading/ourpalm-loading.service";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {Observable} from "rxjs/Observable";
import {Router} from "../../../router/router";

@Component({
  selector: 'app-packagecode',
  templateUrl: './packagecode.component.html',
  styleUrls: ['./packagecode.component.css']
})
export class PackagecodeComponent implements OnInit, OnDestroy,OnSearchBtnWorking {
  searchForm: any;
  datas: BaseElement[];
  table: OurpalmTable;
  $tableSubscription: Subscription;
  id:string;


  @ViewChild('importModal')
  importModal:ModalDirective;
  @ViewChild(OurpalmFormComponent)
  public importForm: OurpalmFormComponent;
  $PackageCodeListState:Observable<PackageCodeListState>;

  @ViewChild('importfile')
  importfile:any;

  constructor(private service: PackageService,
              private store: Store<PackageListState>,
              private loadingService: OurpalmLoadingService,
              private  router:Router,private httpService:HttpService,
              private toastService: ToastService) {
    const _arr = service.getInitCodeList();

    this.datas = _arr.map(item => {
      return new BaseElement(item)
    });

    this.searchForm = {};
    _arr.forEach(item => {
      this.searchForm[item.name] = item.value;
    });




    this.table = new OurpalmTable({
      cacheKey: 'packageListcode-table', //指定cache时的key
      cachePageSize: true,
      cacheColumns: true,
      autoLoadData: false,
      pagePosition: 'bottom',
      defaultPageSize: 100,
      pageList: [100, 200],
      showRefreshBtn: false,
      showSettingBtn: false,
      fixTop: true,
      distanceTop: 50,
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
          this.searchCommition();
      }
    });
    this.$PackageCodeListState = this.store.select('packageCodeList');
      this.$PackageCodeListState.subscribe(res=>{
          console.log(' this.$PackageCodeListState :',res);
      })

  }


  searchCommition() {
    this.service.findGameCodePage({...this.searchForm,...{packageCode:this.id}}, this.table.getOptions());
  }




  onSelectSearchItem(param: CustomQueryParam) {
    let params = JSON.parse(param.query);
    this.searchForm=params;
    this.datas.map(item => {
      item.value = params[item.name]
    });
    this.searchCommition();
  }

  onSearch() {
    this.searchCommition();
  }

  onSearchAdding(): StringOrResolver {
    return JSON.stringify(this.searchForm);
  }

  onResumeSearchItem(param: CustomQueryParam) {
    this.onResumeSearchNothing();
    this.onSelectSearchItem(param);

  }

  onResumeSearchNothing() {
    this.$tableSubscription = Observable.combineLatest(this.router.tab.params,this.$PackageCodeListState,
        (params: any, state: PackageCodeListState)=>[params,state])
      .subscribe(([param,result])=>{
        console.log('12345');
        if (result && !result.isInit) {
          this.table.setPageData(result.data);//表格数据
        }
      })

  }


  ngOnInit() {
     this.router.tab.params.subscribe(res=>{
       if(!res.id) this.router.back();
       this.id = res.id;
       this.searchCommition();
     })
  }

  exportGameCode(){
    const search = this.searchForm;
    var param = {
      'code':search.code,
      'packageId':this.id,
      'status':search.status,
      'getWay':search.getWay,
      'gettingUser':search.gettingUser,
      'gettingTime':search.gettingTime,
      'columns':JSON.stringify(this.getExportColumns()),
    };
    this.service.exportGameCode(param);
  }

  getExportColumns  ():{columnView:string,columnName:string}[] {
    let columns = [];
    this.table.getDisplayedColumns().forEach((column)=> {
      if (column.header && column.field) {
        columns.push({
          columnView: column.header,
          columnName: column.field
        });
      }
    });
    return columns;
  }

  openAddDialog( ){
    this.importfile.nativeElement.value = '';
    this.importModal.show();
  }

  downLoadTemplate(){

     this.service.downLoadTemplate();
  }

  importGameCode(){
    this.loadingService.show();
    this.importModal.hide();
    this.importForm.ajaxSubmit({
      url: environment.getUrl('gameCode/gamePackage/importGameCode.htm'),
      xhrFields: {
        withCredentials: true //跨域发送cookie, 异步提交表单时使用XHR2.0
      },
      headers: this.httpService.getHeaders(),
      success: (result) => {
        console.info(result);
        this.loadingService.hide();
        result = (typeof result === 'string') ? JSON.parse(result) : result;
        if (result.status == '0') {
          this.toastService.translate('success', '添加成功');
          this.searchCommition();
        } else {
          this.toastService.translate('error', result.desc);
        }
      },
      error: (result) => {
        this.loadingService.hide();
        console.info(result);
      }
    })
  }

  ngOnDestroy(){
      this.$tableSubscription&&this.$tableSubscription.unsubscribe();
  }

}


