/**
 * Created by admin on 2017/7/31.
 */
import {PackageListComponent} from "./package-list/package-list.component"
import {PackagecodeComponent} from "./packagecode/packagecode.component";
import {RankingListComponent} from "./ranking-list/ranking-list.component";
import {RankingCycleComponent} from  "./ranking-cycle/ranking-cycle.component";
import {RankingUserListComponent} from  "./ranking-user-list/ranking-user-list.component";
import {RankingUserDetailComponent} from  "./ranking-user-detail/ranking-user-detail.component";


export const packagePages = {
    RankingListComponent,
    PackageListComponent,
    PackagecodeComponent,
    RankingCycleComponent,
    RankingUserListComponent,
    RankingUserDetailComponent
};

export const packagePages_list = [
    RankingListComponent,
    PackageListComponent,
    PackagecodeComponent,
    RankingCycleComponent,
    RankingUserListComponent,
    RankingUserDetailComponent
];
