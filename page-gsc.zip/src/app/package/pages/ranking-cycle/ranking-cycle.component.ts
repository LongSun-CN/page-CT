import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {BaseElement} from "../../entitys/baseElement";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {Subscription} from "rxjs/Subscription";
import {ModalDirective} from "ngx-bootstrap";
import {RankingService} from "../../server/RankingService";
import {Store} from "@ngrx/store";
import {ToastService} from "../../../shared/services/toast.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {Observable} from "rxjs/Observable";
import {LocalGameRangkingCycleState} from "../../reducer/LocalGameRankingCycleReducer";
import {Router} from "../../../router/router";

@Component({
  selector: 'app-ranking-cycle',
  templateUrl: './ranking-cycle.component.html',
  styleUrls: ['./ranking-cycle.component.css']
})
export class RankingCycleComponent implements OnInit ,OnDestroy,OnSearchBtnWorking{
  datas: BaseElement[];
  searchForm: { [index: string]: any };
  addForm: any;
  table: OurpalmTable;
  $tableSubscription: Subscription;
  isAdd: boolean = false;
  isModify: boolean = false;
  $LocalGameRangkingCycleState:Observable<LocalGameRangkingCycleState>;


  @ViewChild('addModal')
  addModal: ModalDirective;

  constructor(private service: RankingService, private store: Store<any>,
              private router:Router, private  toast: ToastService) {
    this.addForm = {
      name: '',
      title: '',
      desc: '',
      product: null,
      channel: null,
      noticeSwitch: '',
      noticeUrl: '',
      type: '',
      rank: '',
      scoreType: '',
      scoreData: '',
    }
  }

  ngOnInit() {
    this.datas = this.service.getLocalGameInitCycleSearchs();
    this.searchForm = {};
    this.datas.forEach(item => {
      this.searchForm[item.name] = item.value;
    });


    this.table = new OurpalmTable({
      cacheKey: 'rangkingLocal-cycle-table', //指定cache时的key
      cachePageSize: true,
      cacheColumns: true,
      autoLoadData: false,
      pagePosition: 'bottom',
      defaultPageSize: 100,
      pageList: [100, 200],
      showRefreshBtn: false,
      showSettingBtn: false,
      fixTop: true,
      distanceTop: 50,
      onDbClickRow: (index, row) => {
        this.modifyOpen(row);
      },
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        this.searchCommition();
      }
    });
    this.$LocalGameRangkingCycleState = this.store.select('cylceGameRankin');



    this.router.tab.params.subscribe(res=>{
        this.searchForm.rankListId = res.id;
    })
  }

  searchCommition() {
    this.service.findActivityCycle(this.searchForm, this.table.getOptions());
  }





  onSelectSearchItem(param: CustomQueryParam) {
    let params = JSON.parse(param.query);
    this.searchForm = params;
    this.datas.map(item => {
      item.value = params[item.name]
    });
    this.searchCommition();
  }

  onSearch() {
    this.searchCommition();
  }

  onSearchAdding(): StringOrResolver {
    return JSON.stringify(this.searchForm);
  }

  onResumeSearchItem(param: CustomQueryParam) {
    this.onResumeSearchNothing();
    this.onSelectSearchItem(param);

  }

  onResumeSearchNothing() {
    this.$tableSubscription = Observable.combineLatest(this.router.tab.params,this.$LocalGameRangkingCycleState, (params: any, state: LocalGameRangkingCycleState)=>[params,state])
      .subscribe(([param,result])=>{
        if (result && !result.isInit) {
          this.table.setPageData(result.data);//表格数据
          let params = JSON.parse(result.search);
          this.searchForm = params;
          this.datas.map(item => {
            item.value = params[item.name]
          })
        }
      })

  }


  updateStatus(type: '1' | '0') {
    let ids: string[] = [];
    let isValid = false;
    this.table.getSelectedRows().forEach(item => {
      if (type === '1' && item.status === '1' && !isValid) {
        this.toast.translate('warning', '选择行中包含已商用的数据');
        isValid = true;
        return;
      } else if (type === '0' && item.status === '0' && !isValid) {
        isValid = true;
        this.toast.translate('warning', '选择行中包含已暂停的数据');
        return;
      } else if (!isValid) {
        ids.push(item.id);
      }
    });
    if (isValid)return;
    this.service.updateActivityCycleStatus(this.searchForm.rankListId,ids, type).then(result => {
      if (result.status === '0') {
        this.toast.translate('success', '修改成功');
        this.searchCommition();
      }
    })

  }

  openAddDialog() {
    this.isAdd = true;
    this.isModify = false;
    this.addForm = {rankListId:this.searchForm.rankListId,status:'0'};
    this.addModal.show()
  }

  addCommition() {
    this.service.haveEmpltyCycle(this.addForm) && this.service.addActivityCycle(this.addForm).then(result => {
      if (result.status === '0') {
        this.addModal.hide();
        this.searchCommition();
      }
    });
  }

  modifyOpen(row: any) {
    this.isAdd = false;
    this.isModify = true;
    this.addForm = row;
    this.addForm = {...this.addForm,  ...row };
    this.addModal.show()
  }

  editCommition() {
    this.service.haveEmpltyCycle(this.addForm) && this.service.updateActivityCycle(this.addForm).then(result => {
      if (result.status === '0') {
        this.addModal.hide();
        this.searchCommition();
      }
    });
  }

  ngOnDestroy(){
    this.$tableSubscription.unsubscribe();
  }
}
