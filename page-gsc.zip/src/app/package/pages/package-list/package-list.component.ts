import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {BaseElement} from "../../entitys/baseElement";
import {PackageService} from "../../server/packageService";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {Subscription} from "rxjs/Subscription";
import {PackageListState} from "../../reducer/packageReducer";
import {Store} from "@ngrx/store";
import {ProductState} from "../../../widgets/ui-select-auto/ui-select-auto.reducer";
import {ModalDirective} from "ngx-bootstrap";
import {ToastService} from "../../../shared/services/toast.service";
import {Observable} from "rxjs/Observable";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {Router} from "../../../router/router";

@Component({
  selector: 'app-package-list',
  templateUrl: './package-list.component.html',
  styleUrls: ['./package-list.component.css']
})
export class PackageListComponent implements OnInit, OnDestroy,OnSearchBtnWorking {

  searchForm: any;
  datas: BaseElement[];
  table: OurpalmTable;
  $tableSubscription: Subscription;
  productReadySubcription: Subscription;
  editOrAdd: 1 | 2;
  isModify: boolean;
  add: any;

  @ViewChild('addModal')
  addModal: ModalDirective;
  $PackageListState:Observable<PackageListState>;

  constructor(private service: PackageService, private store: Store<PackageListState>,
              private toastService: ToastService,private route:Router) {
    const _arr = service.getInitList();

    this.datas = _arr.map(item => {
      return new BaseElement(item)
    });

    this.searchForm = {};
    _arr.forEach(item => {
      this.searchForm[item.name] = item.value;
    });


    this.table = new OurpalmTable({
      cacheKey: 'packageList-table', //指定cache时的key
      cachePageSize: true,
      cacheColumns: true,
      autoLoadData: false,
      pagePosition: 'bottom',
      defaultPageSize: 100,
      pageList: [100, 200],
      showRefreshBtn: false,
      showSettingBtn: false,
      fixTop: true,
      distanceTop: 50,
      onDbClickRow:(index,row)=>{
         this.modifyOpen(row);
      },
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
            this.searchCommition();
      }
    });

    this.$PackageListState = this.store.select('packageList');


    this.productReadySubcription = store.select('product').subscribe((state: ProductState) => {
      if (state.data && state.data.length > 1) {
        this.searchCommition();
      }
    });
  }

  searchCommition() {
    this.service.findGamePackagePage(this.searchForm, this.table.getOptions());
  }





  onSelectSearchItem(param: CustomQueryParam) {
    let params = JSON.parse(param.query);
    this.searchForm=params;
    this.datas.map(item => {
      item.value = params[item.name]
    });
    this.searchCommition();
  }

  onSearch() {
    this.searchCommition();
  }

  onSearchAdding(): StringOrResolver {
    return JSON.stringify(this.searchForm);
  }

  onResumeSearchItem(param: CustomQueryParam) {
    this.onResumeSearchNothing();
    this.onSelectSearchItem(param);

  }

  onResumeSearchNothing() {
    this.$tableSubscription = Observable.combineLatest(this.route.tab.params,this.$PackageListState, (params: any, state: PackageListState)=>[params,state])
      .subscribe(([param,result])=>{
        if (result && !result.isInit) {
          this.table.setPageData(result.data);//表格数据
          let params = JSON.parse(result.search);
          this.searchForm = params;
          this.datas.map(item => {
            item.value = params[item.name]
          })
        }
      })

  }




  openAddDialog() {
    this.editOrAdd = 1;
    this.isModify = false;
    this.add = {status: '0', alertType: '0'};
    this.addModal.show();
  }

  modifyOpen(item: any) {
    this.editOrAdd = 2;
    this.isModify = true;
    this.add = item;
    this.addModal.show();
    this.add.alertUsers  = (item.alertUsers&&item.alertUsers.split(","))||[];
    this.add.product = {
      id:item.productid
    }
  }

  gotoPackageCode(item: any) {
      this.route.navigate(['gamecode/code',item.id], {
        queryParamsHandling: 'merge'
      });
  }

  addOrUpdateCommition() {
      const _param = this.service.paramHandler(this.add);
    if (this.editOrAdd === 2&&_param) {
      _param.id = this.add.id;
      _param.localid = this.add.localid;
      this.service.updateGamePackage(_param).then((result) => {
        if (result.status == '0') {
          this.addModal.hide();
          this.searchCommition();
        } else {
          this.toastService.pop('warning', result.desc);
        }
      })
    } else if(_param){
      this.service.addGamePackage(_param).then((result) => {
        if (result.status == '0') {
          this.addModal.hide();
          this.searchCommition();
        } else {
          this.toastService.pop('warning', result.desc);
        }
      })
    }
  }

  onAddingUser(username): Observable<any> {
    return this.service.isUserValid(username).filter(result => {
      !result.data.success && this.toastService.translate('error', '用户不存在');
      return result.data.success;
    }).mapTo(username);
  }

  ngOnInit() {
    this.add = {};

  }

  ngOnDestroy() {
    this.$tableSubscription.unsubscribe();
    this.productReadySubcription.unsubscribe();
  }

}
