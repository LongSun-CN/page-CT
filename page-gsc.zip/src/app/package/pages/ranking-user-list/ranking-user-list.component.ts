import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {BaseElement} from "../../entitys/baseElement";
import {OurpalmTable, Page} from "ngx-ourpalm-table";
import {Subscription} from "rxjs/Subscription";
import {RankingService} from "../../server/RankingService";
import {Store} from "@ngrx/store";
import {ToastService} from "../../../shared/services/toast.service";
import {OnSearchBtnWorking, StringOrResolver} from "../../../widgets/ourpalm-searchbtn/search-btn.interface";
import {CustomQueryParam} from "../../../widgets/ourpalm-searchbtn/ourpalm-search.service";
import {Observable} from "rxjs/Observable";
import {LocalGameRangkingCycleUsersState} from "../../reducer/LocalGameRankingCycleUsersReducer";
import {Router} from "../../../router/router";

@Component({
  selector: 'app-ranking-user-list',
  templateUrl: './ranking-user-list.component.html',
  styleUrls: ['./ranking-user-list.component.css']
})
export class RankingUserListComponent implements OnInit,OnDestroy,OnSearchBtnWorking {
  datas: BaseElement[];
  searchForm: { [index: string]: any };
  table: OurpalmTable;
  $tableSubscription: Subscription;
  $LocalGameRangkingCycleUsersState:Observable<LocalGameRangkingCycleUsersState>;

  stageId:string;


  constructor(private service: RankingService, private store: Store<any>,
              private router:Router, private  toast: ToastService) {

  }

  ngOnInit() {
    this.datas = this.service.getLocalGameInitCycleUsersSearchs();
    this.searchForm = {};
    this.datas.forEach(item => {
      this.searchForm[item.name] = item.value;
    });


    this.table = new OurpalmTable({
      cacheKey: 'rangkingLocal-cycle-users-table', //指定cache时的key
      cachePageSize: true,
      cacheColumns: true,
      autoLoadData: false,
      pagePosition: 'bottom',
      defaultPageSize: 100,
      pageList: [100, 200],
      showRefreshBtn: false,
      showSettingBtn: false,
      fixTop: true,
      distanceTop: 50,
      onDbClickRow: (index, row) => {
        this.modifyOpen(row);
      },
      loadData: (table: OurpalmTable, callback: (page: Page) => {}) => {
        this.searchCommition();
      }
    });
    this.$LocalGameRangkingCycleUsersState = this.store.select('usersGameRanking');


    this.router.tab.params.subscribe(res=>{
      this.searchForm.stageId = this.stageId = res.id;
    })
  }

  searchCommition() {
    this.service.findUserList(this.searchForm, this.table.getOptions());
  }




  onSelectSearchItem(param: CustomQueryParam) {
    let params = JSON.parse(param.query);
    this.searchForm = params;
    this.datas.map(item => {
      item.value = params[item.name]
    });
    this.searchCommition();
  }

  onSearch() {
    this.searchCommition();
  }

  onSearchAdding(): StringOrResolver {
    return JSON.stringify(this.searchForm);
  }

  onResumeSearchItem(param: CustomQueryParam) {
    this.onResumeSearchNothing();
    this.onSelectSearchItem(param);

  }

  onResumeSearchNothing() {
    this.$tableSubscription = Observable.combineLatest(this.router.tab.params,this.$LocalGameRangkingCycleUsersState, (params: any, state: LocalGameRangkingCycleUsersState)=>[params,state])
      .subscribe(([param,result])=>{
        if (result && !result.isInit) {
          this.table.setPageData(result.data);//表格数据
          let params = JSON.parse(result.search);
          this.searchForm = params;
          this.datas.map(item => {
            item.value = params[item.name]
          })
        }
      })

  }





  modifyOpen(row: any) {

  }


  ngOnDestroy(){
    this.$tableSubscription.unsubscribe();
  }

  getExportColumns  ():{columnView:string,columnName:string}[] {
    let columns = [];
    this.table.getDisplayedColumns().forEach((column)=> {
      if (column.header && column.field) {
        columns.push({
          columnView: column.header,
          columnName: column.field
        });
      }
    });
    return columns;
  }

  exportRegistrationList(){
     this.service.exportRegistrationList({...this.searchForm,columns:JSON.stringify(this.getExportColumns())}, this.table.getOptions())
  }

}
