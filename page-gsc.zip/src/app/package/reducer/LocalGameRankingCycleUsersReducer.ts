import {Action} from "ngx-bootstrap/mini-ngrx";
import {Page} from "ngx-ourpalm-table";
/**
 * Created by admin on 2017/8/21.
 */

export const SEARCH_LOCALGAME_CYCLELIST_USERS = 'search localgame cylce list users';

export class LocalGameRangkingCycleUsersState{
  isInit?:boolean = true;
  search:string;
  data:Page
}

export function LocalGameRankingCyleUsersReducer(state:LocalGameRangkingCycleUsersState,action:Action){
  switch (action.type){
    case SEARCH_LOCALGAME_CYCLELIST_USERS:
      return action.payload;
    default :
      return state;
  }
}
