/**
 * Created by admin on 2017/6/23.
 */
import {PackageListReducer} from  "./packageReducer";
import {PackageCodeListReducer} from  "./packageCodeReducer";
import {LocalGameRankingListReducer} from "./LocalGameRankingListReducer"
import {LocalGameRankingCyleReducer} from "./LocalGameRankingCycleReducer";
import {LocalGameRankingCyleUsersReducer} from "./LocalGameRankingCycleUsersReducer";
import {LocalGameRankingCyleUsersDetailReducer} from "./LocalGameRankingCycleUsersDetailReducer";

export const packageReducer = {
  packageList:PackageListReducer,
  packageCodeList:PackageCodeListReducer,
  localGameRankin:LocalGameRankingListReducer,
  cylceGameRankin:LocalGameRankingCyleReducer,
  usersGameRanking:LocalGameRankingCyleUsersReducer,
  udetailGameRanking:LocalGameRankingCyleUsersDetailReducer
};
