/**
 * Created by admin on 2017/6/23.
 */
import {Action} from "@ngrx/store";
import {Page} from "ngx-ourpalm-table"


export const SEARCH_PACKAGE_LIST = 'search package list';


export  class PackageListState {
  isInit?:boolean = true;
  search:string;
  data:Page
}
export function PackageListReducer(state:PackageListState,action:Action){
  switch (action.type){
    case SEARCH_PACKAGE_LIST:
      return action.payload;
    default :
      return state;
  }
}



