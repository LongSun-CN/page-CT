/**
 * Created by admin on 2017/6/23.
 */
import {Action} from "@ngrx/store";
import {Page} from "ngx-ourpalm-table"


export const SEARCH_PACKAGE_CODE_LIST = 'search package code list';


export  class PackageCodeListState {
  isInit?:boolean = true;
  search:string;
  data:Page
}
export function PackageCodeListReducer(state:PackageCodeListState,action:Action){
  switch (action.type){
    case SEARCH_PACKAGE_CODE_LIST:
      return action.payload;
    default :
      return state;
  }
}



