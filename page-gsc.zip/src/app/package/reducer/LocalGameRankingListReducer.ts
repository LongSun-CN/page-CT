import {Action} from "ngx-bootstrap/mini-ngrx";
import {Page} from "ngx-ourpalm-table";
/**
 * Created by admin on 2017/8/21.
 */

export const SEARCH_LOCALGAME_LIST = 'search localgame list';

export class LocalGameRangkingState{
  isInit?:boolean = true;
  search:string;
  data:Page
}

export function LocalGameRankingListReducer(state:LocalGameRangkingState,action:Action){
  switch (action.type){
    case SEARCH_LOCALGAME_LIST:
      return action.payload;
    default :
      return state;
  }
}
