import {Action} from "ngx-bootstrap/mini-ngrx";
import {Page} from "ngx-ourpalm-table";
/**
 * Created by admin on 2017/8/21.
 */

export const SEARCH_LOCALGAME_CYCLELIST = 'search localgame cylce list';

export class LocalGameRangkingCycleState{
  isInit?:boolean = true;
  search:string;
  data:Page
}

export function LocalGameRankingCyleReducer(state:LocalGameRangkingCycleState,action:Action){
  switch (action.type){
    case SEARCH_LOCALGAME_CYCLELIST:
      return action.payload;
    default :
      return state;
  }
}
