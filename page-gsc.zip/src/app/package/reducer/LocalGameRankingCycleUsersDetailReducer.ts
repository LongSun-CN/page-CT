import {Action} from "ngx-bootstrap/mini-ngrx";
import {Page} from "ngx-ourpalm-table";
/**
 * Created by admin on 2017/8/21.
 */

export const SEARCH_LOCALGAME_CYCLELIST_USERS_DETAIL = 'search localgame cylce list users detail';

export class LocalGameRangkingCycleUsersDetailState{
  isInit?:boolean = true;
  search:string;
  data:Page
}

export function LocalGameRankingCyleUsersDetailReducer(state:LocalGameRangkingCycleUsersDetailState,action:Action){
  switch (action.type){
    case SEARCH_LOCALGAME_CYCLELIST_USERS_DETAIL:
      return action.payload;
    default :
      return state;
  }
}
