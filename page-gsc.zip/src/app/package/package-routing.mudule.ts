import {packagePages} from "./pages";
import {Routes} from "../router";


export const packageRoutingModule: Routes = [
    {
        path: 'gamecode',
        component: packagePages.PackageListComponent
    }, {
        path: 'gamecode/index',
        component: packagePages.PackageListComponent
    }, {
        path: 'gamecode/code/:id',
        component: packagePages.PackagecodeComponent
    }, {
        path: 'gamecode/ranking-localgame',
        component: packagePages.RankingListComponent
    }, {
        path: 'gamecode/ranking-localgame/cycle/:id',
        component: packagePages.RankingCycleComponent
    }, {
        path: 'gamecode/ranking-localgame/userList/:id',
        component: packagePages.RankingUserListComponent
    }, {
        path: 'gamecode/ranking-localgame/userDetailList/:userId/:stageId',
        component: packagePages.RankingUserDetailComponent
    }
];
