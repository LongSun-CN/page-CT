import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'packageGetOsTypePipe'
})
export class PackageGetOsTypePipePipe implements PipeTransform {
  translationns:{[index:string]:string};
  constructor(private translate:TranslateService){
    this.translate.get(['安卓','o','wp','其他']).subscribe(res=>{
      this.translationns = res;
    })
  }
  transform(value: any, args?: any): any {
    switch (value){
      case '0':return this.translationns['安卓'];
      case '1':return this.translationns['ios'];
      case '2':return  this.translationns['wp'];
      case '9':return  this.translationns['其他'];
      default:return '';
    }
  }

}
