import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'getWayPipe'
})
export class PackageGetwayPipe implements PipeTransform {
  translationns:{[index:string]:string};
  constructor(private translate:TranslateService){
    this.translate.get(['官网','论坛','微信','活动']).subscribe(res=>{
      this.translationns = res;
    })
  }


  transform(point: any, args?: any): any {
    switch (point){
      case '1':return  this.translationns['官网'];
      case '2':return  this.translationns['论坛'];
      case '3':return  this.translationns['微信'];
      case '4':return this.translationns['活动'];
      default:return '';
    }
  }
}

