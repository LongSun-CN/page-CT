import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'packageGetUserTypePipe'
})
export class PackageGetUserTypePipePipe implements PipeTransform {
  translationns:{[index:string]:string};
  constructor(private translate:TranslateService){
    this.translate.get(['论坛账户','游戏账户','手机号码','邮箱','fb账户','微信账户']).subscribe(res=>{
      this.translationns = res;
    })
  }
  transform(value: any, args?: any): any {
    switch (value){
      case '1':return this.translationns['论坛账户'];
      case '2':return this.translationns['游戏账户'];
      case '3':return  this.translationns['手机号码'];
      case '4':return  this.translationns['邮箱'];
      case '5':return  this.translationns['fb账户'];
      case '6':return  this.translationns['微信账户'];
      default:return '';
    }
  }

}

