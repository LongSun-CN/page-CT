import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'alertTypePipe'
})
export class PackagePipePipe implements PipeTransform {
  translationns:{[index:string]:string};
  constructor(private translate:TranslateService){
    this.translate.get(['未开启','剩余量提醒','剩余百分比提醒']).subscribe(res=>{
      this.translationns = res;
    })
  }


  transform(point: any, args?: any): any {
    if (point=='0') {
      return this.translationns['未开启']
    } else if (point == '1') {
      return this.translationns['剩余量提醒']
    } else if (point == '2') {
      return this.translationns['剩余百分比提醒']
    }else  {
      return ''
    }
  }

}

