/**
 * Created by admin on 2017/8/24.
 */
import {PackageGetwayPipe} from  "./package-code-getway.pipe";
import {PackageGetOsTypePipePipe} from  "./package-get-os-type-pipe.pipe"
import {PackageGetUserTypePipePipe} from  "./package-get-user-type-pipe.pipe";
import {PackagePipePipe} from  "./package-pipe.pipe";
import {PackageCyclePhasePipe} from  "./package-rangkingCycle.pipe";


export const packagePipes = [
  PackageGetwayPipe,
  PackageGetOsTypePipePipe,
  PackageGetUserTypePipePipe,
  PackagePipePipe,
  PackageCyclePhasePipe
];
