import { Pipe, PipeTransform } from '@angular/core';
import {TranslateService} from "@ngx-translate/core";

@Pipe({
  name: 'cylclePhasePipe'
})
export class PackageCyclePhasePipe implements PipeTransform {
  translationns:{[index:string]:string};
  constructor(private translate:TranslateService){
    this.translate.get(['未开始','进行中','已结束','已关闭']).subscribe(res=>{
      this.translationns = res;
    })
  }


  transform(point: any, args?: any): any {
    if (point=='1') {
      return this.translationns['未开始']
    } else if (point == '2') {
      return this.translationns['进行中']
    } else if (point == '3') {
      return this.translationns['已结束']
    }else if (point == '4') {
      return this.translationns['已关闭']
    }else  {
      return ''
    }

  }

}

