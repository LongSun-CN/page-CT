import {Component, Input, OnInit} from '@angular/core';
import {BaseElement} from "../../entitys/baseElement";
import {FormGroup} from "@angular/forms";
import {OurpalmBoxComponent} from "../../../widgets/ourpalm-box/ourpalm-box.component";

@Component({
  selector: 'package-search-form',
  template: `
    <form class="form-inline form-search-column" role="form" [formGroup]="form">

      <ng-container *ngFor="let data of datas_simple;index as $index;">
        <ng-container [ngSwitch]="data.type">

          <div class="form-group" *ngSwitchCase="'input'">
            <label class="control-label" >
              {{data.label}}
            </label>
            <input *ngSwitchCase="'input'" placeholder=" {{data.placeHolder}}" [formControlName]="data.name"
                   [value]="data.value" class="form-control input-sm"/>
          </div>

          <div class="form-group" *ngSwitchCase="'select'">
            <label class="control-label" *ngIf="data.type==='input'||data.type==='select'">
              {{data.label}}
            </label>
            <select *ngSwitchCase="'select'" class="form-control input-sm" [formControlName]="data.name"
                    [value]="data.value">
              <option *ngFor="let op of data.options" [value]="op.value">{{op.name}}</option>
            </select>
          </div>

          <div class="form-group" *ngSwitchCase="'date'">
            <label class="control-label" >
              {{data.label}}
            </label>
            <input type="text"  (ngModelChange)="setFormValue($event,data.name)"
                    [options]="data.options"   [value]="form.get(data.name).value"
                   class="form-control input-sm" ourpalm-daterangepicker placeholder="">
          </div>
        

          <ourpalm-products-auto *ngSwitchCase="'product'" emit="" [select]="data.value"
                                 (ngModelChange)="setFormValue($event,data.name)" key="search"></ourpalm-products-auto>


        </ng-container>
      </ng-container>


      <ourpalm-box-multiform [box]="box" *ngIf="datas_multip&&datas_multip.length>0">
        <ng-container *ngFor="let data of datas_multip;index as $index;">
          <ng-container [ngSwitch]="data.type">

            <div class="form-group" *ngSwitchCase="'input'">
              <label class="control-label" >
                {{data.label}}
              </label>
              <input *ngSwitchCase="'input'" placeholder=" {{data.placeHolder}}" [formControlName]="data.name"
                     [value]="data.value" class="form-control input-sm"/>
            </div>

            <div class="form-group" *ngSwitchCase="'select'">
              <label class="control-label" >
                {{data.label}}
              </label>
              <select *ngSwitchCase="'select'" class="form-control input-sm" [formControlName]="data.name"
                      [value]="data.value">
                <option *ngFor="let op of data.options" [value]="op.value">{{op.name}}</option>
              </select>
            </div>

            <div class="form-group" *ngSwitchCase="'date'">
              <label class="control-label" >
                {{data.label}}
              </label>
              <input type="text"  (ngModelChange)="setFormValue($event,data.name)"
                     [options]="data.options"   [value]="form.get(data.name).value"
                     class="form-control input-sm" ourpalm-daterangepicker placeholder="">
            </div>

            <ourpalm-products-auto *ngSwitchCase="'product'" emit="" [select]="data.value"
                                   (ngModelChange)="setFormValue($event,data.name)"
                                   key="search"></ourpalm-products-auto>

          </ng-container>
        </ng-container>
      </ourpalm-box-multiform>

    </form>
  `,
  styles: ['']
})
export class SearchFormComponent implements OnInit {

  @Input()
  datas: BaseElement[];

  @Input()
  form: FormGroup;

  @Input()
  box: OurpalmBoxComponent;

  datas_simple: BaseElement[] = [];
  datas_multip: BaseElement[] = [];


  constructor() {

  }

  ngOnInit() {
    if (this.datas && this.datas.length) {
      this.datas.forEach(item => {
        if (!item.simple) {
          this.datas_multip.push(item);
        } else {
          this.datas_simple.push(item);
        }
      })
    }
  }

  setFormValue(ev: string, name: string) {
    this.form.patchValue({
      [name]: ev
    }, {
      onlySelf: true
    })
  }

}
