import {Component, Input, OnInit} from '@angular/core';
import {BaseElement} from "../../entitys/baseElement";
import {FormGroup} from "@angular/forms";
import {OurpalmBoxComponent} from "../../../widgets/ourpalm-box/ourpalm-box.component";

@Component({
  selector: 'package-search-gwform',
  template: `
    <div class="form-inline form-search-column" role="form">
      <gw-toolbar #bar>
        <ng-container *ngFor="let data of datas;index as $index;">
          <ng-container [ngSwitch]="data.type">
            <gw-input #gwcontrol *ngSwitchCase="'input'" [toolbar]="bar"
                      [label]="data.label"
                      [(ngModel)]="search[data.name]"
                      [closeable]="false"
                      [enabled]="true"
                      [showSelect]="data.showSelect"
                      [selectData]="data.selectData"
            ></gw-input>
            <gw-rangeinput #gwcontrol *ngSwitchCase="'rangeinput'" [toolbar]="bar"
                      [label]="data.label"
                      [(ngModel)]="search[data.name]"
                      [closeable]="false"
                      [enabled]="true"
                      [showSelect]="data.showSelect"
                      [selectData]="data.selectData"
            ></gw-rangeinput>
            <gw-single-select #gwcontrol *ngSwitchCase="'select'" [toolbar]="bar"
                              [label]="data.label"
                              [data]="data.options"
                              [(ngModel)]="search[data.name]"
                              [closeable]="false"
                              [enabled]="true"
                              [showSelect]="false"
            ></gw-single-select>

            <gw-datepicker #gwcontrol *ngSwitchCase="'date'" [toolbar]="bar"   [closeable]="false"
                           [label]="data.label"
                           [options]="data.options"
                           [(ngModel)]="search[data.name]">
            </gw-datepicker>

            <gw-select-auto-product *ngSwitchCase="'product'"  
                                    [toolbar]="bar"
                                     key="'search'"
                                    [type]="data.selectType"
                                    [(ngModel)]="search[data.name]">
            ></gw-select-auto-product>
            
            <gw-select-auto-server *ngSwitchCase="'server'" [toolbar]="bar"
                                    key="'search'"
                                   [(ngModel)]="search[data.name]">
            ></gw-select-auto-server>
            
            <gw-select-auto-channel
              *ngSwitchCase="'channel'" [toolbar]="bar"
              key="'search'"
              [(ngModel)]="search[data.name]"
            ></gw-select-auto-channel>

            <gw-select-complete-kefu  *ngSwitchCase="'admin'"
                                      [toolbar]="bar"
                                      [label]="data.label"
                                       type="2"
                                      [(ngModel)]="search[data.name]" 
            ></gw-select-complete-kefu>
            
          </ng-container>
        </ng-container>
      </gw-toolbar>
    </div>
  `,
  styles: ['']
})
export class SearchGwFormComponent implements OnInit {

  @Input()
  datas: BaseElement[];

  @Input()
  search: any;


  constructor() {

  }

  ngOnInit() {

  }



}
