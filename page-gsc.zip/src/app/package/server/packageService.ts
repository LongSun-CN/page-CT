/**
 * Created by admin on 2017/7/31.
 */
import {Injectable} from "@angular/core";
import {BaseElement} from "../entitys/baseElement";
import {Store} from "@ngrx/store";
import {TranslateService} from "@ngx-translate/core";
import {PackageListState, SEARCH_PACKAGE_LIST} from "../reducer/packageReducer";
import {LanProTypeService} from "../../widgets/language-producttype/language-producttype.service";
import {DateFormatterPipe} from "../../widgets/ourpalm-pipes/date-formatter.pipe";
import * as moment from "moment";
import {PackageCodeListState, SEARCH_PACKAGE_CODE_LIST} from "../reducer/packageCodeReducer";
import {environment} from "../../../environments/environment";
import {HttpService} from "../../shared/services/httpx.service";
import {ToastService} from "../../shared/services/toast.service";

@Injectable()
export class PackageService {
  mustNotNull = {
    'name': '礼包名称不能为空',
    'productid': '产品不能为空',
    'status': '状态不能为空',
    'invalidTime': '失效时间不能为空',
  };

  constructor(private http: HttpService, private $store: Store<PackageListState | PackageCodeListState>,
              private lanservice: LanProTypeService, private  toast: ToastService,
              private translate: TranslateService, private dateformatter: DateFormatterPipe) {

  }

  getInitList(): BaseElement[] {
    return [{
      type: 'input',
      label: '礼包名称',
      name: 'packageName',
      placeHolder: '请输入礼包名称',
      value: ''
    }, {
      type: 'product',
      label: '产品',
      name: 'product',
      selectType:''
    }, {
      type: 'select',
      label: '状态',
      name: 'status',
      value: '',
      options: [{text: '暂停', id: '0'}, {text: '商用', id: '1'}]
    }];
  }

  findGamePackagePage(search: any, options: any): void {
    let param = {
      'localid': (this.lanservice.getCurrentLanguage() && this.lanservice.getCurrentLanguage().value) || "01",
      'packageName': search.packageName,
      'status': search.status,
      'productId': search.product && search.product.id,
      'currentPage': options.currentPage,
      'rows': options.pageSize,
      'isValid': '0'
    };
    if (!param.productId) {
      param.productId = [];
      this.lanservice.getAllProduct().forEach((item) => {
        item.id && param.productId.push(item.id);
      });
      param.productId = param.productId.join(',');
      if (!param.productId) {
        return this.toast.translate('warning', '没有可查询的产品');
      }
    }

    this.http.get(environment.getUrl('gameCode/gamePackage/findGamePackagePage.htm'), param)
      .map((res: any) => {
        res = res.json();
        res.data && res.data.list && res.data.list.map(item => {
          const fmt = 'YYYY-MM-DD HH:mm:ss';
          item.invalidTime = this.dateformatter.transform(item.invalidTime, fmt);
          item.createTime = this.dateformatter.transform(item.createTime, fmt);
          item.modifyTime = this.dateformatter.transform(item.modifyTime, fmt);
          return item;
        });
        return res;
      })
      .subscribe(res => {
        let state = {
          isInit: false,
          search: JSON.stringify(search),
          data: {
            currentPage: options.currentPage,
            pageSize: options.pageSize,
            total: (res.data && res.data.totalCount) || 0,
            rows: (res.data && res.data.list) || []
          }
        };
        this.$store.dispatch({
          type: SEARCH_PACKAGE_LIST,
          payload: state
        })
      });
  }

  isUserValid(user: string) {
    return this.http
      .get(environment.getUrl('account/accountManage/checkUserIsValid.htm'), {
        username: user
      }).map(response => response.json());
  }


  updateGamePackage(param: any): Promise<any> {
    return this.http.post(environment.getUrl('gameCode/gamePackage/updateGamePackage.htm'), param).map(res => res.json()).toPromise()
  }

  addGamePackage(param: any) {
    return this.http.post(environment.getUrl('gameCode/gamePackage/addGamePackage.htm'), param).map(res => res.json()).toPromise()
  }

  paramHandler(add: any): { [index: string]: string } {
    var param = {
      'name': add.name,
      'localid': this.lanservice.getCurrentLanguage().value,
      'productid': add.product && add.product.id,
      'status': add.status,
      'desc': add.desc,
      'instruction': add.instruction,
      'invalidTime': add.invalidTime || '0',
      'alertType': add.alertType,
      'alertUsers': '',
      'alertValue': add.alertValue,
    };
    let users = [];
    add.alertUsers.forEach(item => {
      users.push(item.value || item);
    });
    param.alertUsers = users.join(',');
    //过滤不能为空的参数
    for (let key of Object.keys(this.mustNotNull)) {
      if (!param[key]) {
        this.toast.pop('warning', this.mustNotNull[key]);
        return;
      }
    }
    //失效时间 范围为现在到一年后

    if (param.invalidTime < moment().format('YYYY-MM-DD HH:mm:SS') || param.invalidTime > moment().add(1, 'y').format('YYYY-MM-DD HH:mm:SS')) {
      this.toast.translate('warning', '失效时间为现在起往后一年内');
      return
    }

    //若提醒开启 提醒人和提醒阀值不能为空
    if (param.alertType != '0') {
      if (!param.alertValue) {
        this.toast.translate('warning', '提醒阀值必须大于0');
        return
      }
      if (param.alertUsers.length == 0) {
        this.toast.translate('warning', '提醒人不能为空');
        return
      }
    }
    return param;
  }


  getInitCodeList(): BaseElement[] {
    return [{
      type: 'input',
      label: '码号',
      name: 'code',
      value: ''
    }, {
      type: 'select',
      label: '状态',
      name: 'status',
      value: '',
      options: [{text: '未领取', id: '0'}, {text: '已领取', id: '1'}]
    }, {
      type: 'select',
      label: '下发通道',
      name: 'getWay',
      value: '',
      options: [{text: '官网', id: '0'}, {text: '论坛', id: '1'}
        , {text: '微信', id: '2'}, {text: '活动', id: '3'}]
    }, {
      type: 'input',
      label: '领取用户',
      name: 'gettingUser',
      placeHolder: '',
      value: ''
    }, {
      type: 'date',
      label: '领取时间',
      name: 'gettingTime',
      placeHolder: '请选择领取日期',
      value: '',
      options: {locale: {format: "YYYY-MM-DD"}, opens: 'left'}
    }];
  }

  //礼包-分页查询码号接口

  findGameCodePage(search: any, options: any): void {
    let param = {
      'code': search.code,
      'packageId': search.packageCode,
      'status': search.status,
      'getWay': search.getWay,
      'gettingUser': search.gettingUser,
      'gettingTime': `${(search.gettingTime && search.gettingTime.start) || ''}${(search.gettingTime && search.gettingTime.end && (' - ' + search.gettingTime.end) || '')}`,
      'currentPage': options.currentPage,
      'rows': options.pageSize,
    };

    this.http.get(environment.getUrl('gameCode/gamePackage/findGameCodePage.htm'), param)
      .map((res: any) => {
        res = res.json();
        res.data && res.data.list && res.data.list.map(item => {
          const fmt = 'YYYY-MM-DD HH:mm:ss';
          item.getTime = this.dateformatter.transform(item.getTime, fmt);
          item.createTime = this.dateformatter.transform(item.createTime, fmt);
          item.modifyTime = this.dateformatter.transform(item.modifyTime, fmt);
          return item;
        });
        return res;
      })
      .subscribe(res => {
        let state = {
          isInit: false,
          search: JSON.stringify(search),
          data: {
            currentPage: options.currentPage,
            pageSize: options.pageSize,
            total: (res.data && res.data.totalCount) || 0,
            rows: (res.data && res.data.list) || []
          }
        };
        this.$store.dispatch({
          type: SEARCH_PACKAGE_CODE_LIST,
          payload: state
        })
      });
  }


  //礼包- 列表下载
  exportGameCode(param): void {
    this.http.download(environment.getUrl('gameCode/gamePackage/exportGameCode.htm'), param);
  };

  //礼包- 模板下载
  downLoadTemplate() {
    this.http.download(environment.getUrl('gameCode/gamePackage/downLoadTemplate.htm'));
  }

}
