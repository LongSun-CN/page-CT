import {Injectable} from "@angular/core";
import {LanProTypeService} from "../../widgets/language-producttype/language-producttype.service";
import {TranslateService} from "@ngx-translate/core";
import {DateFormatterPipe} from "../../widgets/ourpalm-pipes/date-formatter.pipe";
import {Store} from "@ngrx/store";
import {BaseElement} from "../entitys/baseElement";
import {environment} from "../../../environments/environment";
import {SEARCH_LOCALGAME_LIST} from "../reducer/LocalGameRankingListReducer";
import {SEARCH_LOCALGAME_CYCLELIST} from "../reducer/LocalGameRankingCycleReducer";
import {SEARCH_LOCALGAME_CYCLELIST_USERS} from "../reducer/LocalGameRankingCycleUsersReducer";
import {SEARCH_LOCALGAME_CYCLELIST_USERS_DETAIL} from "../reducer/LocalGameRankingCycleUsersDetailReducer";
import {HttpService} from "../../shared/services/httpx.service";
import {ToastService} from "../../shared/services/toast.service";
/**
 * Created by admin on 2017/8/21.
 */
@Injectable()
export class RankingService {

  addFormMap = {
    name: '',
    title: '',
    desc: '',
    product: null,
    channel: null,
    noticeSwitch: '',
    noticeUrl: '',
    type: '',
    rank: '',
    scoreType: '',
    scoreData: '',
  };
  addFormMapCycle = {
    name: '',
    beginTime: '',
    endTime: '',
    cutOffTime: ''
  };


  constructor(private http: HttpService, private $store: Store<any>,
              private lanservice: LanProTypeService, private  toast: ToastService,
              private translate: TranslateService, private dateformatter: DateFormatterPipe) {

    translate.get(['名称不能为空', '标题不能为空', '描述不能为空', '产品不能为空',
      '联运不能为空', '公告开关不能为空', '榜单类型不能为空', '标题名额不能为空',
      '变更分值类型不能为空', '变更分值不能为空', '公告地址不能为空', '开始时间不能为空', '结束时间不能为空', '关闭时间不能为空'
    ]).subscribe(translations => {
      this.addFormMap = {
        name: translations['名称不能为空'],
        title: translations['标题不能为空'],
        desc: translations['描述不能为空'],
        product: translations['产品不能为空'],
        channel: translations['联运不能为空'],
        noticeSwitch: translations['公告开关不能为空'],
        noticeUrl: translations['公告地址不能为空'],
        type: translations['榜单类型不能为空'],
        rank: translations['标题名额不能为空'],
        scoreType: translations['变更分值类型不能为空'],
        scoreData: translations['变更分值不能为空'],
      };
      this.addFormMapCycle = {
        name: translations['名称不能为空'],
        beginTime: translations['开始时间不能为空'],
        endTime: translations['结束时间不能为空'],
        cutOffTime: translations['关闭时间不能为空'],
      }
    })

  }

  /*******************************活动排行start***********************************************************/

  getLocalGameInitSearchs(): BaseElement[] {
    return [{
      type: 'input',
      label: '名称',
      name: 'name',
      placeHolder: '请输入礼包名称',
      value: ''
    }, {
      type: 'product',
      label: '产品',
      name: 'product',
      selectType: '2'
    }, {
      type: 'channel',
      label: '联运',
      name: 'channel'
    }, {
      type: 'select',
      label: '状态',
      name: 'status',
      value: '',
      options: [{text: '暂停', id: '0'}, {text: '商用', id: '1'}]
    }, {
      type: 'date',
      label: '修改时间',
      name: 'modifyTime',
      value: '',
      options: '{singleDatePicker:false,opens:"right",timePickerIncrement :1,locale:{ format: "YYYY-MM-DD"}}'
    }];
  }

  findSingleRankingList(searchForm: { [p: string]: any }, options: { [p: string]: any }) {
    let param: { [index: string]: string } = {
      startTime: searchForm.modifyTime && searchForm.modifyTime.start,
      endTime: searchForm.modifyTime && searchForm.modifyTime.end,
      operationLineId: searchForm.channel && searchForm.channel.id,
      productId: searchForm.product && searchForm.product.id,
      localeId: this.lanservice.getCurrentLanguage().value,
      status: searchForm.status,
      name: searchForm.name,
    };
    param = {...searchForm, ...options, ...param};
    this.http.get(environment.getUrl('activity/rankList/findSingleRankingList.htm'), param)
      .map(res => res.json())
      .subscribe(result => {
        if (result.status === '0') {
          let state = {
            isInit: false,
            search: JSON.stringify(searchForm),
            data: {
              currentPage: options.currentPage,
              pageSize: options.pageSize,
              total: (result.data && result.data.totalCount) || 0,
              rows: (result.data && result.data.list) || []
            }
          };
          this.$store.dispatch({
            type: SEARCH_LOCALGAME_LIST,
            payload: state
          })
        } else {
          this.toast.pop('warning', result.desc);
        }

      })
  }

  addRankingList(addForm: any): Promise<any> {
    let param = {
      ...addForm, ...{
        operationLineId: addForm.channel.id,
        productId: addForm.product.id,
        localeId: this.lanservice.getCurrentLanguage().value
      }
    };
    console.log('addRankingList', param);
    return this.http.get(environment.getUrl('activity/rankList/addRankingList.htm'), param)
      .map(res => res.json())
      .toPromise();
  }

  updateRankingList(addForm: any): Promise<any> {
    let param = {
      ...addForm, ...{
        operationLineId: addForm.channel.id,
        productId: addForm.product.id,
        localeId: this.lanservice.getCurrentLanguage().value
      }
    };
    return this.http.get(environment.getUrl('activity/rankList/updateRankList.htm'), param)
      .map(res => res.json())
      .toPromise();
  }


  updateStatus(ids: string[], type: '1' | '0'): Promise<any> {
    return this.http.post(environment.getUrl('activity/rankList/updateStatus.htm'), {
      rankListIds: ids.join(','),
      status: type
    })
      .map(res => res.json())
      .toPromise()
  }

  haveEmplty(addForm: any): boolean {
    let isvalid = true;
    for (let prop in this.addFormMap) {
      if (!addForm[prop]) {
        this.toast.pop('warning', this.addFormMap[prop]);
        isvalid = false;
      }
    }
    return isvalid;
  }

  /*******************************活动排行start***********************************************************/

  getLocalGameInitCycleSearchs(): BaseElement[] {
    return [{
      type: 'input',
      label: '名称',
      name: 'name',
      placeHolder: '请输入礼包名称',
      value: ''
    }, {
      type: 'select',
      label: '状态',
      name: 'status',
      value: '',
      options: [{text: '暂停', id: '0'}, {text: '商用', id: '1'}]
    }, {
      type: 'select',
      label: '阶段',
      name: 'phase',
      value: '',
      options: [{text: '未开始', id: '1'}, {text: '进行中', id: '2'}, {text: '已结束', id: '3'}, {text: '已关闭', id: '4'}]
    }, {
      type: 'date',
      label: '修改时间',
      name: 'modifyTime',
      value: '',
      options: '{singleDatePicker:false,opens:"right",timePickerIncrement :1,locale:{ format: "YYYY-MM-DD"}}'
    }];
  }

  findActivityCycle(searchForm: { [p: string]: any }, options: { [p: string]: any }) {
    let param: { [index: string]: string } = {
      startTime: searchForm.modifyTime && searchForm.modifyTime.start,
      endTime: searchForm.modifyTime && searchForm.modifyTime.end
    };
    param = {...searchForm, ...options, ...param};
    this.http.get(environment.getUrl('activity/rankList/findActivityCycle.htm'), param)
      .map(res => res.json())
      .subscribe(result => {
        if (result.status === '0') {
          let state = {
            isInit: false,
            search: JSON.stringify(searchForm),
            data: {
              currentPage: options.currentPage,
              pageSize: options.pageSize,
              total: (result.data && result.data.totalCount) || 0,
              rows: (result.data && result.data.list) || []
            }
          };
          this.$store.dispatch({
            type: SEARCH_LOCALGAME_CYCLELIST,
            payload: state
          })
        } else {
          this.toast.pop('warning', result.desc);
        }

      })
  }

  addActivityCycle(addForm: any): Promise<any> {
    console.log('addRankingList', addForm);
    return this.http.get(environment.getUrl('activity/rankList/addActivityCycle.htm'), addForm)
      .map(res => res.json())
      .toPromise();
  }

  updateActivityCycle(addForm: any): Promise<any> {
    return this.http.get(environment.getUrl('activity/rankList/updateRankList.htm'), addForm)
      .map(res => res.json())
      .toPromise();
  }

  updateActivityCycleStatus(rankListId: string, ids: string[], type: '1' | '0'): Promise<any> {
    return this.http.post(environment.getUrl('activity/rankList/updateActivityCycleStatus.htm'), {
      stageIds: ids.join(','),
      rankListId,
      status: type
    })
      .map(res => res.json())
      .toPromise()
  }

  haveEmpltyCycle(addForm: any): boolean {
    let isvalid = true;
    for (let prop in this.addFormMapCycle) {
      if (!addForm[prop]) {
        this.toast.pop('warning', this.addFormMapCycle[prop]);
        isvalid = false;
      }
    }
    return isvalid;
  }

  /*******************************活动周期start***********************************************************/


  /*******************************活动周期用户列表 start**********************************************************/
  getLocalGameInitCycleUsersSearchs(): BaseElement[] {
    return [{
      type: 'input',
      label: '名称',
      name: 'name',
      placeHolder: '请输入礼包名称',
      value: '',
      showSelect: true,
      selectData: [{id: 'userId', text: '用户ID'}, {id: 'nickName', text: '用户昵称'}, {id: 'phone', text: '手机号'}]
    }, {
      type: 'rangeinput',
      label: '分数',
      name: 'score',
      placeHolder: '请输入分数',
      value: '',
      showSelect: false,
      selectData: []
    }, {
      type: 'date',
      label: '更新时间',
      name: 'modifyTime',
      value: '',
      options: '{singleDatePicker:false,opens:"right",timePickerIncrement :1,locale:{ format: "YYYY-MM-DD"}}'
    }];
  }

  findUserList(searchForm: { [p: string]: any }, options: { [p: string]: any }) {
    let param: { [index: string]: string } = {
      userInfoType:searchForm.name&&searchForm.name.selectValue,
      userInfoText:searchForm.name&&searchForm.name.value,
      score:(searchForm.score&&searchForm.score.start)+','+(searchForm.score&&searchForm.score.end),
      startTime: searchForm.modifyTime && searchForm.modifyTime.start,
      endTime: searchForm.modifyTime && searchForm.modifyTime.end
    };
    param = {...searchForm, ...options, ...param};
    this.http.get(environment.getUrl('activity/rankList/findUserList.htm'), param)
      .map(res => res.json())
      .subscribe(result => {
        if (result.status === '0') {
          let state = {
            isInit: false,
            search: JSON.stringify(searchForm),
            data: {
              currentPage: options.currentPage,
              pageSize: options.pageSize,
              total: (result.data && result.data.totalCount) || 0,
              rows: (result.data && result.data.list) || []
            }
          };
          this.$store.dispatch({
            type: SEARCH_LOCALGAME_CYCLELIST_USERS,
            payload: state
          })
        } else {
          this.toast.pop('warning', result.desc);
        }

      })
  }

  exportRegistrationList(searchForm: { [p: string]: any }, options: { [p: string]: any }):void{
    let param: { [index: string]: string } = {
      exportType:'excel',
      userInfoType:searchForm.name&&searchForm.name.selectValue,
      userInfoText:searchForm.name&&searchForm.name.value,
      score:(searchForm.score&&searchForm.score.start)+','+(searchForm.score&&searchForm.score.end),
      startTime: searchForm.modifyTime && searchForm.modifyTime.start,
      endTime: searchForm.modifyTime && searchForm.modifyTime.end
    };
    param = {...searchForm, ...options, ...param};
    this.http.download(environment.getUrl('activity/rankList/exportRegistrationList.htm'),param);
  }
  /*******************************活动周期用户列表 end***********************************************************/

  /*******************************活动周期用户列表详情 start***********************************************************/
  getLocalGameInitCycleUserDetailSearchs(): BaseElement[] {
    return [ {
      type: 'select',
      label: '分数来源',
      name: 'type',
      value: '',
      options: [{text: '游戏活动', id: '1'}, {text: '后台管理', id: '2'}]
    }, {
      type: 'date',
      label: '更新时间',
      name: 'modifyTime',
      value: '',
      options: '{singleDatePicker:false,opens:"right",timePickerIncrement :1,locale:{ format: "YYYY-MM-DD"}}'
    }, {
      type: 'admin',
      label: '修改人',
      name: 'modifyUser',
      value: '',
    }];
  }

  findUserDetailInfo(searchForm: { [p: string]: any }, options: { [p: string]: any }) {
    let param: { [index: string]: string } = {
      beginTime: searchForm.modifyTime && searchForm.modifyTime.start,
      endTime: searchForm.modifyTime && searchForm.modifyTime.end,
      modifyUser:searchForm.modifyUser&&searchForm.modifyUser.accountId
    };
    param = {...searchForm, ...options, ...param};
    this.http.get(environment.getUrl('activity/rankList/findUserDetailInfo.htm'), param)
      .map(res => res.json())
      .subscribe(result => {
        if (result.status === '0') {
          let state = {
            isInit: false,
            search: JSON.stringify(searchForm),
            data: {
              currentPage: options.currentPage,
              pageSize: options.pageSize,
              total: (result.data && result.data.totalCount) || 0,
              rows: (result.data && result.data.list) || []
            }
          };
          this.$store.dispatch({
            type: SEARCH_LOCALGAME_CYCLELIST_USERS_DETAIL,
            payload: state
          })
        } else {
          this.toast.pop('warning', result.desc);
        }

      })
  }

  exportUserDetailInfo(searchForm: { [p: string]: any }, options: { [p: string]: any }):void{
    let param: { [index: string]: string } = {
      exportType:'excel',
      startTime: searchForm.modifyTime && searchForm.modifyTime.start,
      endTime: searchForm.modifyTime && searchForm.modifyTime.end,
      modifyUser:searchForm.modifyUser&&searchForm.modifyUser.accountId
    };
    param = {...searchForm,  ...param};
    this.http.download(environment.getUrl('activity/rankList/exportUserDetailInfo.htm'),param);
  }

  /*******************************活动周期用户列表详情 end***********************************************************/



}
